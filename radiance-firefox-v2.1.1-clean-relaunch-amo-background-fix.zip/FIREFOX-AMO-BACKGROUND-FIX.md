# Firefox AMO Background Fix

## Version

v2.1.1

## 수정 내용

Firefox AMO linter가 다음 경고를 표시할 수 있습니다.

`Unsupported "/background/service_worker" manifest property used without "/background/scripts" property as Firefox-compatible fallback.`

이를 피하기 위해 Firefox 패키지에서는 `background.service_worker` 대신 다음 구조를 사용합니다.

```json
"background": {
  "scripts": ["background.js"]
}
```

Chromium판은 기존처럼 `background.service_worker`를 사용합니다.
Firefox판만 AMO 호환을 위해 background scripts 방식으로 정리했습니다.
