# Radiance Lucis V2

Radiance Lucis는 Entry 작업을 위한 제작 보조 패널입니다.

## 핵심 기능

- 작업 체크리스트
- 타임라인 메모
- 메모장
- 스니펫 보관함
- 팔레트 키트
- 테마 키트
- YouTube BGM 창 열기
- 페이지 검색
- 백업 도구
- 지원 센터
- 배지
- Radiance Quality Boost V2

## V2 핵심

### Background Service Worker

Radiance V2는 background service worker를 유지합니다.

- YouTube BGM 창 열기 처리
- Quality Boost 프레임 메시지 처리
- Manifest V3 구조 유지

MV3에서는 background service worker가 평소 비활성처럼 보일 수 있습니다.  
필요한 메시지가 오면 활성화되어 동작합니다.

### YouTube BGM

Radiance는 YouTube 영상을 다운로드하거나 음원을 추출하지 않습니다.

- YouTube 링크/영상 ID 저장
- 즐겨찾기 저장
- 메모/타임라인 기록
- `분리 창 열기` 버튼으로 YouTube 원본 watch 페이지를 popup 창으로 열기

확장 내부 iframe 분리창은 사용하지 않습니다.  
이 방식은 YouTube embed 오류를 피하기 위한 구조입니다.

### Radiance Quality Boost V2

Entry의 원본 렌더 해상도를 직접 바꾸지 않습니다.  
감지된 640×400 계열 canvas에 CSS 기반 보정만 적용합니다.

- 내부 프레임 canvas 감지
- 균형 / 부드럽게 / 선명하게 모드
- 캡처 프레임
- 확대 실험
- 끄면 원상복구

## 안전 원칙

- Entry 프로젝트 데이터를 직접 수정하지 않음
- 원격 코드 실행 없음
- 사용자 데이터를 외부 서버로 전송하지 않음
- YouTube 다운로드/음원 추출/광고 우회 없음

## Credit

Radiance Lucis by Blucy1004 / Lucid Labs.


## Firefox AMO Background Fix

Firefox 제출용 패키지는 AMO linter 호환을 위해 `background.scripts` 구조를 사용합니다.
