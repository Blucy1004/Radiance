const globalKey = 'radiance:global';
const legacyGlobalKey = 'entry-helper:global';
const warnings = [
  'Radiance V2 Clean Relaunch 빌드입니다.',
  'Radiance V2 Final 정리 빌드입니다.',
  'Quality Boost 프레임 인식 핫픽스가 적용되었습니다.',
  'Radiance V2: background와 Quality Boost가 추가되었습니다.',
  'YouTube embed 오류 153 회피 핫픽스가 적용되었습니다.',
  'BGM을 별도 플레이어 창으로 열 수 있습니다.',
  'BGM 기능을 안정 구조로 되돌렸습니다.',
  'YouTube 링크를 BGM Room에서 열 수 있습니다.',
  '접힘 버튼이 더 작고 깔끔한 형태로 바뀌었습니다.',
  'Mini Dock 기본 위치가 위로 올라가 다른 확장과의 겹침을 줄였습니다.',
  'Mini Dock를 드래그해서 위치를 바꿀 수 있습니다.',
  '접힘 버튼이 테마 기반 Mini Dock으로 바뀌었습니다.',
  'Ctrl/Command+Shift+K로 빠른 실행을 열 수 있습니다.',
  '홈에서 테마를 빠르게 전환할 수 있습니다.',
  '패널 표면 배경이 테마 기준으로 수정되었습니다.',
  '패널 배경색 변화와 벚꽃 텍스트색이 조정되었습니다.',
  '테마별 이미지 배경이 실제 패널에 적용됩니다.',
  '테마 적용/저장 문제가 수정되었습니다.',
  '테마 탭에서 Radiance 패널 분위기를 바꿀 수 있습니다.',
  '팔레트 탭에서 프로젝트 색상 HEX와 CSS 변수를 관리할 수 있습니다.',
  '블록/스크립트 직접 삽입 기능은 Radiance 밖의 별도 실험툴로 분리됩니다.',
  '상단 탭을 줄이고 내 스니펫을 맨 위로 올렸습니다.',
  '코드저장 탭에서 실제 코드를 구조적으로 저장할 수 있습니다.',
  '스니펫 팩과 Bridge 연동 배지가 강화되었습니다.',
  '지원 센터 탭에서 설치 안내와 버그제보 템플릿을 복사할 수 있습니다.',
  'Chrome/Edge 안내가 Chromium판 안내로 통합되었습니다.',
  '사용설명서와 업데이트 로그가 추가되었습니다.',
  '업데이트 탭에서 브라우저별 업데이트 방법을 확인할 수 있습니다.',
  'Firefox에서는 정식 설치 전 AMO 서명이 필요합니다.',
  '패널을 접은 상태가 페이지 이동 후에도 유지됩니다.',
  '진단 탭에서 버그 제보용 상태 정보를 복사할 수 있습니다.',
  '런처 홈에서 오늘 작업 상태를 바로 확인할 수 있습니다.',
  'Radiance Lucis · V2 Clean Relaunch',
  '페이지 검색은 현재 화면에 로딩된 카드만 대상으로 동작합니다.',
  '백업은 엔트리 작품 저장이 아니라 Radiance 내부 데이터 백업입니다.',
  '작업 보호는 저장 여부를 직접 판별하는 기능이 아니라 이탈 경고입니다.',
  '장면 시작 이벤트는 해당 장면에 진입해야 실행됩니다.',
  '초시계 기반 코드는 초시계 준비 여부를 먼저 확인해 보세요.'
];

const enabled = document.getElementById('enabled');
const openPanel = document.getElementById('openPanel');
const warning = document.getElementById('warning');
warning.textContent = warnings[Math.floor(Math.random() * warnings.length)];

chrome.storage.local.get([globalKey, legacyGlobalKey], data => {
  const global = data?.[globalKey] || data?.[legacyGlobalKey] || {};
  enabled.checked = global.enabled !== false;
});

enabled.addEventListener('change', () => {
  const next = enabled.checked;
  chrome.storage.local.get([globalKey, legacyGlobalKey], data => {
    chrome.storage.local.set({
      [globalKey]: {
        ...(data?.[globalKey] || data?.[legacyGlobalKey] || {}),
        enabled: next
      }
    });
  });
  sendToActiveTab({ type: 'SET_ENABLED', enabled: next });
});

openPanel.addEventListener('click', () => {
  enabled.checked = true;
  chrome.storage.local.get([globalKey, legacyGlobalKey], data => {
    chrome.storage.local.set({
      [globalKey]: {
        ...(data?.[globalKey] || data?.[legacyGlobalKey] || {}),
        enabled: true
      }
    });
  });
  sendToActiveTab({ type: 'OPEN_PANEL' });
});

function sendToActiveTab(message) {
  chrome.tabs.query({ active: true, currentWindow: true }, tabs => {
    const tabId = tabs?.[0]?.id;
    if (!tabId) return;
    chrome.tabs.sendMessage(tabId, { source: 'ENTRY_HELPER_POPUP', ...message }, () => {
      void chrome.runtime.lastError;
    });
  });
}
