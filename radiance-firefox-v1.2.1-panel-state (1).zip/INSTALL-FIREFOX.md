# Radiance Lucis Firefox 설치/테스트 안내

## 임시 테스트

1. Firefox 주소창에 `about:debugging#/runtime/this-firefox` 입력
2. “임시 부가 기능 로드...” 클릭
3. 압축을 푼 Radiance Firefox 폴더 안의 `manifest.json` 선택
4. playentry.org에서 Radiance 패널 테스트

## 정식 배포

Firefox 일반/베타 버전에 영구 설치하려면 Mozilla 서명이 필요합니다.  
AMO(Add-ons Mozilla) Developer Hub에 업로드해서 서명/검토를 받아야 합니다.

## 주의

- 이 패키지는 Firefox용으로 manifest와 CSS 경로를 조정한 빌드입니다.
- Chrome용 ZIP을 그대로 Firefox에 올리는 것보다 이 Firefox용 ZIP을 사용하는 것을 권장합니다.
- Radiance는 외부 서버 전송 기능 없이 브라우저 로컬 저장소를 사용합니다.
