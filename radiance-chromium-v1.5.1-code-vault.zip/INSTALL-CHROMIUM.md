# Radiance Lucis Chromium판 설치 안내

Chromium판은 다음 브라우저에서 사용할 수 있습니다.

- Google Chrome
- Microsoft Edge
- Naver Whale
- Brave
- 기타 Chromium 기반 브라우저

## 설치 방법

1. ZIP 파일 압축 풀기
2. 브라우저 주소창에 확장 프로그램 관리 페이지 열기
   - Chrome: `chrome://extensions`
   - Edge: `edge://extensions`
   - Whale: `whale://extensions`
   - Brave: `brave://extensions`
3. 개발자 모드 켜기
4. “압축해제된 확장 프로그램을 로드” 클릭
5. 압축을 푼 Radiance 폴더 선택

## 업데이트 방법

새 버전 ZIP을 받아 압축을 풀고, 확장 프로그램 관리 페이지에서 기존 Radiance를 다시 로드합니다.
