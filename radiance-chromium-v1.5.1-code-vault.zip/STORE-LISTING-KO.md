# Radiance Lucis - 스토어 소개문

Radiance Lucis는 엔트리 프로젝트 제작을 돕는 브라우저 확장 프로그램입니다.

체크리스트, 타임라인 메모, 프로젝트 메모, 스니펫, Viventry Bridge, 배지 시스템, 페이지 내부 검색, Radiance 내부 백업, 작업 보호 기능을 제공합니다. 제작 중 자주 확인해야 하는 정보를 한 패널에서 관리하고, 필요한 텍스트를 현재 입력칸에 반자동으로 넣을 수 있습니다.

Radiance는 외부 채팅 서비스나 커뮤니티 기능을 포함하지 않습니다. 데이터는 브라우저 로컬 저장소에 저장되며 별도 서버로 전송되지 않습니다.


배포 안내: Chromium판은 Chrome, Edge, Whale, Brave 등 Chromium 기반 브라우저에서 사용할 수 있습니다. Firefox는 별도 Firefox판을 사용합니다.
