# Radiance Lucis V2 Clean Relaunch

## Version

v2.1.0

## Purpose

기존 테스트/실험 버전과 분리해서 새로 재출시하기 위한 클린 빌드입니다.

## Cleaned

- 브랜드 문구 정리
- Quality Boost 명칭 정리
- 이전 실험/롤백 문서 제거
- 확장 내부 YouTube iframe 분리창 제거 상태 유지
- background service worker 유지
- Quality Boost all_frames 구조 유지

## Final feature set

- Background service worker
- YouTube BGM original watch window
- Radiance Quality Boost V2 with all_frames detection
- Themes
- Palette
- Notes
- Timeline
- Checklist
- Snippets
- Page search
- Backup
- Support center
- Badges
