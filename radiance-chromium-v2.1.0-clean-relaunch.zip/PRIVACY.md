# Radiance Lucis V2 Privacy

Radiance Lucis V2는 사용자의 개인정보를 수집하거나 외부 서버로 전송하지 않습니다.

## 수집하지 않는 정보

- 이름
- 이메일
- Entry 계정 정보
- 작품 내용
- 대화 내용
- 방문 기록 전체
- 결제 정보
- 위치 정보

## 저장되는 정보

Radiance 설정과 작업 보조 데이터는 브라우저 저장소에 저장됩니다.

예시:

- 체크리스트 상태
- 메모
- 타임라인 메모
- 스니펫
- 팔레트 설정
- 테마 설정
- BGM 즐겨찾기 링크
- Quality Boost 설정
- 배지 상태

이 정보는 사용자의 브라우저 안에 저장되며 Radiance 서버로 전송되지 않습니다.

## YouTube BGM

BGM 기능은 사용자가 입력한 YouTube 링크를 YouTube 원본 watch 페이지로 여는 방식입니다.

Radiance는 다음을 하지 않습니다.

- YouTube 영상 다운로드
- 음원 추출
- 광고 우회
- YouTube 로그인 정보 수집
- YouTube 재생 기록 수집

## Quality Boost

Quality Boost는 Entry 화면의 canvas 표시 방식에 CSS 보정을 적용하는 실험 기능입니다.

- Entry 프로젝트 데이터를 수정하지 않습니다.
- 서버 전송이 없습니다.
- 기능을 끄면 적용된 CSS 보정이 해제됩니다.

## 권한 사용

Radiance는 Entry 작업 페이지에서 보조 패널을 표시하고 설정을 저장하기 위해 필요한 최소 권한만 사용합니다.

## 문의

Radiance Lucis by Blucy1004 / Lucid Labs.
