# Firefox 설치 안내

Firefox AMO 제출용 ZIP과 unsigned XPI가 포함됩니다.

## 테스트

unsigned XPI는 일반 Firefox에서 영구 설치가 제한될 수 있습니다.  
테스트가 필요하면 Firefox Developer Edition 또는 임시 애드온 로드를 사용하세요.

## AMO 제출

AMO 제출용 ZIP 파일을 사용하세요.
