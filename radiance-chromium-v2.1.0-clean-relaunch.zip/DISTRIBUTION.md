# Radiance Lucis 배포 파일 구분

## Chromium판

파일명 예시:

`radiance-chromium-v1.3.1-distribution-polish.zip`

대상 브라우저:

- Chrome
- Edge
- Whale
- Brave
- 기타 Chromium 기반 브라우저

## Firefox판

파일명 예시:

`radiance-firefox-v1.3.1-distribution-polish.zip`

대상 브라우저:

- Firefox

Firefox 일반 사용자는 Mozilla 서명된 XPI 또는 AMO 배포판을 사용하는 것을 권장합니다.

## 권장 배포 문구

Radiance Lucis는 Chromium판과 Firefox판으로 배포됩니다.

- Chromium판: Chrome, Edge, Whale, Brave 등 Chromium 기반 브라우저용
- Firefox판: Mozilla AMO 서명 기반 Firefox용
