# Radiance Lucis v1.7.1 Mini Dock Bubble

## 변경점

- 패널 접힘 버튼을 Mini Dock 스타일로 변경
- 현재 테마 이미지를 접힘 버튼 배경에 반영
- hover 시 `Radiance 열기` 라벨 표시
- 상태 점 추가
- 테마별 버튼 색감 추가

## 의도

패널을 접었을 때도 단순 아이콘이 아니라
Radiance의 분위기와 현재 테마가 살아있는 작은 런처처럼 보이게 합니다.
