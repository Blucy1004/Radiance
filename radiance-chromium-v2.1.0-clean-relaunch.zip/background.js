chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (!message || message.type !== 'RADIANCE_OPEN_YOUTUBE_WINDOW') return false;

  const videoId = String(message.videoId || '').replace(/[^a-zA-Z0-9_-]/g, '').slice(0, 11);
  if (!videoId) {
    sendResponse?.({ ok: false, error: 'missing_video_id' });
    return true;
  }

  const url = `https://www.youtube.com/watch?v=${encodeURIComponent(videoId)}`;

  try {
    chrome.windows.create({
      url,
      type: 'popup',
      width: 960,
      height: 640,
      left: 80,
      top: 80,
      focused: true
    }, win => {
      const err = chrome.runtime.lastError;
      if (err) sendResponse?.({ ok: false, error: err.message });
      else sendResponse?.({ ok: true, windowId: win?.id || null });
    });
  } catch (error) {
    sendResponse?.({ ok: false, error: String(error?.message || error) });
  }

  return true;
});

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (!message || message.type !== 'RADIANCE_BACKGROUND_PING') return false;
  sendResponse?.({ ok: true, name: 'Radiance Background', version: '2.0.0' });
  return true;
});


chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message || message.type !== 'RADIANCE_QUALITY_BROADCAST') return false;

  const tabId = sender?.tab?.id;
  if (!tabId) {
    sendResponse?.({ ok: false, error: 'missing_tab' });
    return true;
  }

  chrome.tabs.sendMessage(tabId, {
    type: 'RADIANCE_QUALITY_FRAME_APPLY',
    state: message.state || {}
  }, () => {
    // It is okay if some frames do not have the frame script.
    sendResponse?.({ ok: true });
  });

  return true;
});
