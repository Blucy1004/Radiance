(() => {
  const APP_ID = 'entry-helper-toolkit';
  const QUALITY_FRAME_STORAGE_KEY = 'radianceQualityBoostFrameState';
  if (window.__ENTRY_HELPER_TOOLKIT__) return;
  window.__ENTRY_HELPER_TOOLKIT__ = true;

  const TEXT = {
  "name": "Radiance",
  "shortName": "Radiance",
  "description": "유저 블루시가 제작한 엔트리 제작 도우미, Radiance에 오신 것을 환영합니다!",
  "panelTitle": "엔트리 제작 도우미",
  "panelSubtitle": "제작 중 자주 확인할 도구를 한곳에 모았습니다.",
  "openButton": "도우미 열기",
  "closeButton": "접기",
  "resetButton": "초기화",
  "copyButton": "복사",
  "copiedToast": "복사되었습니다.",
  "savedToast": "저장되었습니다.",
  "resetConfirm": "이 페이지에 저장된 도구 데이터를 초기화할까요?",
  "emptyState": "아직 저장된 내용이 없습니다.",
  "tabs": {
    "home": "홈",
    "check": "체크리스트",
    "coord": "좌표",
    "timeline": "타임라인",
    "notes": "메모",
    "snippet": "스니펫",
    "palette": "팔레트",
    "theme": "테마",
    "codeVault": "코드저장",
    "tips": "팁",
    "badges": "배지",
    "diagnostics": "진단",
    "backupTools": "데이터",
    "settings": "설정",
    "guide": "사용설명서",
    "updateHub": "업데이트",
    "support": "지원",
    "bridge": "연동",
    "save": "백업",
    "pageSearch": "페이지 검색",
    "guard": "작업 보호"
  },
  "checkTitle": "프로젝트 점검",
  "checkDescription": "실행 전에 자주 놓치는 부분을 확인해 보세요.",
  "progressLabel": "점검률",
  "clearChecks": "체크 해제",
  "coordsTitle": "엔트리 좌표 계산기",
  "coordsDescription": "엔트리 화면 기준 좌표를 빠르게 확인하고 복사합니다.",
  "xLabel": "X",
  "yLabel": "Y",
  "resultLabel": "복사용 좌표",
  "stageHint": "기본 화면 범위: X -240~240 / Y -120~120",
  "customCoords": "커스텀 좌표 검사",
  "outsideWarning": "화면 밖 가능성",
  "timelineTitle": "타이포그래피 타임라인 메모",
  "timelineDescription": "가사, 효과, 장면 전환 타이밍을 적어 두세요.",
  "timelinePlaceholder": "예: 00.0s  첫 문장 등장\n01.2s  화면 전환\n02.5s  다음 가사",
  "addLineButton": "현재 줄 추가",
  "sortButton": "시간순 정렬",
  "timelineHint": "팁: “초.초s 텍스트 x/y/size/effect” 형태로 적으면 정렬이 잘 됩니다.",
  "notesTitle": "프로젝트 메모",
  "notesDescription": "아이디어, 수정할 점, 테스트 결과를 자유롭게 적어 두세요.",
  "notesPlaceholder": "예: 2절부터 글자 크기 줄이기 / 배경을 조금 더 어둡게 조정",
  "backupJson": "백업 JSON",
  "snippetsTitle": "자주 쓰는 문구/코드 메모",
  "snippetsDescription": "반복해서 쓰는 메모나 제작 패턴을 저장해 두세요.",
  "snippetsPlaceholder": "예: 페이드 인 → 대기 → 페이드 아웃 패턴",
  "mySnippets": "내 스니펫",
  "copyMySnippets": "내 스니펫 복사",
  "tipsTitle": "제작 팁",
  "tipsDescription": "작업 중 확인하면 좋은 짧은 팁입니다.",
  "randomButton": "다른 팁 보기",
  "studioTitle": "작품만들기 연동",
  "studioDescription": "엔트리 작품만들기 화면에서 입력칸을 감지하고 값을 넣습니다.",
  "bridgeTitle": "Viventry Bridge",
  "bridgeDescription": "Viventry가 만든 JSON 계획을 붙여넣고 큐 단위로 적용합니다.",
  "insertButton": "입력",
  "insertTextButton": "입력칸에 넣기",
  "currentTarget": "현재 입력 대상",
  "noTarget": "엔트리 입력칸을 먼저 클릭해 주세요.",
  "detectWorkspace": "작품만들기 감지",
  "detected": "감지됨",
  "notDetected": "미확실",
  "bringSelection": "선택 텍스트 가져오기",
  "parseJson": "JSON 분석",
  "bridgePlaceholder": "Viventry JSON을 여기에 붙여넣기",
  "queuePreview": "큐 미리보기",
  "markDone": "완료",
  "clearDone": "완료 해제",
  "jsonInvalid": "JSON 형식이 맞지 않습니다.",
  "targetInserted": "입력칸에 넣었습니다.",
  "storageUnavailable": "브라우저 저장소를 사용할 수 없습니다.",
  "copyFailed": "복사에 실패했습니다. 직접 선택해서 복사해 주세요.",
  "loadFailed": "도구를 불러오는 중 문제가 발생했습니다.",
  "badgesTitle": "Radiance 배지",
  "badgesDescription": "작업 중 특정 조건을 만족하면 자동으로 달성되는 작은 업적입니다.",
  "badgeUnlocked": "새 배지 달성",
  "badgeLocked": "잠김",
  "badgeUnlockedLabel": "달성",
  "settingsTitle": "설정",
  "settingsDescription": "Radiance 동작과 엔트리 화면 보조 기능을 조정합니다.",
  "darkModeTitle": "다크모드 임시 중단",
  "darkModeDescription": "엔트리 홈/작품/에디터 화면 구조가 달라 안정화 전까지 다크모드를 제외했습니다.",
  "darkModeOn": "다크모드 켜짐",
  "darkModeOff": "다크모드 꺼짐",
  "experimental": "실험적"
};
  const WARNINGS = [
  "흰 배경 위의 흰 글자는 보이지 않을 수 있습니다. 배경색과 글자색 대비를 확인해 보세요.",
  "초시계 기반 코드를 사용할 때는 초시계가 정상적으로 동작하는지 먼저 확인해 보세요.",
  "오브젝트나 복제본 수가 많아지면 실행 속도가 느려질 수 있습니다.",
  "장면 시작 이벤트는 해당 장면에 진입해야 실행됩니다.",
  "Im Handsome:sunglasses:"
];
  const CHECKLIST = [
  {
    "id": "scene-start",
    "text": "장면 시작하기 코드를 사용한 장면에 시작하기 버튼을 클릭했을 때가 없나요?"
  },
  {
    "id": "timer",
    "text": "초시계 기반 코드를 쓴다면 초시계가 준비되어 있나요?"
  },
  {
    "id": "text-contrast",
    "text": "글자색과 배경색이 충분히 구분되나요?"
  },
  {
    "id": "stage-bound",
    "text": "중요 오브젝트가 화면 범위 안에 있나요?"
  },
  {
    "id": "layering",
    "text": "배경/오브젝트/텍스트 레이어 순서가 의도대로인가요?"
  },
  {
    "id": "textbox-lines",
    "text": "여러 줄 텍스트 정렬이 깨지지 않나요?"
  },
  {
    "id": "clone-count",
    "text": "복제본이나 오브젝트 수가 너무 많지 않나요?"
  },
  {
    "id": "music-sync",
    "text": "음악 싱크 타이밍이 잘 맞나요?"
  }
];
  const COORD_PRESETS = [
  {
    "label": "중앙",
    "x": 0,
    "y": 0
  },
  {
    "label": "왼쪽 위",
    "x": -240,
    "y": 120
  },
  {
    "label": "오른쪽 위",
    "x": 240,
    "y": 120
  },
  {
    "label": "왼쪽 아래",
    "x": -240,
    "y": -120
  },
  {
    "label": "오른쪽 아래",
    "x": 240,
    "y": -120
  },
  {
    "label": "아래 중앙",
    "x": 0,
    "y": -120
  }
];

  const RELEASE_NOTES = [
    {
      version: '2.1.0',
      title: 'V2 Clean Relaunch',
      date: '2026-06-11',
      items: [
        '재출시용 클린 빌드',
        '브랜드 문구 정리',
        'Radiance Quality Boost V2 명칭 통일',
        'background service worker 유지',
        'Quality Boost 프레임 감지 유지'
      ]
    },
    {
      version: '2.0.2',
      title: 'V2 Final Clean',
      date: '2026-06-11',
      items: [
        'V2 최종 정리 빌드',
        'background service worker 유지',
        'YouTube BGM 원본 창 열기 유지',
        'Quality Boost V2 프레임 감지 유지',
        '이전 실험/롤백 흔적 정리'
      ]
    },
    {
      version: '2.0.1',
      title: 'V2 Final',
      date: '2026-06-11',
      items: [
        'Quality Boost가 내부 프레임의 canvas를 못 잡는 문제 수정',
        '화질 보정 전용 all_frames content script 추가',
        'Radiance 본체 패널은 top frame에만 유지',
        'Quality Boost 설정을 chrome.storage.local로 프레임에 공유',
        '프레임별 canvas 감지 범위 확장'
      ]
    },
    {
      version: '2.0.0',
      title: 'Radiance V2 · Background + Quality Boost',
      date: '2026-06-11',
      items: [
        'background service worker 복구',
        'YouTube BGM 창 열기를 background에서 처리',
        '오류 153 회피를 위해 YouTube 원본 watch 창 사용',
        'Radiance Quality Boost V2 탭 추가',
        '640×400 canvas 후보 감지/선명도 보정/캡처 프레임/확대 실험 추가'
      ]
    },
    {
      version: '1.8.1',
      title: 'YouTube Window Hotfix',
      date: '2026-06-11',
      items: [
        'YouTube embed 오류 153 회피',
        'BGM 분리 창을 확장 내부 iframe이 아닌 YouTube 원본 창으로 열도록 변경',
        'background service worker 의존도를 줄여 content script에서 직접 window.open 사용',
        '기존 BGM 링크/즐겨찾기/기록 기능 유지',
        'BGM Player Window 문서 업데이트'
      ]
    },
    {
      version: '1.8.0',
      title: 'BGM Player Window',
      date: '2026-06-11',
      items: [
        'YouTube BGM을 별도 플레이어 창으로 여는 기능 추가',
        '패널 닫기/탭 이동과 BGM 재생을 분리',
        'BGM 탭에 분리 창 열기 버튼 추가',
        '즐겨찾기에서도 분리 창으로 바로 열기 지원',
        '기존 패널 내부 임베드 기능은 유지'
      ]
    },
    {
      version: '1.7.9',
      title: 'BGM Safety Rollback',
      date: '2026-06-11',
      items: [
        'v1.7.8에서 패널이 사라질 수 있는 문제 방지',
        'BGM 플레이어를 안정적인 v1.7.5 구조로 롤백',
        'YouTube BGM Room 기능 유지',
        'Quality Boost 안내 카드 유지',
        '패널 본체 안정성 우선 적용'
      ]
    },
    {
      version: '1.7.5',
      title: 'YouTube BGM Room',
      date: '2026-06-11',
      items: [
        'YouTube BGM Room 추가',
        'YouTube 링크를 임베드 플레이어로 재생',
        'BGM 즐겨찾기 슬롯 저장',
        '현재 BGM을 메모/타임라인에 기록',
        'Quality Boost 실험실 안내 카드 추가'
      ]
    },
    {
      version: '1.7.4',
      title: 'Seasonal Theme Swap',
      date: '2026-06-11',
      items: [
        '고대 유적 / 사이버펑크 테마를 겨울 / 숲 테마로 교체',
        '겨울 테마는 종탑 중심의 차가운 설경 분위기로 구성',
        '숲 테마는 숲속 유적 분위기의 잔잔한 녹색 톤으로 구성',
        '기존 테마 저장값도 새 테마로 자동 이어받도록 보정',
        '패널과 미니 도크 색상도 새 테마에 맞춰 조정'
      ]
    },
    {
      version: '1.7.3',
      title: 'Clean Bubble Lift',
      date: '2026-06-11',
      items: [
        '접힘 버튼을 로고 중심의 깔끔한 미니 버튼으로 단순화',
        '버튼 기본 위치를 더 위로 조정',
        '다른 확장 패널과 겹침을 줄이도록 위치 마진 수정',
        'hover 시에만 짧은 라벨이 보이도록 정리',
        'Mini Dock 위치 프리셋도 상향 조정'
      ]
    },
    {
      version: '1.7.2',
      title: 'Dock Position Control',
      date: '2026-06-11',
      items: [
        'Mini Dock 위치 저장 추가',
        'Mini Dock 드래그 이동 지원',
        '좌상/우상/좌하/우하 위치 프리셋 추가',
        '홈에서 위치를 바로 바꿀 수 있는 카드 추가',
        '화면 리사이즈 시 Mini Dock 위치 자동 보정'
      ]
    },
    {
      version: '1.7.1',
      title: 'Mini Dock Bubble',
      date: '2026-06-10',
      items: [
        '패널 접힘 버튼을 Mini Dock 스타일로 변경',
        '접힘 버튼에 현재 테마 이미지 반영',
        '접힘 버튼 hover 확장 효과 추가',
        '접힘 버튼에 상태 점/열기 라벨 추가',
        '테마별 접힘 버튼 색감 개선'
      ]
    },
    {
      version: '1.7.0',
      title: 'Command Palette',
      date: '2026-06-10',
      items: [
        '빠른 실행 커맨드 팔레트 추가',
        'Ctrl/Command + Shift + K 단축키 추가',
        '탭 이동/테마 적용/백업/초기화/설정 액션 검색 지원',
        '헤더 빠른 실행 버튼 추가',
        '커맨드 팔레트 사용 배지 추가'
      ]
    },
    {
      version: '1.6.1',
      title: 'Theme Quick Switch',
      date: '2026-06-10',
      items: [
        '홈에 퀵 테마 전환 바 추가',
        '랜덤 테마 버튼 추가',
        '현재 테마 다시 적용 버튼 추가',
        '테마 변경/랜덤 테마 사용 배지 추가',
        '테마 전환 UX 개선'
      ]
    },
    {
      version: '1.6.0',
      title: 'Panel Surface Fix',
      date: '2026-06-10',
      items: [
        '예전 런처 스킨 CSS가 패널 표면을 덮어쓰던 문제 수정',
        '탭 영역/바디/푸터/경고 박스/헤더 표면을 테마 기준으로 통일',
        '깔끔한 다크 테마의 패널 배경을 확실한 다크 톤으로 조정',
        '벚꽃 테마 텍스트색 유지 및 표면 계열 정리'
      ]
    },
    {
      version: '1.5.9',
      title: 'Theme Color Hotfix',
      date: '2026-06-10',
      items: [
        '패널 배경색 변화가 약하던 문제 수정',
        '테마별 컬러 틴트 오버레이 추가로 배경 차이 강화',
        '카드/버튼 계열 대비 조정',
        '벚꽃 테마 텍스트색 가독성 조정'
      ]
    },
    {
      version: '1.5.8',
      title: 'Theme Image Pack',
      date: '2026-06-10',
      items: [
        '테마별 실제 이미지 배경 적용',
        '홈 히어로 카드에 현재 테마 이미지 반영',
        '테마 선택 카드에 이미지 미리보기 적용',
        'CSS 변수 우선순위 문제 수정으로 테마별 디자인 차이 강화',
        '하늘섬/다크/화이트/벚꽃/해변/유적/사이버펑크/우주 이미지 포함'
      ]
    },
    {
      version: '1.5.7',
      title: 'Theme Save Hotfix',
      date: '2026-06-10',
      items: [
        '테마 적용이 즉시 반영되지 않던 문제 수정',
        '테마 설정이 새로고침 후 하늘섬으로 돌아가던 문제 수정',
        '다크모드 봉인 코드가 테마를 초기화하던 문제 수정',
        '설정 탭 진입 시 테마가 초기화되던 문제 수정',
        '테마 저장 스냅샷 중복 정리'
      ]
    },
    {
      version: '1.5.6',
      title: 'Theme Kit Update',
      date: '2026-06-10',
      items: [
        '테마 탭 추가',
        '하늘섬/깔끔한 다크/깔끔한 화이트/벚꽃/여름 해변가/고대 유적/사이버펑크/우주 테마 추가',
        '테마 미리보기 카드 추가',
        '클릭 즉시 Radiance 패널 테마 변경',
        '테마 설정 저장 및 백업 포함'
      ]
    },
    {
      version: '1.5.5',
      title: 'Palette Kit Update',
      date: '2026-06-10',
      items: [
        '색상 팔레트 탭 추가',
        '프로젝트별 색 이름/HEX/역할 저장 지원',
        'HEX 복사/CSS 변수 복사/팔레트 전체 복사 지원',
        '팔레트 내용을 메모로 보내기 지원',
        '기본 추천 팔레트 프리셋 추가',
        '연동/Bridge 접근 제거 및 Safe Core 방향 유지'
      ]
    },
    {
      version: '1.5.4',
      title: 'Safe Core Update',
      date: '2026-06-10',
      items: [
        'Radiance 본체를 안정 제작 보조 라인으로 정리',
        '코드저장 탭을 상단 탭에서 제거',
        '블록/스크립트 직접 삽입 기능은 별도 실험툴로 분리 안내',
        '지원 탭에 Safe Core 안내 추가',
        '패널 구성을 메모/스니펫/백업/검색/지원 중심으로 정리'
      ]
    },
    {
      version: '1.5.2',
      title: 'Panel Slim Update',
      date: '2026-06-10',
      items: [
        '스니펫 탭에서 내 스니펫을 맨 위로 이동',
        '상단 탭 수를 줄여 자주 쓰는 기능 중심으로 정리',
        '배지/진단/데이터/사용설명서/업데이트/설정은 지원 탭 바로가기로 이동',
        '지원 탭에 관리 바로가기 카드 추가'
      ]
    },
    {
      version: '1.5.1',
      title: 'Code Vault Update',
      date: '2026-06-10',
      items: [
        '코드저장 탭 추가',
        '제목/언어/설명/태그/코드 구조 저장 지원',
        '코드 복사/입력칸 삽입/메모로 보내기 지원',
        '코드 보관함 JSON 내보내기/가져오기 지원',
        'Radiance 전체 데이터 백업에 코드 보관함 포함'
      ]
    },
    {
      version: '1.5.0',
      title: 'Creator Power Update',
      date: '2026-06-10',
      items: [
        '스니펫 팩 추가',
        '스니펫을 메모/타임라인/Bridge로 보내는 기능 추가',
        'Bridge 큐 진행률/전체 복사/현재 큐 메모화 추가',
        '스니펫 팩 기반 Bridge 예시 생성 추가',
        '스니펫/연동/지원센터 관련 배지 추가'
      ]
    },
    {
      version: '1.4.0',
      title: 'Support Center Update',
      date: '2026-06-09',
      items: [
        '지원 센터 탭 추가',
        'Chromium/Firefox 설치 안내 복사 기능 추가',
        '버그제보 템플릿을 지원 탭으로 정리',
        '업데이트/재설치 안내 카드 추가',
        '배포 후 사용자 안내용 문구 보강'
      ]
    },
    {
      version: '1.3.1',
      title: 'Distribution Polish',
      date: '2026-06-09',
      items: [
        'Chrome/Edge 별도 안내를 Chromium판 안내로 통합',
        'Chromium 기반 브라우저 설치 안내 추가',
        'Firefox AMO 서명판 안내 유지',
        '릴리즈 공지/업데이트 문구 정리'
      ]
    },
    {
      version: '1.3.0',
      title: 'Release Hub Update',
      date: '2026-06-09',
      items: [
        '사용설명서 탭 추가',
        '업데이트 탭 추가',
        '브라우저별 업데이트 방법 안내',
        '버그제보 템플릿 복사 기능 추가',
        '릴리즈 공지 문구 복사 기능 추가'
      ]
    },
    {
      version: '1.2.1',
      title: 'Panel State Fix',
      date: '2026-06-09',
      items: [
        '패널을 접은 뒤 페이지 이동 시 다시 열리던 문제 수정',
        '패널 열림/접힘 상태를 전역 UI 상태로 저장',
        'Firefox AMO 제출용 데이터 수집 권한 선언 추가'
      ]
    },
    {
      version: '1.2.0',
      title: 'Store Ready Toolkit',
      date: '2026-06-09',
      items: [
        '진단 탭 추가',
        '데이터 관리 탭 추가',
        '스토어 심사용 점검/내보내기 기능 추가'
      ]
    }
  ];

  const USER_GUIDE_SECTIONS = [
    {
      title: '1. 패널 열기',
      body: 'playentry.org에서 확장 아이콘을 누르고 “도우미 열기”를 클릭합니다. 패널을 접으면 페이지를 옮겨도 접힌 상태가 유지됩니다.'
    },
    {
      title: '2. 체크리스트',
      body: '프로젝트 실행 전 장면 진입, 초시계, 레이어, 좌표, 텍스트 색 같은 자주 놓치는 항목을 빠르게 확인합니다.'
    },
    {
      title: '3. 타임라인',
      body: '타이포그래피나 연출 타이밍을 초 단위로 적어 둡니다. 시간순 정렬 버튼으로 큐를 정리할 수 있습니다.'
    },
    {
      title: '4. 메모 / 스니펫',
      body: '아이디어, 수정사항, 반복해서 쓰는 문구를 저장합니다. 복사 버튼으로 바로 가져갈 수 있습니다.'
    },
    {
      title: '5. 페이지 검색',
      body: '현재 화면에 로딩된 작품 카드나 목록을 검색합니다. 서버 전체 검색이 아니라 현재 페이지 내부 검색입니다.'
    },
    {
      title: '6. 백업 / 데이터',
      body: 'Radiance 내부 데이터만 브라우저 로컬에 백업합니다. 엔트리 작품 파일 자체를 저장하는 기능은 아닙니다.'
    },
    {
      title: '7. 진단',
      body: '버전, 현재 탭, 백업 수, 페이지 검색 대상 수 등 버그제보에 필요한 정보를 복사합니다.'
    },
    {
      title: '8. 업데이트',
      body: '브라우저별 업데이트 방식을 확인하고, 릴리즈 공지/버그제보 템플릿을 복사합니다.'
    }
  ];

  const DEFAULT_SNIPPETS = [
  {
    "title": "타이포 타임라인",
    "body": "00.0s  텍스트 등장\n01.0s  크기 변화\n02.0s  페이드 아웃"
  },
  {
    "title": "디버그 체크",
    "body": "장면 진입 / 초시계 / 레이어 / 좌표 / 텍스트 색 확인"
  }
];

  const SNIPPET_PACKS = [
    {
      id: 'typo',
      title: '타이포 제작 팩',
      tag: 'Typography',
      desc: '가사/타이밍/효과 정리용',
      snippets: [
        { title: '타이포 큐 기본형', body: '00.0s  텍스트 등장  x:0 y:20 size:34 effect:fade-in\n01.2s  다음 구절    x:-40 y:0 size:32 effect:slide-up\n02.5s  페이드 아웃  effect:fade-out' },
        { title: '글자 확인 체크', body: '폰트 / 색 대비 / 크기 / 중앙정렬 / 레이어 / 초시계 / 장면 진입 확인' },
        { title: '연출 메모', body: '등장: ease-out / 유지: 0.6s / 퇴장: fade-out / 카메라 흔들림 최소' }
      ]
    },
    {
      id: 'debug',
      title: '디버그 팩',
      tag: 'Debug',
      desc: '엔트리 제작 중 막혔을 때 점검',
      snippets: [
        { title: '장면 디버그', body: '장면 시작하기로 진입했는가?\n해당 장면의 “장면이 시작되었을 때” 코드가 맞는가?\n오브젝트가 숨김/레이어 뒤에 있지 않은가?' },
        { title: '초시계 디버그', body: '초시계 변수가 있는가?\n시작 시 초시계 초기화가 되는가?\n시간 조건이 너무 좁지 않은가?' },
        { title: '좌표 디버그', body: '화면 범위 X -240~240 / Y -120~120\n크기 100 기준 중심점 확인\n배경보다 앞 레이어인지 확인' }
      ]
    },
    {
      id: 'release',
      title: '배포 팩',
      tag: 'Release',
      desc: '배포글/버그제보/업데이트 정리',
      snippets: [
        { title: '배포 공지 기본형', body: 'Radiance Lucis 업데이트\n\n지원 브라우저:\n- Chromium판: Chrome, Edge, Whale, Brave 등\n- Firefox판: AMO 서명판\n\n변경점:\n- ' },
        { title: '버그제보 요청', body: '버그 제보 시 브라우저 종류, 사용한 파일명, 재현 순서, 화면 캡처, 진단 JSON을 함께 보내주세요.' },
        { title: '업데이트 안내', body: 'Chromium판은 새 ZIP을 받아 확장 프로그램 관리 페이지에서 다시 로드하고, Firefox판은 signed XPI 또는 AMO 배포판을 사용합니다.' }
      ]
    },
    {
      id: 'bridge',
      title: 'Bridge 큐 팩',
      tag: 'Bridge',
      desc: 'Viventry/Radiance 큐 변환용',
      snippets: [
        { title: 'Bridge JSON 기본형', body: '{\n  "type": "radiance-timeline",\n  "items": [\n    { "time": "00.0", "text": "첫 문장", "x": 0, "y": 20, "size": 34, "effect": "fade-in" }\n  ]\n}' },
        { title: 'Bridge 필드 목록', body: 'text / x / y / size / direction / effect / scene / object' },
        { title: '큐 적용 루틴', body: '현재 큐 선택 → 텍스트 넣고 다음 → 완료 체크 → 다음 큐 확인' }
      ]
    }
  ];


  const PALETTE_ROLES = ['메인', '배경', '텍스트', '강조', '그림자', '버튼', '라인', '기타'];

  const PALETTE_PRESETS = [
    {
      id: 'radiance-sky',
      title: 'Radiance Sky',
      desc: 'Radiance 기본 청량 하늘톤',
      colors: [
        { name: 'Radiance Main', hex: '#A1A1FF', role: '메인' },
        { name: 'Sky Accent', hex: '#7DD3FC', role: '강조' },
        { name: 'Cloud Text', hex: '#FFFFFF', role: '텍스트' },
        { name: 'Deep Panel', hex: '#202436', role: '배경' }
      ]
    },
    {
      id: 'dark-panel',
      title: 'Dark Panel',
      desc: '다크 UI 패널용',
      colors: [
        { name: 'Panel Background', hex: '#141827', role: '배경' },
        { name: 'Card Surface', hex: '#202436', role: '배경' },
        { name: 'Main Text', hex: '#F8FAFC', role: '텍스트' },
        { name: 'Soft Line', hex: '#334155', role: '라인' }
      ]
    },
    {
      id: 'entry-clean',
      title: 'Entry Clean',
      desc: '엔트리 작품 설명/썸네일용 깔끔톤',
      colors: [
        { name: 'Clean Blue', hex: '#4F8CFF', role: '메인' },
        { name: 'Soft Background', hex: '#F6F8FF', role: '배경' },
        { name: 'Ink Text', hex: '#1F2937', role: '텍스트' },
        { name: 'Fresh Accent', hex: '#22C55E', role: '강조' }
      ]
    },
    {
      id: 'typography-pink',
      title: 'Typography Pink',
      desc: '가사 타이포/감성맵용',
      colors: [
        { name: 'Petal Pink', hex: '#FFB7D5', role: '메인' },
        { name: 'Soft Rose', hex: '#FFE4EF', role: '배경' },
        { name: 'Night Purple', hex: '#2A1B3D', role: '텍스트' },
        { name: 'Glow Point', hex: '#F472B6', role: '강조' }
      ]
    },
    {
      id: 'ocean-blue',
      title: 'Ocean Blue',
      desc: '청량/바다/하늘 계열',
      colors: [
        { name: 'Ocean Main', hex: '#0EA5E9', role: '메인' },
        { name: 'Deep Sea', hex: '#075985', role: '배경' },
        { name: 'Foam', hex: '#E0F2FE', role: '텍스트' },
        { name: 'Mint Light', hex: '#67E8F9', role: '강조' }
      ]
    },
    {
      id: 'sunset-warm',
      title: 'Sunset Warm',
      desc: '노을/따뜻한 분위기',
      colors: [
        { name: 'Sunset Orange', hex: '#FB923C', role: '메인' },
        { name: 'Warm Yellow', hex: '#FACC15', role: '강조' },
        { name: 'Rose Sky', hex: '#FDA4AF', role: '배경' },
        { name: 'Brown Text', hex: '#431407', role: '텍스트' }
      ]
    }
  ];



  const THEME_PRESETS = [
    { id: 'sky-island', title: '하늘섬', desc: '떠있는 섬과 폭포가 있는 기본 테마', asset: 'assets/themes/sky-island.webp', colors: ['#A1A1FF', '#7DD3FC', '#FFFFFF', '#202436'] },
    { id: 'clean-dark', title: '깔끔한 다크', desc: '집중용 미니멀 다크 테마', asset: 'assets/themes/clean-dark.webp', colors: ['#111827', '#334155', '#F8FAFC', '#60A5FA'] },
    { id: 'clean-white', title: '깔끔한 화이트', desc: '밝고 깨끗한 화이트 테마', asset: 'assets/themes/clean-white.webp', colors: ['#FFFFFF', '#F1F5F9', '#0F172A', '#2563EB'] },
    { id: 'cherry-blossom', title: '벚꽃', desc: '봄날의 벚꽃 정원 테마', asset: 'assets/themes/cherry-blossom.webp', colors: ['#FFE4EF', '#FFB7D5', '#3B2330', '#F472B6'] },
    { id: 'summer-beach', title: '여름 해변가', desc: '청량한 바다와 모래빛 테마', asset: 'assets/themes/summer-beach.webp', colors: ['#E0F7FA', '#38BDF8', '#0F3A4A', '#FACC15'] },
    { id: 'winter-belltower', title: '겨울', desc: '눈 덮인 종탑과 푸른 설경 테마', asset: 'assets/themes/winter-belltower.webp', colors: ['#1E3A8A', '#93C5FD', '#EFF6FF', '#F9A8D4'] },
    { id: 'forest-ruins', title: '숲', desc: '숲 유적의 고요한 녹색 테마', asset: 'assets/themes/forest-ruins.webp', colors: ['#163A2E', '#34D399', '#ECFDF5', '#A7F3D0'] },
    { id: 'space', title: '우주', desc: '어두운 성운과 행성 테마', asset: 'assets/themes/space.webp', colors: ['#070B1A', '#312E81', '#E0E7FF', '#A78BFA'] }
  ];


  const state = {
    enabled: true,
    collapsed: false,
    tab: 'home',
    checklist: {},
    timeline: '',
    notes: '',
    customSnippets: '',
    palette: [],
    codeVault: [],
    bridgeJson: '',
    bridgeDone: {},
    bridgeInsertText: '',
    bridgeActiveIndex: 0,
    saveWatcher: defaultSaveWatcherState(),
    internalBackup: defaultInternalBackupState(),
    pageSearch: defaultPageSearchState(),
    leaveGuard: defaultLeaveGuardState(),
    bgmRoom: defaultBgmState(),
    qualityBoost: defaultQualityBoostState(),
    badges: {},
    stats: {},
    darkMode: false,
    commandOpen: false,
    commandQuery: '',
    theme: 'sky-island',
    position: { right: 18, top: 82 },
    bubblePosition: { right: 18, bottom: 94 },
    warningIndex: Math.floor(Math.random() * WARNINGS.length)
  };

  const projectKey = makeProjectKey();
  const storageKey = `radiance:${projectKey}`;
  const legacyStorageKey = `entry-helper:${projectKey}`;
  const globalKey = 'radiance:global';
  const legacyGlobalKey = 'entry-helper:global';

  function makeProjectKey() {
    const url = new URL(location.href);
    const match = url.pathname.match(/\/project\/([^/?#]+)/i);
    const project = match?.[1];
    if (project) return `project:${project}`;
    const cleanPath = url.pathname.replace(/[^a-zA-Z0-9_-]/g, '_').replace(/^_+|_+$/g, '');
    return cleanPath ? `page:${cleanPath}` : `host:${url.hostname}`;
  }

  function safeChromeStorageGet(keys) {
    return new Promise(resolve => {
      try { chrome.storage.local.get(keys, resolve); }
      catch { resolve({}); }
    });
  }

  function safeChromeStorageSet(value) {
    return new Promise(resolve => {
      try { chrome.storage.local.set(value, resolve); }
      catch { resolve(); }
    });
  }

  async function loadState() {
    const data = await safeChromeStorageGet([globalKey, storageKey, legacyGlobalKey, legacyStorageKey]);
    const global = data[globalKey] || data[legacyGlobalKey] || {};
    const local = data[storageKey] || data[legacyStorageKey] || {};
    Object.assign(state, global, local);
    // v1.2.1: panel open/collapsed is a global UI state.
    // Page-local saved data should not reopen the panel after the user collapsed it.
    if (typeof global.enabled === 'boolean') state.enabled = global.enabled;
    if (typeof global.collapsed === 'boolean') state.collapsed = global.collapsed;
    if (global.position && typeof global.position === 'object') state.position = Object.assign(state.position || {}, global.position);
    if (global.bubblePosition && typeof global.bubblePosition === 'object') state.bubblePosition = Object.assign(state.bubblePosition || {}, global.bubblePosition);
    if (typeof state.warningIndex !== 'number' || state.warningIndex >= WARNINGS.length) state.warningIndex = 0;
    if (!Array.isArray(state.palette)) state.palette = [];
    if (!Array.isArray(state.codeVault)) state.codeVault = [];
    if (!state.badges || typeof state.badges !== 'object') state.badges = {};
    if (!state.stats || typeof state.stats !== 'object') state.stats = {};
    state.theme = getThemeId();
    if (!state.leaveGuard || typeof state.leaveGuard !== 'object') state.leaveGuard = defaultLeaveGuardState();
    state.leaveGuard = Object.assign(defaultLeaveGuardState(), state.leaveGuard);
    if (!state.pageSearch || typeof state.pageSearch !== 'object') state.pageSearch = defaultPageSearchState();
    state.pageSearch = Object.assign(defaultPageSearchState(), state.pageSearch);
    if (!state.internalBackup || typeof state.internalBackup !== 'object') state.internalBackup = defaultInternalBackupState();
    state.internalBackup = Object.assign(defaultInternalBackupState(), state.internalBackup);
    if (!Array.isArray(state.internalBackup.items)) state.internalBackup.items = [];
    if (!state.saveWatcher || typeof state.saveWatcher !== 'object') state.saveWatcher = defaultSaveWatcherState();
    state.saveWatcher = Object.assign(defaultSaveWatcherState(), state.saveWatcher);
    ensureBgmState();
    ensureQualityBoostState();
    applyDarkMode();
    applyQualityBoost(false);
    setupInternalBackupTimer();
    // Auto-save timer disabled in v0.6.7 hotfix to prevent page freezes.
  }

  function localSnapshot() {
    return {
      [storageKey]: {
        collapsed: state.collapsed,
        tab: state.tab,
        checklist: state.checklist,
        timeline: state.timeline,
        notes: state.notes,
        customSnippets: state.customSnippets,
        palette: state.palette,
        codeVault: state.codeVault,
        bridgeJson: state.bridgeJson,
        bridgeDone: state.bridgeDone,
        bridgeInsertText: state.bridgeInsertText,
        bridgeActiveIndex: state.bridgeActiveIndex || 0,
        saveWatcher: state.saveWatcher,
        internalBackup: state.internalBackup,
        pageSearch: state.pageSearch,
        leaveGuard: state.leaveGuard,
        bgmRoom: state.bgmRoom,
        qualityBoost: state.qualityBoost,
        badges: state.badges,
        stats: state.stats,
        theme: state.theme,
        warningIndex: state.warningIndex
      }
    };
  }

  function saveLocalNow() {
    return safeChromeStorageSet(localSnapshot());
  }

  const saveLocal = debounce(() => {
    saveLocalNow();
  }, 80);

  function globalSnapshot() {
    return {
      [globalKey]: {
        enabled: state.enabled,
        collapsed: state.collapsed,
        darkMode: state.darkMode,
        theme: state.theme,
        position: state.position,
        bubblePosition: state.bubblePosition
      }
    };
  }

  function saveGlobalNow() {
    return safeChromeStorageSet(globalSnapshot());
  }

  const saveGlobal = debounce(() => {
    saveGlobalNow();
  }, 80);

  function debounce(fn, delay) {
    let timer;
    return (...args) => {
      clearTimeout(timer);
      timer = setTimeout(() => fn(...args), delay);
    };
  }

  function el(tag, attrs = {}, children = []) {
    const node = document.createElement(tag);
    for (const [key, value] of Object.entries(attrs)) {
      if (key === 'class') node.className = value;
      else if (key === 'text') node.textContent = value;
      else if (key === 'html') node.innerHTML = value;
      else if (key.startsWith('on') && typeof value === 'function') node.addEventListener(key.slice(2), value);
      else node.setAttribute(key, value);
    }
    for (const child of children) node.append(child);
    return node;
  }

  function sectionIntro(title, description) {
    const children = [el('div', { class: 'eht-mini-title', text: title })];
    if (description) children.push(el('div', { class: 'eht-hint', text: description }));
    return el('div', { class: 'eht-section-intro' }, children);
  }

  function render() {
    document.getElementById(APP_ID)?.remove();
    document.getElementById(`${APP_ID}-bubble`)?.remove();

    if (!state.enabled) return renderBubble(false);
    if (state.collapsed) return renderBubble(true);

    const root = el('section', {
      id: APP_ID,
      class: 'eht-panel',
      style: `right:${state.position.right}px;top:${state.position.top}px;`
    });
    applyThemeToNode(root);

    const header = el('div', { class: 'eht-header' }, [
      el('img', { class: 'eht-logo', src: chrome.runtime.getURL('assets/icon48.png'), alt: TEXT.shortName }),
      el('div', { class: 'eht-title-wrap' }, [
        el('div', { class: 'eht-kicker', text: TEXT.name }),
        el('div', { class: 'eht-title', text: TEXT.panelTitle }),
        TEXT.panelSubtitle ? el('div', { class: 'eht-header-subtitle', text: TEXT.panelSubtitle }) : document.createTextNode('')
      ]),
      el('img', { class: 'eht-theme-corner-art', src: themeAssetUrl(), alt: '' }),
      el('div', { class: 'eht-header-actions' }, [
        el('button', { class: 'eht-icon-btn', title: '빠른 실행', onclick: openCommandPalette }, ['⌘']),
        el('button', { class: 'eht-icon-btn', title: TEXT.randomButton, onclick: rerollWarning }, ['⚠️']),
        el('button', { class: 'eht-icon-btn', title: TEXT.closeButton, onclick: collapsePanel }, ['—'])
      ])
    ]);

    makeDraggable(root, header);

    const warning = el('button', { class: 'eht-warning', onclick: rerollWarning }, [WARNINGS[state.warningIndex]]);
    const visibleTabs = ['home', 'check', 'timeline', 'notes', 'snippet', 'palette', 'theme', 'bgm', 'quality', 'pageSearch', 'save', 'support'];
    const allowedTabs = [...visibleTabs, 'badges', 'diagnostics', 'backupTools', 'guide', 'updateHub', 'settings', 'codeVault', 'coord', 'tips', 'guard'];
    if (!allowedTabs.includes(state.tab)) state.tab = 'home';

    const tabs = el('div', { class: 'eht-tabs' }, [
      tabButton('home', TEXT.tabs.home),
      tabButton('check', TEXT.tabs.check),
      tabButton('timeline', TEXT.tabs.timeline),
      tabButton('notes', TEXT.tabs.notes),
      tabButton('snippet', TEXT.tabs.snippet),
      tabButton('palette', TEXT.tabs.palette),
      tabButton('theme', TEXT.tabs.theme),
      tabButton('bgm', 'BGM'),
      tabButton('quality', '화질'),
      tabButton('pageSearch', TEXT.tabs.pageSearch),
      tabButton('save', TEXT.tabs.save),
      tabButton('support', TEXT.tabs.support)
    ]);

    const body = el('div', { class: 'eht-body' }, [renderTabBody()]);
    const footer = el('div', { class: 'eht-footer' }, [
      el('span', { text: projectKey.replace(/^project:/, '프로젝트: ').replace(/^page:/, '페이지: ') }),
      el('button', { class: 'eht-link-btn', onclick: resetCurrentProject }, [TEXT.resetButton])
    ]);

    root.append(header, warning, tabs, body, footer, renderCommandPalette());
    document.documentElement.append(root);
  }


  function ensureBubblePosition() {
    if (!state.bubblePosition || typeof state.bubblePosition !== 'object') {
      state.bubblePosition = { right: 18, bottom: 94 };
    }
    state.bubblePosition.right = Number.isFinite(Number(state.bubblePosition.right)) ? Number(state.bubblePosition.right) : 18;
    state.bubblePosition.bottom = Number.isFinite(Number(state.bubblePosition.bottom)) ? Number(state.bubblePosition.bottom) : 94;
    if (!state.__bubbleLiftMigrated) {
      const nearOldDefault = Math.abs(Number(state.bubblePosition.right) - 18) <= 2 && Math.abs(Number(state.bubblePosition.bottom) - 18) <= 4;
      if (nearOldDefault) state.bubblePosition.bottom = 94;
      state.__bubbleLiftMigrated = true;
    }
    return state.bubblePosition;
  }

  function bubblePositionStyle() {
    const pos = ensureBubblePosition();
    return `right:${pos.right}px;bottom:${pos.bottom}px;`;
  }

  function setBubblePreset(preset) {
    const margin = 18;
    const liftedBottom = 94;
    const bubbleWidth = 50;
    const bubbleHeight = 50;
    const rightByPreset = preset.includes('left')
      ? Math.max(margin, window.innerWidth - bubbleWidth - margin)
      : margin;
    const bottomByPreset = preset.includes('top')
      ? Math.max(margin, window.innerHeight - bubbleHeight - margin)
      : liftedBottom;
    state.bubblePosition = { right: rightByPreset, bottom: bottomByPreset };
    state.stats = state.stats || {};
    state.stats.bubbleMoves = Number(state.stats.bubbleMoves || 0) + 1;
    saveGlobalNow();
    saveLocalNow();
    toast(`Mini Dock 위치 · ${bubblePresetLabel(preset)}`);
    render();
  }

  function bubblePresetLabel(preset) {
    return ({
      'top-left': '좌상단',
      'top-right': '우상단',
      'bottom-left': '좌하단',
      'bottom-right': '우하단'
    })[preset] || '사용자 지정';
  }

  function renderBubblePositionCard() {
    const pos = ensureBubblePosition();
    return el('div', { class: 'eht-home-card eht-bubble-position-card' }, [
      el('div', { class: 'eht-home-card-head' }, [
        el('strong', { text: 'Mini Dock 위치' }),
        el('span', { text: `${Math.round(pos.right)} / ${Math.round(pos.bottom)}` })
      ]),
      el('div', { class: 'eht-home-card-sub', text: '접힌 상태에서 드래그로 옮기거나, 아래 프리셋으로 바로 이동할 수 있습니다.' }),
      el('div', { class: 'eht-position-grid' }, [
        el('button', { class: 'eht-position-chip', onclick: () => setBubblePreset('top-left') }, ['좌상']),
        el('button', { class: 'eht-position-chip', onclick: () => setBubblePreset('top-right') }, ['우상']),
        el('button', { class: 'eht-position-chip', onclick: () => setBubblePreset('bottom-left') }, ['좌하']),
        el('button', { class: 'eht-position-chip', onclick: () => setBubblePreset('bottom-right') }, ['우하'])
      ])
    ]);
  }


  let bubbleClickSuppressUntil = 0;

  function makeBubbleDraggable(bubble) {
    let startX = 0;
    let startY = 0;
    let startRight = 0;
    let startBottom = 0;
    let dragging = false;
    let moved = false;

    bubble.addEventListener('pointerdown', event => {
      dragging = true;
      moved = false;
      startX = event.clientX;
      startY = event.clientY;
      const rect = bubble.getBoundingClientRect();
      startRight = window.innerWidth - rect.right;
      startBottom = window.innerHeight - rect.bottom;
      try { bubble.setPointerCapture(event.pointerId); } catch {}
      bubble.classList.add('is-dragging');
    });

    bubble.addEventListener('pointermove', event => {
      if (!dragging) return;
      const dx = event.clientX - startX;
      const dy = event.clientY - startY;
      if (Math.abs(dx) > 3 || Math.abs(dy) > 3) moved = true;
      const width = bubble.offsetWidth || 50;
      const height = bubble.offsetHeight || 50;
      const nextRight = clamp(startRight - dx, 8, Math.max(8, window.innerWidth - width - 8));
      const nextBottom = clamp(startBottom - dy, 8, Math.max(8, window.innerHeight - height - 8));
      state.bubblePosition = { right: nextRight, bottom: nextBottom };
      bubble.style.right = `${nextRight}px`;
      bubble.style.bottom = `${nextBottom}px`;
      saveGlobal();
    });

    const finish = event => {
      if (!dragging) return;
      dragging = false;
      bubble.classList.remove('is-dragging');
      try { bubble.releasePointerCapture(event.pointerId); } catch {}
      if (moved) {
        bubbleClickSuppressUntil = Date.now() + 250;
        state.stats = state.stats || {};
        state.stats.bubbleMoves = Number(state.stats.bubbleMoves || 0) + 1;
        saveLocalNow();
      }
    };

    bubble.addEventListener('pointerup', finish);
    bubble.addEventListener('pointercancel', finish);
  }

  function keepBubbleInsideViewport() {
    ensureBubblePosition();
    const margin = 12;
    const width = 50;
    const height = 50;
    state.bubblePosition.right = clamp(state.bubblePosition.right, margin, Math.max(margin, window.innerWidth - width - margin));
    state.bubblePosition.bottom = clamp(state.bubblePosition.bottom, margin, Math.max(margin, window.innerHeight - height - margin));
    const bubble = document.getElementById(`${APP_ID}-bubble`);
    if (bubble) {
      bubble.style.right = `${state.bubblePosition.right}px`;
      bubble.style.bottom = `${state.bubblePosition.bottom}px`;
    }
    saveGlobal();
  }

  function renderBubble(collapsed = true) {
    const id = getThemeId();
    const bubble = el('button', {
      id: `${APP_ID}-bubble`,
      class: `eht-bubble ${collapsed ? '' : 'eht-bubble-disabled'}`,
      title: collapsed ? `${TEXT.panelTitle} 열기` : `${TEXT.panelTitle} 꺼짐`,
      style: bubblePositionStyle(),
      onclick: () => {
        if (Date.now() < bubbleClickSuppressUntil) return;
        state.enabled = true;
        state.collapsed = false;
        saveGlobalNow();
        saveLocalNow();
        render();
      }
    }, [
      el('span', { class: 'eht-bubble-dock' }, [
        el('span', { class: 'eht-bubble-mark' }, [
          el('img', { class: 'eht-bubble-logo', src: chrome.runtime.getURL('assets/icon48.png'), alt: TEXT.shortName })
        ]),
        el('span', { class: 'eht-bubble-copy' }, [
          el('strong', { text: collapsed ? 'Radiance' : 'OFF' }),
          el('span', { text: collapsed ? '열기' : '꺼짐' })
        ]),
        el('i', { class: 'eht-bubble-status' })
      ])
    ]);
    bubble.dataset.radianceTheme = id;
    document.documentElement.append(bubble);
    makeBubbleDraggable(bubble);
  }

  function tabButton(id, label) {
    return el('button', {
      class: `eht-tab ${state.tab === id ? 'is-active' : ''}`,
      onclick: () => switchTab(id)
    }, [label]);
  }

  function renderTabBody() {
    if (state.tab === 'home') return renderHome();
    if (state.tab === 'coord') return renderCoords();
    if (state.tab === 'timeline') return renderTimeline();
    if (state.tab === 'notes') return renderNotes();
    if (state.tab === 'snippet') return renderSnippets();
    if (state.tab === 'palette') return renderPalette();
    if (state.tab === 'theme') return renderThemeKit();
    if (state.tab === 'bgm') return renderBgmRoom();
    if (state.tab === 'quality') return renderQualityBoost();
    if (state.tab === 'codeVault') return renderCodeVault();
    if (state.tab === 'tips') return renderTips();
    if (state.tab === 'badges') return renderBadges();
    if (state.tab === 'settings') return renderSettings();
    if (state.tab === 'bridge') return renderBridge();
    if (state.tab === 'pageSearch') return renderPageSearch();
    if (state.tab === 'save') return renderSaveClicker();
    if (state.tab === 'diagnostics') return renderDiagnostics();
    if (state.tab === 'backupTools') return renderBackupTools();
    if (state.tab === 'guide') return renderGuide();
    if (state.tab === 'updateHub') return renderUpdateHub();
    if (state.tab === 'support') return renderSupportCenter();
    if (state.tab === 'guard') return renderLeaveGuard();
    return renderChecklist();
  }

  function renderHome() {
    const checkedCount = CHECKLIST.filter((_, i) => state.checklist[i]).length;
    const progress = Math.round((checkedCount / CHECKLIST.length) * 100);
    const backup = ensureBackupState();
    const page = ensurePageSearchState();
    const workspace = detectWorkspace();
    const timelineCount = timelineLines(state.timeline).length;
    const notesLength = (state.notes || '').trim().length;
    const snippetLength = (state.customSnippets || '').trim().length;
    const lastBackup = backup.lastBackupAt ? new Date(backup.lastBackupAt).toLocaleTimeString() : '아직 없음';

    return el('div', { class: 'eht-section eht-home-section' }, [
      el('div', { class: 'eht-home-hero' }, [
        el('div', { class: 'eht-home-kicker', text: `현재 테마 · ${getThemeLabel()}` }),
        el('div', { class: 'eht-home-title', text: 'Radiance 작업실' }),
        el('div', { class: 'eht-home-subtitle', text: workspace.ok ? '엔트리 작업 화면 감지됨' : '현재 페이지에서 사용 가능한 도구를 모았습니다.' }),
        el('div', { class: 'eht-action-row eht-wrap-row eht-home-actions' }, [
          el('button', { class: 'eht-main-btn', onclick: () => switchTab('notes') }, ['메모 열기']),
          el('button', { class: 'eht-link-btn', onclick: () => switchTab('pageSearch') }, ['페이지 검색']),
          el('button', { class: 'eht-link-btn', onclick: () => createInternalBackup('manual') }, ['지금 백업']),
          el('button', { class: 'eht-link-btn', onclick: () => switchTab('palette') }, ['팔레트']),
          el('button', { class: 'eht-link-btn', onclick: () => switchTab('theme') }, ['테마']),
          el('button', { class: 'eht-link-btn', onclick: () => switchTab('bgm') }, ['BGM']),
          el('button', { class: 'eht-link-btn', onclick: () => switchTab('quality') }, ['화질']),
          el('button', { class: 'eht-link-btn', onclick: () => switchTab('guide') }, ['사용설명서']),
          el('button', { class: 'eht-link-btn', onclick: () => switchTab('updateHub') }, ['업데이트']),
          el('button', { class: 'eht-link-btn', onclick: () => switchTab('support') }, ['지원'])
        ])
      ]),

      renderQuickThemeBar(),

      renderBubblePositionCard(),

      el('div', { class: 'eht-home-grid' }, [
        homeStatCard('점검률', `${progress}%`, `${checkedCount}/${CHECKLIST.length} 완료`, 'check'),
        homeStatCard('타임라인', `${timelineCount}줄`, timelineCount ? '큐 기록 있음' : '아직 비어 있음', 'timeline'),
        homeStatCard('메모', `${notesLength}자`, notesLength ? '작성 중' : '메모 없음', 'notes'),
        homeStatCard('백업', `${backup.items?.length || 0}개`, `최근: ${lastBackup}`, 'save')
      ]),

      el('div', { class: 'eht-save-card eht-home-card' }, [
        el('div', { class: 'eht-mini-title', text: '빠른 실행' }),
        el('div', { class: 'eht-home-launch-list' }, [
          homeLaunchButton('체크리스트', '실행 전 점검', 'check'),
          homeLaunchButton('타임라인', '타이포 큐 정리', 'timeline'),
          homeLaunchButton('스니펫', `${snippetLength}자 저장됨`, 'snippet'),
          homeLaunchButton('배지', '진행도 확인', 'badges'),
          homeLaunchButton('백업', backup.autoEnabled ? '자동 백업 ON' : '자동 백업 OFF', 'save'),
          homeLaunchButton('진단', '상태 확인', 'diagnostics'),
          homeLaunchButton('데이터', '내보내기/복원', 'backupTools')
        ])
      ]),

      el('div', { class: 'eht-save-card eht-home-tip' }, [
        el('div', { class: 'eht-mini-title', text: '오늘의 제작 팁' }),
        el('div', { class: 'eht-home-tip-text', text: WARNINGS[state.warningIndex] || '작게 만들고 자주 테스트하면 버그가 빨리 잡힙니다.' }),
        el('div', { class: 'eht-action-row eht-wrap-row' }, [
          el('button', { class: 'eht-link-btn', onclick: rerollWarning }, ['다른 팁']),
          el('button', { class: 'eht-link-btn', onclick: () => copyText(WARNINGS[state.warningIndex] || '', TEXT.copiedToast) }, ['팁 복사'])
        ])
      ])
    ]);
  }

  function homeStatCard(label, value, sub, tab) {
    return el('button', { class: 'eht-home-stat', onclick: () => switchTab(tab) }, [
      el('span', { text: label }),
      el('strong', { text: value }),
      el('em', { text: sub })
    ]);
  }

  function homeLaunchButton(title, sub, tab) {
    return el('button', { class: 'eht-home-launch', onclick: () => switchTab(tab) }, [
      el('strong', { text: title }),
      el('span', { text: sub })
    ]);
  }

  function switchTab(tab) {
    state.tab = tab;
    state.stats = state.stats || {};
    state.stats[`tab:${tab}`] = Number(state.stats[`tab:${tab}`] || 0) + 1;
    refreshBadges(true);
    saveLocalNow();
    render();
  }


  function renderChecklist() {
    const checkedCount = CHECKLIST.filter((_, i) => state.checklist[i]).length;
    const progress = Math.round((checkedCount / CHECKLIST.length) * 100);
    return el('div', { class: 'eht-section' }, [
      sectionIntro(TEXT.checkTitle, TEXT.checkDescription),
      el('div', { class: 'eht-progress-row' }, [
        el('strong', { text: `${TEXT.progressLabel} ${progress}%` }),
        el('button', { class: 'eht-link-btn', onclick: clearChecklist }, [TEXT.clearChecks])
      ]),
      el('div', { class: 'eht-progress' }, [
        el('div', { class: 'eht-progress-fill', style: `width:${progress}%` })
      ]),
      ...CHECKLIST.map((item, index) => {
        const id = `eht-check-${index}`;
        const input = el('input', {
          type: 'checkbox',
          id,
          ...(state.checklist[index] ? { checked: 'checked' } : {}),
          onchange: event => {
            state.checklist[index] = event.target.checked;
            saveLocal();
            updateChecklistProgress();
            refreshBadges(true);
          }
        });
        return el('label', { class: 'eht-check-item', for: id }, [input, el('span', { text: item.text })]);
      })
    ]);
  }

  function updateChecklistProgress() {
    const checkedCount = CHECKLIST.filter((_, i) => state.checklist[i]).length;
    const progress = Math.round((checkedCount / CHECKLIST.length) * 100);
    const row = document.querySelector(`#${APP_ID} .eht-progress-row strong`);
    const fill = document.querySelector(`#${APP_ID} .eht-progress-fill`);
    if (row) row.textContent = `${TEXT.progressLabel} ${progress}%`;
    if (fill) fill.style.width = `${progress}%`;
  }

  function renderCoords() {
    const customX = el('input', { class: 'eht-input', type: 'number', value: '0', min: '-999', max: '999', step: '1' });
    const customY = el('input', { class: 'eht-input', type: 'number', value: '0', min: '-999', max: '999', step: '1' });
    const result = el('div', { class: 'eht-coordinate-result', text: `${TEXT.xLabel} 0 / ${TEXT.yLabel} 0` });
    const hint = el('div', { class: 'eht-hint', text: TEXT.stageHint });

    const update = () => {
      const x = Number(customX.value || 0);
      const y = Number(customY.value || 0);
      const outside = x < -240 || x > 240 || y < -120 || y > 120;
      result.textContent = `${TEXT.xLabel} ${x} / ${TEXT.yLabel} ${y}${outside ? '  ⚠️ ' + TEXT.outsideWarning : ''}`;
      result.classList.toggle('is-danger', outside);
    };
    customX.addEventListener('input', update);
    customY.addEventListener('input', update);

    return el('div', { class: 'eht-section' }, [
      sectionIntro(TEXT.coordsTitle, TEXT.coordsDescription),
      el('div', { class: 'eht-grid' }, COORD_PRESETS.map(preset =>
        el('div', { class: 'eht-preset-card' }, [
          el('strong', { text: preset.label }),
          el('span', { text: `x:${preset.x} / y:${preset.y}` }),
          el('div', { class: 'eht-preset-actions' }, [
            el('button', { class: 'eht-link-btn', onclick: () => { bumpStat('coordCopies'); copyText(`x:${preset.x}, y:${preset.y}`, `${preset.label} ${TEXT.copiedToast}`); } }, [TEXT.copyButton]),
            el('button', { class: 'eht-link-btn', onclick: () => { bumpStat('coordInserts'); insertIntoTarget(`x:${preset.x}, y:${preset.y}`); } }, [TEXT.insertButton])
          ])
        ])
      )),
      renderTargetMini(),
      el('div', { class: 'eht-mini-title', text: TEXT.customCoords }),
      el('div', { class: 'eht-inline-fields eht-wrap-row' }, [
        el('label', { text: TEXT.xLabel }), customX,
        el('label', { text: TEXT.yLabel }), customY,
        el('button', { class: 'eht-main-btn', onclick: () => { bumpStat('coordCopies'); copyText(`x:${customX.value || 0}, y:${customY.value || 0}`, TEXT.copiedToast); } }, [TEXT.copyButton]),
        el('button', { class: 'eht-main-btn', onclick: () => { bumpStat('coordInserts'); insertIntoTarget(`x:${customX.value || 0}, y:${customY.value || 0}`); } }, [TEXT.insertButton])
      ]),
      el('div', { class: 'eht-action-row eht-wrap-row' }, [
        el('button', { class: 'eht-link-btn', onclick: () => insertIntoTarget(String(customX.value || 0)) }, [`${TEXT.xLabel}만 ${TEXT.insertButton}`]),
        el('button', { class: 'eht-link-btn', onclick: () => insertIntoTarget(String(customY.value || 0)) }, [`${TEXT.yLabel}만 ${TEXT.insertButton}`])
      ]),
      result,
      hint
    ]);
  }

  function renderTimeline() {
    const area = el('textarea', {
      class: 'eht-textarea eht-timeline',
      placeholder: TEXT.timelinePlaceholder,
      spellcheck: 'false'
    });
    area.value = state.timeline || '';

    const meta = el('div', { class: 'eht-timeline-meta' });
    const preview = el('div', { class: 'eht-timeline-preview' });

    const updateTimelineUi = () => {
      state.timeline = area.value;
      renderTimelineMeta(meta, area.value);
      renderTimelinePreview(preview, area.value);
      refreshBadges(false);
    };

    area.addEventListener('input', () => {
      updateTimelineUi();
      saveLocal();
    });

    updateTimelineUi();

    return el('div', { class: 'eht-section eht-timeline-section' }, [
      sectionIntro(TEXT.timelineTitle, TEXT.timelineDescription),
      el('div', { class: 'eht-timeline-board' }, [
        meta,
        el('div', { class: 'eht-action-row eht-timeline-actions' }, [
          el('button', { class: 'eht-main-btn', onclick: () => { addTimelineStamp(area); updateTimelineUi(); } }, [TEXT.addLineButton]),
          el('button', { class: 'eht-main-btn', onclick: () => { sortTimeline(area); updateTimelineUi(); } }, [TEXT.sortButton]),
          el('button', { class: 'eht-main-btn', onclick: () => copyText(area.value, TEXT.copiedToast) }, [TEXT.copyButton])
        ]),
        area,
        el('div', { class: 'eht-hint eht-timeline-hint', text: TEXT.timelineHint }),
        preview
      ])
    ]);
  }

  function timelineLines(value) {
    return (value || '').split('\n').map(line => line.trim()).filter(Boolean);
  }

  function formatCueTime(seconds) {
    if (!Number.isFinite(seconds)) return '--';
    const min = Math.floor(seconds / 60);
    const sec = seconds - min * 60;
    return min > 0 ? `${min}:${sec.toFixed(1).padStart(4, '0')}s` : `${sec.toFixed(1)}s`;
  }

  function renderTimelineMeta(container, value) {
    container.replaceChildren();
    const lines = timelineLines(value);
    const parsed = lines.map(parseSeconds).filter(Number.isFinite).sort((a, b) => a - b);
    const first = parsed.length ? formatCueTime(parsed[0]) : '--';
    const last = parsed.length ? formatCueTime(parsed[parsed.length - 1]) : '--';
    container.append(
      el('div', { class: 'eht-timeline-chip' }, [el('strong', { text: String(lines.length) }), el('span', { text: '큐' })]),
      el('div', { class: 'eht-timeline-chip' }, [el('strong', { text: first }), el('span', { text: '시작' })]),
      el('div', { class: 'eht-timeline-chip' }, [el('strong', { text: last }), el('span', { text: '마지막' })])
    );
  }

  function renderTimelinePreview(container, value) {
    container.replaceChildren();
    const lines = timelineLines(value);
    if (!lines.length) {
      container.append(el('div', { class: 'eht-timeline-empty', text: '타임라인을 적으면 아래에 큐 미리보기가 생깁니다.' }));
      return;
    }
    container.append(el('div', { class: 'eht-mini-title', text: '큐 미리보기' }));
    const visible = lines.slice(0, 7);
    for (const line of visible) {
      const seconds = parseSeconds(line);
      const body = line.replace(/^(?:(\d+):)?\d+(?:\.\d+)?\s*s?\s*/i, '').trim() || line;
      container.append(el('div', { class: 'eht-cue-row eht-cue-row-plus' }, [
        el('span', { class: 'eht-cue-time', text: formatCueTime(seconds) }),
        el('span', { class: 'eht-cue-body', text: body }),
        el('div', { class: 'eht-cue-actions' }, [
          el('button', { class: 'eht-link-btn', onclick: () => copyText(line, TEXT.copiedToast) }, [TEXT.copyButton]),
          el('button', { class: 'eht-link-btn', onclick: () => insertIntoTarget(body) }, [TEXT.insertButton])
        ])
      ]));
    }
    if (lines.length > visible.length) {
      container.append(el('div', { class: 'eht-timeline-more', text: `+${lines.length - visible.length}개 더 있음` }));
    }
  }

  function addTimelineStamp(area) {
    const now = new Date();
    const stamp = `${String(now.getMinutes()).padStart(2, '0')}.${String(now.getSeconds()).padStart(2, '0')}s  [텍스트]  x:0 y:0 size:35 fade`;
    area.value = area.value ? `${area.value}
${stamp}` : stamp;
    state.timeline = area.value;
    saveLocal();
  }

  function parseSeconds(line) {
    const match = line.trim().match(/^(?:(\d+):)?(\d+(?:\.\d+)?)\s*s?/i);
    if (!match) return Number.POSITIVE_INFINITY;
    const min = Number(match[1] || 0);
    const sec = Number(match[2] || 0);
    return min * 60 + sec;
  }

  function sortTimeline(area) {
    const lines = area.value.split('\n').filter(line => line.trim().length > 0);
    lines.sort((a, b) => parseSeconds(a) - parseSeconds(b));
    area.value = lines.join('\n');
    state.timeline = area.value;
    saveLocal();
    toast(`${TEXT.sortButton}됨`);
  }

  function renderNotes() {
    const area = el('textarea', {
      class: 'eht-textarea eht-notes',
      placeholder: TEXT.notesPlaceholder
    });
    area.value = state.notes || '';

    const counter = el('div', { class: 'eht-note-counter' });
    const updateNoteCounter = () => {
      const text = area.value || '';
      const chars = text.length;
      const lines = text ? text.split('\n').length : 0;
      counter.textContent = `${lines}줄 · ${chars}자`;
    };

    area.addEventListener('input', () => {
      state.notes = area.value;
      updateNoteCounter();
      refreshBadges(false);
      saveLocal();
    });
    updateNoteCounter();

    return el('div', { class: 'eht-section eht-notes-section' }, [
      sectionIntro(TEXT.notesTitle, TEXT.notesDescription),
      el('div', { class: 'eht-note-pad' }, [
        el('div', { class: 'eht-note-toolbar' }, [
          el('div', { class: 'eht-note-label', text: '자유 메모장' }),
          counter
        ]),
        area,
        el('div', { class: 'eht-action-row eht-note-actions' }, [
          el('button', { class: 'eht-main-btn', onclick: () => copyText(area.value, TEXT.copiedToast) }, [TEXT.copyButton]),
          el('button', { class: 'eht-main-btn', onclick: () => exportProjectData() }, [TEXT.backupJson])
        ])
      ])
    ]);
  }


  function copySnippetBody(snippet) {
    bumpStat('snippetCopies');
    copyText(snippet.body, `${snippet.title} ${TEXT.copiedToast}`);
  }

  function insertSnippetBody(snippet) {
    const ok = insertIntoTarget(snippet.body);
    if (ok) bumpStat('snippetInserts');
  }

  function appendToNotes(text, label = '스니펫') {
    const prefix = state.notes && state.notes.trim() ? '\n\n' : '';
    state.notes = `${state.notes || ''}${prefix}[${label}]\n${text}`;
    bumpStat('snippetToNotes');
    saveLocalNow();
    toast('메모에 추가됨');
  }

  function appendToTimeline(text, label = '스니펫') {
    const lines = String(text || '').split('\n').filter(Boolean);
    const timelineText = lines.map((line, index) => {
      if (/^(?:(\d+):)?\d+(?:\.\d+)?\s*s?\s+/i.test(line.trim())) return line;
      return `${index.toFixed(1)}s  ${line}`;
    }).join('\n');
    const prefix = state.timeline && state.timeline.trim() ? '\n' : '';
    state.timeline = `${state.timeline || ''}${prefix}${timelineText}`;
    bumpStat('snippetToTimeline');
    saveLocalNow();
    toast(`${label} 타임라인 추가됨`);
  }

  function snippetToBridgeJson(snippet, packId = 'snippet') {
    const items = String(snippet.body || '').split('\n').filter(Boolean).map((line, index) => {
      const seconds = parseSeconds(line);
      const text = line.replace(/^(?:(\d+):)?\d+(?:\.\d+)?\s*s?\s*/i, '').trim() || line;
      return {
        id: `${packId}-${index}`,
        time: Number.isFinite(seconds) ? Number(seconds.toFixed(1)) : '',
        text
      };
    });
    return JSON.stringify({ type: 'radiance-snippet-bridge', source: snippet.title, items }, null, 2);
  }

  function sendSnippetToBridge(snippet, packId = 'snippet') {
    state.bridgeJson = snippetToBridgeJson(snippet, packId);
    state.bridgeActiveIndex = 0;
    bumpStat('snippetToBridge');
    saveLocalNow();
    toast('Bridge로 보냄');
    switchTab('bridge');
  }

  function makeBridgeFromSnippetPack(pack) {
    const items = pack.snippets.map((snippet, index) => ({
      id: `${pack.id}-${index}`,
      time: index === 0 ? '00.0' : `${(index * 1.2).toFixed(1)}`,
      text: snippet.title,
      note: snippet.body,
      scene: pack.title,
      effect: index === 0 ? 'fade-in' : 'slide-up'
    }));
    return JSON.stringify({ type: 'radiance-snippet-pack', pack: pack.id, items }, null, 2);
  }

  function useSnippetPack(packId, mode = 'copy') {
    const pack = SNIPPET_PACKS.find(item => item.id === packId);
    if (!pack) return;
    const text = pack.snippets.map(snippet => `[${snippet.title}]\n${snippet.body}`).join('\n\n');
    bumpStat('snippetPackUses');
    if (mode === 'notes') appendToNotes(text, pack.title);
    else if (mode === 'timeline') appendToTimeline(text, pack.title);
    else if (mode === 'bridge') {
      state.bridgeJson = makeBridgeFromSnippetPack(pack);
      state.bridgeActiveIndex = 0;
      saveLocalNow();
      toast(`${pack.title} Bridge 생성`);
      switchTab('bridge');
    } else copyText(text, `${pack.title} 복사됨`);
  }

  function bridgeProgress(items = parseBridgeItems(state.bridgeJson).items) {
    const total = items.length;
    const done = items.filter(item => state.bridgeDone[item.id]).length;
    const percent = total ? Math.round((done / total) * 100) : 0;
    return { total, done, percent };
  }

  function copyBridgeQueueText() {
    const { items } = parseBridgeItems(state.bridgeJson);
    if (!items.length) {
      toast('복사할 Bridge 큐가 없습니다.');
      return;
    }
    const text = items.map((item, index) => `${index + 1}. ${bridgeLine(item)}`).join('\n');
    bumpStat('bridgeQueueCopies');
    copyText(text, 'Bridge 큐 복사 완료');
  }

  function markAllBridgeDone() {
    const { items } = parseBridgeItems(state.bridgeJson);
    if (!items.length) return;
    items.forEach(item => { state.bridgeDone[item.id] = true; });
    bumpStat('bridgeQueueCompletions');
    saveLocalNow();
    render();
  }

  function clearBridgeDone() {
    state.bridgeDone = {};
    saveLocalNow();
    render();
  }

  function sendCurrentBridgeToNotes() {
    const { items } = parseBridgeItems(state.bridgeJson);
    if (!items.length) {
      toast('현재 큐가 없습니다.');
      return;
    }
    const index = clamp(state.bridgeActiveIndex || 0, 0, items.length - 1);
    appendToNotes(bridgeLine(items[index]), `Bridge 큐 ${index + 1}`);
  }

  function fillBridgeWithSnippetPack(area, onUpdate, packId = 'typo') {
    const pack = SNIPPET_PACKS.find(item => item.id === packId) || SNIPPET_PACKS[0];
    area.value = makeBridgeFromSnippetPack(pack);
    state.bridgeJson = area.value;
    state.bridgeActiveIndex = 0;
    bumpStat('snippetPackUses');
    onUpdate?.();
    toast(`${pack.title} Bridge 예시 생성`);
  }


  function renderSnippets() {
    const custom = el('textarea', {
      class: 'eht-textarea eht-custom-snippet',
      placeholder: TEXT.snippetsPlaceholder
    });
    custom.value = state.customSnippets || '';
    custom.addEventListener('input', () => {
      state.customSnippets = custom.value;
      refreshBadges(false);
      saveLocal();
    });

    return el('div', { class: 'eht-section eht-snippet-section' }, [
      sectionIntro(TEXT.snippetsTitle, '자주 쓰는 내 스니펫을 먼저 보여주고, 아래에 기본 스니펫/팩을 정리합니다.'),
      renderTargetMini(),
      el('div', { class: 'eht-status-grid' }, [
        statusChip('내 스니펫', `${(state.customSnippets || '').trim().length}자`, Boolean((state.customSnippets || '').trim())),
        statusChip('기본 스니펫', `${DEFAULT_SNIPPETS.length}개`, true),
        statusChip('스니펫 팩', `${SNIPPET_PACKS.length}개`, true),
        statusChip('입력 대상', getTargetLabel(), Boolean(lastEditableTarget && document.contains(lastEditableTarget)))
      ]),

      el('div', { class: 'eht-mini-title', text: TEXT.mySnippets }),
      custom,
      el('div', { class: 'eht-action-row eht-wrap-row' }, [
        el('button', { class: 'eht-main-btn', onclick: () => { bumpStat('snippetCopies'); copyText(custom.value, TEXT.copiedToast); } }, [TEXT.copyMySnippets]),
        el('button', { class: 'eht-main-btn', onclick: () => { if (insertIntoTarget(custom.value)) bumpStat('snippetInserts'); } }, [TEXT.insertTextButton]),
        el('button', { class: 'eht-link-btn', onclick: () => appendToNotes(custom.value, '내 스니펫') }, ['메모로']),
        el('button', { class: 'eht-link-btn', onclick: () => appendToTimeline(custom.value, '내 스니펫') }, ['타임라인']),
        el('button', { class: 'eht-link-btn', onclick: () => sendSnippetToBridge({ title: '내 스니펫', body: custom.value }, 'custom') }, ['Bridge'])
      ]),
      el('div', { class: 'eht-slim-note', text: '내 스니펫을 맨 위로 올렸습니다. 아래는 프리셋용 기본 스니펫입니다.' }),

      el('div', { class: 'eht-mini-title', text: '기본 스니펫' }),
      ...DEFAULT_SNIPPETS.map(snippet => renderSnippetCard(snippet, 'default')),
      el('div', { class: 'eht-mini-title', text: '스니펫 팩' }),
      ...SNIPPET_PACKS.map(pack =>
        el('div', { class: 'eht-snippet-pack' }, [
          el('div', { class: 'eht-snippet-pack-head' }, [
            el('div', {}, [
              el('strong', { text: pack.title }),
              el('span', { text: `${pack.tag} · ${pack.desc}` })
            ]),
            el('div', { class: 'eht-action-row eht-wrap-row' }, [
              el('button', { class: 'eht-link-btn', onclick: () => useSnippetPack(pack.id, 'copy') }, ['팩 복사']),
              el('button', { class: 'eht-link-btn', onclick: () => useSnippetPack(pack.id, 'notes') }, ['메모로']),
              el('button', { class: 'eht-link-btn', onclick: () => useSnippetPack(pack.id, 'timeline') }, ['타임라인']),
              el('button', { class: 'eht-main-btn', onclick: () => useSnippetPack(pack.id, 'bridge') }, ['Bridge'])
            ])
          ]),
          ...pack.snippets.map(snippet => renderSnippetCard(snippet, pack.id))
        ])
      )
    ]);
  }

function renderSnippetCard(snippet, packId = 'snippet') {
    return el('div', { class: 'eht-snippet-card eht-snippet-card-plus' }, [
      el('div', { class: 'eht-snippet-head' }, [
        el('strong', { text: snippet.title }),
        el('div', { class: 'eht-action-row eht-wrap-row' }, [
          el('button', { class: 'eht-link-btn', onclick: () => copySnippetBody(snippet) }, [TEXT.copyButton]),
          el('button', { class: 'eht-link-btn', onclick: () => insertSnippetBody(snippet) }, [TEXT.insertButton]),
          el('button', { class: 'eht-link-btn', onclick: () => appendToNotes(snippet.body, snippet.title) }, ['메모']),
          el('button', { class: 'eht-link-btn', onclick: () => appendToTimeline(snippet.body, snippet.title) }, ['타임라인']),
          el('button', { class: 'eht-main-btn', onclick: () => sendSnippetToBridge(snippet, packId) }, ['Bridge'])
        ])
      ]),
      el('pre', { text: snippet.body })
    ]);
  }


  function renderTips() {
    return el('div', { class: 'eht-section' }, [
      sectionIntro(TEXT.tipsTitle, TEXT.tipsDescription),
      el('button', { class: 'eht-main-btn eht-full-btn', onclick: rerollWarning }, [TEXT.randomButton]),
      ...WARNINGS.map((tip, index) => el('button', {
        class: `eht-warning eht-tip-list-item ${index === state.warningIndex ? 'is-active' : ''}`,
        onclick: () => {
          state.warningIndex = index;
          saveLocal();
          render();
        }
      }, [tip]))
    ]);
  }

  function renderBridge() {
    const workspace = detectWorkspace();
    const targetLabel = getTargetLabel();
    const bridgeData = parseBridgeItems(state.bridgeJson);
    const items = bridgeData.items;
    if (!Number.isInteger(state.bridgeActiveIndex)) state.bridgeActiveIndex = 0;
    if (items.length) state.bridgeActiveIndex = clamp(state.bridgeActiveIndex, 0, items.length - 1);
    else state.bridgeActiveIndex = 0;

    const insertArea = el('textarea', {
      class: 'eht-textarea eht-bridge-insert',
      placeholder: '현재 입력칸에 넣을 텍스트'
    });
    insertArea.value = state.bridgeInsertText || '';
    insertArea.addEventListener('input', () => {
      state.bridgeInsertText = insertArea.value;
      saveLocal();
    });

    const bridgeArea = el('textarea', {
      class: 'eht-textarea eht-bridge-json',
      placeholder: TEXT.bridgePlaceholder,
      spellcheck: 'false'
    });
    bridgeArea.value = state.bridgeJson || '';

    const jsonStatus = el('div', { class: 'eht-hint' });
    const queue = el('div', { class: 'eht-bridge-queue' });
    const activeBox = el('div', { class: 'eht-bridge-active' });

    const updateBridge = () => {
      state.bridgeJson = bridgeArea.value;
      const parsed = parseBridgeItems(bridgeArea.value);
      if (parsed.items.length) state.bridgeActiveIndex = clamp(state.bridgeActiveIndex || 0, 0, parsed.items.length - 1);
      else state.bridgeActiveIndex = 0;
      renderBridgeActive(activeBox, parsed.items);
      renderBridgeQueue(queue, jsonStatus, bridgeArea.value);
      refreshBadges(false);
      saveLocal();
    };

    bridgeArea.addEventListener('input', updateBridge);
    renderBridgeActive(activeBox, items);
    renderBridgeQueue(queue, jsonStatus, bridgeArea.value);

    return el('div', { class: 'eht-section eht-bridge-section' }, [
      sectionIntro(TEXT.studioTitle, TEXT.studioDescription),
      el('div', { class: 'eht-status-grid' }, [
        statusChip(TEXT.detectWorkspace, workspace.ok ? TEXT.detected : TEXT.notDetected, workspace.ok),
        statusChip(TEXT.currentTarget, targetLabel, Boolean(lastEditableTarget && document.contains(lastEditableTarget))),
        statusChip('큐 진행', `${bridgeProgress(items).done}/${bridgeProgress(items).total}`, Boolean(items.length && bridgeProgress(items).done === bridgeProgress(items).total))
      ]),
      el('div', { class: 'eht-bridge-card' }, [
        el('div', { class: 'eht-mini-title', text: '현재 입력칸 도구' }),
        insertArea,
        el('div', { class: 'eht-action-row eht-wrap-row' }, [
          el('button', { class: 'eht-main-btn', onclick: () => insertIntoTarget(insertArea.value) }, [TEXT.insertTextButton]),
          el('button', { class: 'eht-link-btn', onclick: () => replaceTargetValue(insertArea.value) }, ['덮어쓰기']),
          el('button', { class: 'eht-link-btn', onclick: () => clearTargetValue() }, ['비우기']),
          el('button', { class: 'eht-link-btn', onclick: () => flashTarget() }, ['대상 표시']),
          el('button', { class: 'eht-link-btn', onclick: () => copyText(insertArea.value, TEXT.copiedToast) }, [TEXT.copyButton]),
          el('button', { class: 'eht-link-btn', onclick: () => bringSelectionToArea(insertArea) }, [TEXT.bringSelection])
        ])
      ]),
      sectionIntro(TEXT.bridgeTitle, TEXT.bridgeDescription),
      el('div', { class: 'eht-bridge-card eht-viventry-card' }, [
        bridgeArea,
        el('div', { class: 'eht-action-row eht-wrap-row' }, [
          el('button', { class: 'eht-main-btn', onclick: () => { updateBridge(); toast(TEXT.parseJson); } }, [TEXT.parseJson]),
          el('button', { class: 'eht-link-btn', onclick: () => fillBridgeExample(bridgeArea, updateBridge) }, ['예시']),
          el('button', { class: 'eht-link-btn', onclick: () => timelineToBridge(bridgeArea, updateBridge) }, ['타임라인→Bridge']),
          el('button', { class: 'eht-link-btn', onclick: () => fillBridgeWithSnippetPack(bridgeArea, updateBridge, 'typo') }, ['스니펫팩 예시']),
          el('button', { class: 'eht-link-btn', onclick: () => copyText(bridgeArea.value, TEXT.copiedToast) }, [TEXT.copyButton]),
          el('button', { class: 'eht-link-btn', onclick: copyBridgeQueueText }, ['큐 전체 복사']),
          el('button', { class: 'eht-link-btn', onclick: sendCurrentBridgeToNotes }, ['현재 큐→메모']),
          el('button', { class: 'eht-link-btn', onclick: markAllBridgeDone }, ['전체 완료']),
          el('button', { class: 'eht-link-btn', onclick: clearBridgeDone }, [TEXT.clearDone])
        ]),
        el('div', { class: 'eht-bridge-progress' }, [
          el('strong', { text: `진행률 ${bridgeProgress(items).percent}%` }),
          el('span', { text: ` · ${bridgeProgress(items).done}/${bridgeProgress(items).total} 완료` })
        ]),
        jsonStatus,
        activeBox,
        queue
      ])
    ]);
  }

  

  
  let manualSaveButtonTarget = null;
  let pickingSaveButton = false;

  function pickSaveButtonTarget() {
    pickingSaveButton = true;
    markSaveStatus('watching', '저장 버튼 지정 대기 중', '엔트리의 실제 저장 버튼을 한 번 클릭하세요. Radiance가 그 버튼을 기억합니다.');
    toast('엔트리 저장 버튼을 한 번 클릭해 주세요.');
  }

  function rememberSaveButtonTarget(target) {
    if (!target || isRadianceNode(target)) return false;
    const button = target.closest?.('button, a, [role="button"], div, span') || target;
    if (!(button instanceof HTMLElement) || isRadianceNode(button)) return false;
    manualSaveButtonTarget = button;
    state.saveWatcher = Object.assign(defaultSaveWatcherState(), state.saveWatcher || {});
    state.saveWatcher.manualButtonLabel = getSaveCandidateLabel(button) || button.tagName.toLowerCase();
    state.saveWatcher.manualButtonSetAt = new Date().toISOString();
    markSaveStatus('idle', '저장 버튼 지정됨', `기억한 버튼: ${state.saveWatcher.manualButtonLabel || '저장 버튼'}`);
    saveLocalNow();
    render();
    return true;
  }

  function getPreferredSaveButton() {
    if (manualSaveButtonTarget && document.contains(manualSaveButtonTarget)) return manualSaveButtonTarget;
    return findEntrySaveButton();
  }


  function renderPageSearch() {
    const stateData = ensurePageSearchState();
    const detection = detectPageSearchArea();
    const result = stateData.active ? getPageSearchResult(stateData.query || '') : { total: countLibraryCandidates(), matched: 0, hidden: 0 };

    const input = el('input', {
      class: 'eht-page-search-input',
      type: 'search',
      placeholder: '작품 제목, 설명, 닉네임 등 검색',
      value: stateData.query || ''
    });
    let composingPageSearch = false;
    input.addEventListener('compositionstart', () => { composingPageSearch = true; });
    input.addEventListener('compositionend', () => {
      composingPageSearch = false;
      state.pageSearch.query = input.value;
      saveLocal();
    });
    input.addEventListener('input', () => {
      state.pageSearch.query = input.value;
      saveLocal();
    });
    input.addEventListener('keydown', event => {
      if (event.key === 'Enter' && !composingPageSearch) {
        event.preventDefault();
        state.pageSearch.query = input.value;
        state.pageSearch.active = true;
        saveLocal();
        applyPageSearch();
        render();
      }
      if (event.key === 'Escape') {
        event.preventDefault();
        clearPageSearch();
      }
    });

    return el('div', { class: 'eht-section eht-pageSearch-section' }, [
      sectionIntro('페이지 내부 검색', '현재 페이지에 로딩된 카드/항목/작품을 검색합니다. 입력 후 Enter 또는 검색 적용을 누르세요.'),
      el('div', { class: 'eht-status-grid' }, [
        statusChip('페이지 항목', detection.ok ? '감지됨' : '미확실', detection.ok),
        statusChip('검색 대상', `${result.total}개`, result.total > 0),
        statusChip('일치 항목', stateData.active ? `${result.matched}개` : '대기 중', stateData.active && result.matched > 0),
        statusChip('필터 상태', stateData.active ? 'ON' : 'OFF', Boolean(stateData.active))
      ]),
      el('div', { class: 'eht-save-card eht-pageSearch-card' }, [
        el('div', { class: 'eht-mini-title', text: '페이지 내부 검색' }),
        input,
        el('div', { class: 'eht-inline-hint', text: 'Enter로 검색 / Esc로 필터 해제' }),
        el('div', { class: 'eht-action-row eht-wrap-row' }, [
          el('button', { class: 'eht-main-btn', onclick: () => { state.pageSearch.query = input.value; state.pageSearch.active = true; saveLocal(); applyPageSearch(); render(); } }, ['검색 적용']),
          el('button', { class: 'eht-link-btn', onclick: () => { state.pageSearch.hideNonMatches = !state.pageSearch.hideNonMatches; saveLocal(); applyPageSearch(); render(); } }, [stateData.hideNonMatches ? '흐리게 보기' : '숨기기']),
          el('button', { class: 'eht-link-btn', onclick: clearPageSearch }, ['필터 해제']),
          el('button', { class: 'eht-link-btn', onclick: () => { applyPageSearch(); toast('페이지 내부 검색을 새로고침했습니다.'); } }, ['다시 스캔'])
        ]),
        el('div', { class: 'eht-hint', text: stateData.hideNonMatches ? '필터 모드: 불일치 항목 숨김' : '필터 모드: 불일치 항목 흐리게 표시' })
      ]),
      renderPageSearchPreview()
    ]);
  }

  function ensurePageSearchState() {
    if (!state.pageSearch || typeof state.pageSearch !== 'object') {
      state.pageSearch = defaultPageSearchState();
    }
    state.pageSearch = Object.assign(defaultPageSearchState(), state.pageSearch);
    return state.pageSearch;
  }

  function defaultPageSearchState() {
    return {
      query: '',
      active: false,
      hideNonMatches: true
    };
  }

  function detectPageSearchArea() {
    const path = (location.pathname || '').toLowerCase();
    const text = (document.body?.innerText || '').slice(0, 3000);
    const urlLooks = /storage|bookmark|my|mypage|profile|workspace|project|search|community|ranking|challenge|studio/.test(path);
    const textLooks = /(나의 페이지|페이지 항목|페이지|내 작품|나의 작품|즐겨찾기|좋아요|북마크)/.test(text);
    const cards = countLibraryCandidates();
    return { ok: urlLooks || textLooks || cards >= 3, urlLooks, textLooks, cards };
  }

  function getLibraryCandidates() {
    const selector = [
      'article',
      'li',
      'a[href*="/project"]',
      'a[href*="/entry"]',
      'div[class*="card" i]',
      'div[class*="project" i]',
      'div[class*="item" i]',
      'div[class*="work" i]',
      'div[class*="list" i] > div'
    ].join(',');

    const nodes = Array.from(document.querySelectorAll(selector));
    const result = [];
    const seen = new Set();
    const vw = Math.max(window.innerWidth || 1, 1);
    const vh = Math.max(window.innerHeight || 1, 1);

    for (const node of nodes) {
      if (!(node instanceof HTMLElement)) continue;
      if (isRadianceNode(node)) continue;
      if (node.closest?.(`#${APP_ID}, #${APP_ID}-bubble`)) continue;
      const rect = node.getBoundingClientRect();
      if (rect.width < 90 || rect.height < 45) continue;
      if (rect.width > vw * 0.98 && rect.height > vh * 0.85) continue;
      const text = getLibraryCandidateText(node);
      if (!text || text.length < 2) continue;
      if (text.length > 800) continue;

      const candidate = normalizeLibraryCard(node);
      if (!candidate || seen.has(candidate)) continue;
      seen.add(candidate);
      result.push(candidate);
      if (result.length >= 250) break;
    }

    return result;
  }

  function normalizeLibraryCard(node) {
    let current = node;
    let best = node;
    let depth = 0;
    const vw = Math.max(window.innerWidth || 1, 1);
    const vh = Math.max(window.innerHeight || 1, 1);

    while (current && current instanceof HTMLElement && depth < 4) {
      if (isRadianceNode(current)) break;
      const rect = current.getBoundingClientRect();
      const text = getLibraryCandidateText(current);
      const classKey = `${current.className || ''} ${current.id || ''}`;
      const cardLike = current.matches('article, li, a') || /(card|project|item|work|thumb|list)/i.test(classKey);
      const reasonable = rect.width >= 100 && rect.height >= 55 && rect.width < vw * 0.95 && rect.height < vh * 0.75;
      if (reasonable && cardLike && text && text.length < 800) best = current;
      current = current.parentElement;
      depth += 1;
    }

    return best;
  }

  function getLibraryCandidateText(node) {
    return (node.innerText || node.textContent || node.getAttribute?.('aria-label') || node.getAttribute?.('title') || '')
      .replace(/\s+/g, ' ')
      .trim();
  }

  function countLibraryCandidates() {
    try {
      return getLibraryCandidates().length;
    } catch {
      return 0;
    }
  }

  function getPageSearchResult(query) {
    const cards = getLibraryCandidates();
    const q = normalizeSearchText(query);
    if (!q) return { total: cards.length, matched: 0, hidden: 0 };
    let matched = 0;
    let hidden = 0;
    for (const card of cards) {
      const text = normalizeSearchText(getLibraryCandidateText(card));
      if (text.includes(q)) matched += 1;
      else hidden += 1;
    }
    return { total: cards.length, matched, hidden };
  }

  function normalizeSearchText(value) {
    return String(value || '').toLowerCase().replace(/\s+/g, ' ').trim();
  }

  function applyPageSearch() {
    const search = ensurePageSearchState();
    clearPageSearchClasses(false);
    const query = normalizeSearchText(search.query);
    if (!query) {
      search.active = false;
      saveLocal();
      return;
    }

    search.active = true;
    const cards = getLibraryCandidates();
    let matched = 0;

    for (const card of cards) {
      const text = normalizeSearchText(getLibraryCandidateText(card));
      const ok = text.includes(query);
      card.classList.add('radiance-page-search-card');
      if (ok) {
        matched += 1;
        card.classList.add('radiance-pageSearch-match');
      } else {
        card.classList.add(search.hideNonMatches ? 'radiance-pageSearch-hidden' : 'radiance-pageSearch-dim');
      }
    }

    state.stats.pageSearches = Number(state.stats.pageSearches || 0) + 1;
    saveLocal();
    if (matched === 0) toast('일치하는 페이지 항목이 없습니다.');
    else toast(`${matched}개 항목을 찾았습니다.`);
  }

  function clearPageSearch() {
    ensurePageSearchState().query = '';
    ensurePageSearchState().active = false;
    clearPageSearchClasses(true);
    saveLocalNow();
    render();
  }

  function clearPageSearchClasses(removeMatches = true) {
    document.querySelectorAll?.('.radiance-page-search-card, .radiance-pageSearch-match, .radiance-pageSearch-hidden, .radiance-pageSearch-dim').forEach(node => {
      node.classList.remove('radiance-page-search-card', 'radiance-pageSearch-match', 'radiance-pageSearch-hidden', 'radiance-pageSearch-dim');
    });
  }

  function renderPageSearchPreview() {
    const search = ensurePageSearchState();
    const query = normalizeSearchText(search.query);
    if (!query || !search.active) {
      return el('div', { class: 'eht-save-card' }, [
        el('div', { class: 'eht-mini-title', text: '검색 미리보기' }),
        el('div', { class: 'eht-hint', text: '검색어를 입력하고 “검색 적용”을 누르면 현재 화면의 페이지 카드가 필터링됩니다.' })
      ]);
    }

    const cards = getLibraryCandidates();
    const matches = cards
      .map(card => getLibraryCandidateText(card))
      .filter(text => normalizeSearchText(text).includes(query))
      .slice(0, 8);

    return el('div', { class: 'eht-save-card' }, [
      el('div', { class: 'eht-mini-title', text: '검색 결과 미리보기' }),
      matches.length
        ? el('div', { class: 'eht-pageSearch-preview-list' }, matches.map(text =>
            el('div', { class: 'eht-pageSearch-preview-item', text: text.length > 90 ? text.slice(0, 90) + '…' : text })
          ))
        : el('div', { class: 'eht-hint', text: '미리볼 일치 항목이 없습니다.' })
    ]);
  }


  function renderLeaveGuard() {
    const guard = ensureLeaveGuardState();
    return el('div', { class: 'eht-section eht-guard-section' }, [
      sectionIntro('작업 보호', '작업 보호 감지는 안정화 전까지 봉인했습니다.'),
      el('div', { class: 'eht-status-grid' }, [
        statusChip('보호 상태', '봉인됨', false),
        statusChip('나가기 감지', 'OFF', false),
        statusChip('브라우저 경고', 'OFF', false),
        statusChip('상태 저장', guard.sealed ? '안전 모드' : '안전 모드', true)
      ]),
      el('div', { class: 'eht-save-card eht-guard-card eht-sealed-card' }, [
        el('div', { class: 'eht-sealed-icon', text: '🛡️' }),
        el('div', { class: 'eht-mini-title', text: 'Work Guard Coming Soon..' }),
        el('div', { class: 'eht-hint', text: '이전 작업 보호 감지가 페이지 이동/작업 상태를 과하게 잡는 문제가 있어서, 이번 버전에서는 기능을 봉인했습니다.' }),
        el('div', { class: 'eht-hint', text: '현재는 페이지 검색, 내부 백업, 메모/타임라인 기능 중심으로 안정화합니다.' })
      ])
    ]);
  }

  function ensureLeaveGuardState() {
    if (!state.leaveGuard || typeof state.leaveGuard !== 'object') {
      state.leaveGuard = defaultLeaveGuardState();
    }
    state.leaveGuard = Object.assign(defaultLeaveGuardState(), state.leaveGuard, { enabled: false, dirty: false, sealed: true });
    return state.leaveGuard;
  }

  function defaultLeaveGuardState() {
    return {
      enabled: false,
      dirty: false,
      sealed: true,
      lastDirtyAt: '',
      lastCleanAt: ''
    };
  }

  function renderLeaveGuardToggle() {
    return el('div', { class: 'eht-auto-save-box eht-sealed-card' }, [
      el('div', { class: 'eht-setting-main' }, [
        el('div', { class: 'eht-setting-title' }, [
          el('strong', { text: '작업 보호 봉인됨' }),
          el('span', { class: 'eht-pill', text: 'SEALED' })
        ]),
        el('p', { text: '이 기능은 안정화 후 다시 열 예정입니다.' })
      ])
    ]);
  }

  function markProjectDirty() { return; }

  function markProjectClean() {
    const guard = ensureLeaveGuardState();
    guard.dirty = false;
    guard.enabled = false;
    saveLocalNow();
  }

  let pendingLeaveHref = '';

  function shouldWarnBeforeLeave() { return false; }

  function showLeaveGuardOverlay() {
    toast('작업 보호는 현재 봉인된 기능입니다.');
    return false;
  }

  function setupLeaveGuardListeners() {
    // Work Guard detection is sealed in v1.0.1 to avoid false positives.
    return;
  }


  function renderSaveClicker() {
    const backup = ensureBackupState();
    const last = backup.lastBackupAt ? new Date(backup.lastBackupAt).toLocaleString() : '아직 없음';
    const count = Array.isArray(backup.items) ? backup.items.length : 0;

    return el('div', { class: 'eht-section eht-backup-section' }, [
      sectionIntro('Radiance 내부 백업', '엔트리 작품 자체가 아니라, Radiance 안의 메모/타임라인/체크리스트를 로컬에 백업합니다.'),
      el('div', { class: 'eht-status-grid' }, [
        statusChip('백업 개수', `${count}개`, count > 0),
        statusChip('마지막 백업', last, Boolean(backup.lastBackupAt)),
        statusChip('자동 백업', backup.autoEnabled ? 'ON' : 'OFF', Boolean(backup.autoEnabled)),
        statusChip('백업 위치', '브라우저 로컬', true)
      ]),
      el('div', { class: 'eht-save-card eht-backup-card' }, [
        el('div', { class: 'eht-mini-title', text: '백업 도구' }),
        renderInternalBackupControls(),
        el('div', { class: 'eht-action-row eht-wrap-row' }, [
          el('button', { class: 'eht-main-btn', onclick: () => createInternalBackup('manual') }, ['지금 백업']),
          el('button', { class: 'eht-link-btn', onclick: restoreLatestInternalBackup }, ['최신 복원']),
          el('button', { class: 'eht-link-btn', onclick: copyLatestInternalBackup }, ['최신 복사']),
          el('button', { class: 'eht-link-btn', onclick: clearInternalBackups }, ['백업 비우기'])
        ]),
        el('div', { class: 'eht-hint', text: '최근 12개까지 보관합니다. 브라우저 로컬 저장소라서 확장프로그램을 지우면 같이 사라질 수 있습니다.' })
      ]),
      renderInternalBackupList()
    ]);
  }

  function ensureBackupState() {
    if (!state.internalBackup || typeof state.internalBackup !== 'object') {
      state.internalBackup = defaultInternalBackupState();
    }
    state.internalBackup = Object.assign(defaultInternalBackupState(), state.internalBackup);
    if (!Array.isArray(state.internalBackup.items)) state.internalBackup.items = [];
    return state.internalBackup;
  }

  function defaultInternalBackupState() {
    return {
      autoEnabled: true,
      intervalMinutes: 5,
      lastBackupAt: '',
      items: []
    };
  }

  function renderInternalBackupControls() {
    const backup = ensureBackupState();
    const toggle = el('input', { type: 'checkbox', class: 'eht-switch-input' });
    toggle.checked = Boolean(backup.autoEnabled);
    toggle.addEventListener('change', event => {
      ensureBackupState().autoEnabled = Boolean(event.currentTarget.checked);
      saveLocalNow();
      setupInternalBackupTimer();
      toast(ensureBackupState().autoEnabled ? '내부 자동 백업 켜짐' : '내부 자동 백업 꺼짐');
      render();
    });

    const minutes = el('input', {
      type: 'number',
      min: '1',
      max: '60',
      value: String(backup.intervalMinutes || 5),
      class: 'eht-small-input'
    });
    minutes.addEventListener('input', () => {
      ensureBackupState().intervalMinutes = clamp(Number(minutes.value || 5), 1, 60);
      saveLocalNow();
      setupInternalBackupTimer();
    });

    return el('div', { class: `eht-auto-save-box ${backup.autoEnabled ? 'is-enabled' : ''}` }, [
      el('div', { class: 'eht-save-row' }, [
        el('div', { class: 'eht-setting-main' }, [
          el('div', { class: 'eht-setting-title' }, [
            el('strong', { text: '내부 자동 백업' }),
            el('span', { class: 'eht-pill', text: backup.autoEnabled ? 'ON' : 'OFF' })
          ]),
          el('p', { text: 'Radiance 작업 데이터를 정해진 간격마다 로컬 백업합니다.' })
        ]),
        el('label', { class: 'eht-switch eht-switch-clickable' }, [toggle, el('i')])
      ]),
      el('label', { class: 'eht-save-interval' }, [
        el('span', { text: '간격' }),
        minutes,
        el('span', { text: '분' })
      ])
    ]);
  }

  function renderInternalBackupList() {
    const items = ensureBackupState().items || [];
    if (!items.length) {
      return el('div', { class: 'eht-save-card' }, [
        el('div', { class: 'eht-mini-title', text: '백업 목록' }),
        el('div', { class: 'eht-hint', text: '아직 백업이 없습니다. “지금 백업”을 눌러 첫 백업을 만들어 보세요.' })
      ]);
    }

    return el('div', { class: 'eht-save-card' }, [
      el('div', { class: 'eht-mini-title', text: '최근 백업' }),
      el('div', { class: 'eht-backup-list' }, items.slice(0, 6).map((item, index) =>
        el('div', { class: 'eht-backup-item' }, [
          el('div', { class: 'eht-backup-main' }, [
            el('strong', { text: new Date(item.createdAt).toLocaleString() }),
            el('span', { text: `${item.reason || 'backup'} · 타임라인 ${item.summary?.timelineLines || 0}줄 · 메모 ${item.summary?.notesLength || 0}자` })
          ]),
          el('div', { class: 'eht-action-row eht-wrap-row' }, [
            el('button', { class: 'eht-link-btn', onclick: () => restoreInternalBackup(index) }, ['복원']),
            el('button', { class: 'eht-link-btn', onclick: () => copyText(JSON.stringify(item, null, 2), TEXT.copiedToast) }, ['복사'])
          ])
        ])
      ))
    ]);
  }

  let internalBackupTimer = null;

  function setupInternalBackupTimer() {
    if (internalBackupTimer) {
      clearInterval(internalBackupTimer);
      internalBackupTimer = null;
    }
    const backup = ensureBackupState();
    if (!backup.autoEnabled) return;
    const minutes = clamp(Number(backup.intervalMinutes || 5), 1, 60);
    internalBackupTimer = setInterval(() => createInternalBackup('auto'), minutes * 60 * 1000);
  }

  function makeInternalBackupSnapshot(reason = 'manual') {
    const timeline = state.timeline || '';
    const notes = state.notes || '';
    const customSnippets = state.customSnippets || '';
    const bridgeJson = state.bridgeJson || '';
    return {
      type: 'radiance-internal-backup',
      version: '0.6.9',
      reason,
      projectKey,
      createdAt: new Date().toISOString(),
      data: {
        checklist: state.checklist || {},
        timeline,
        notes,
        customSnippets,
        bridgeJson,
        bridgeDone: state.bridgeDone || {},
        bridgeInsertText: state.bridgeInsertText || '',
        bridgeActiveIndex: state.bridgeActiveIndex || 0,
        badges: state.badges || {},
        stats: state.stats || {},
        theme: state.theme,
        warningIndex: state.warningIndex || 0
      },
      summary: {
        checklistDone: Object.values(state.checklist || {}).filter(Boolean).length,
        timelineLines: timelineLines(timeline).length,
        notesLength: notes.trim().length,
        snippetLength: customSnippets.trim().length,
        bridgeItems: parseBridgeItems(bridgeJson).items.length
      }
    };
  }

  function createInternalBackup(reason = 'manual') {
    const backup = ensureBackupState();
    const snapshot = makeInternalBackupSnapshot(reason);
    const latest = backup.items?.[0];
    snapshot.fingerprint = fingerprintBackup(snapshot);
    if (reason === 'auto' && latest && latest.fingerprint === snapshot.fingerprint) return false;
    backup.items = [snapshot, ...(backup.items || [])].slice(0, 12);
    backup.lastBackupAt = snapshot.createdAt;
    state.stats.internalBackups = Number(state.stats.internalBackups || 0) + 1;
    saveLocal();
    refreshBadges(true);
    if (reason !== 'auto') {
      toast('Radiance 내부 백업 완료');
      render();
    }
    return true;
  }

  function fingerprintBackup(snapshot) {
    try {
      return JSON.stringify({
        checklist: snapshot.data.checklist,
        timeline: snapshot.data.timeline,
        notes: snapshot.data.notes,
        customSnippets: snapshot.data.customSnippets,
        bridgeJson: snapshot.data.bridgeJson
      });
    } catch {
      return String(Date.now());
    }
  }

  function restoreLatestInternalBackup() {
    const items = ensureBackupState().items || [];
    if (!items.length) {
      toast('복원할 백업이 없습니다.');
      return false;
    }
    return restoreInternalBackup(0);
  }

  function restoreInternalBackup(index = 0) {
    const item = ensureBackupState().items?.[index];
    if (!item || !item.data) {
      toast('복원할 백업이 없습니다.');
      return false;
    }
    const ok = confirm('이 백업으로 Radiance 데이터를 복원할까요? 현재 메모/타임라인이 바뀝니다.');
    if (!ok) return false;
    state.checklist = item.data.checklist || {};
    state.timeline = item.data.timeline || '';
    state.notes = item.data.notes || '';
    state.customSnippets = item.data.customSnippets || '';
    state.bridgeJson = item.data.bridgeJson || '';
    state.bridgeDone = item.data.bridgeDone || {};
    state.bridgeInsertText = item.data.bridgeInsertText || '';
    state.bridgeActiveIndex = item.data.bridgeActiveIndex || 0;
    state.badges = item.data.badges || {};
    state.stats = item.data.stats || {};
    if (Number.isFinite(Number(item.data.warningIndex))) state.warningIndex = Number(item.data.warningIndex);
    saveLocal();
    toast('Radiance 백업 복원 완료');
    render();
    return true;
  }

  function copyLatestInternalBackup() {
    const item = ensureBackupState().items?.[0];
    if (!item) {
      toast('복사할 백업이 없습니다.');
      return false;
    }
    copyText(JSON.stringify(item, null, 2), TEXT.copiedToast);
    return true;
  }

  function clearInternalBackups() {
    const ok = confirm('Radiance 내부 백업 목록을 모두 지울까요?');
    if (!ok) return;
    ensureBackupState().items = [];
    ensureBackupState().lastBackupAt = '';
    saveLocal();
    toast('백업을 비웠습니다.');
    render();
  }


  function defaultSaveWatcherState() {
    return {
      status: 'idle',
      message: '대기 중',
      detail: '',
      lastClickAt: '',
      lastSuccessAt: '',
      lastDetectedText: '',
      lastButtonLabel: '',
      watchUntil: 0,
      autoEnabled: false,
      autoMinutes: 5,
      hideEntrySaveUi: true,
      manualButtonLabel: '',
      manualButtonSetAt: ''
    };
  }


  function renderHideEntrySaveUiToggle() {
    const enabled = state.saveWatcher?.hideEntrySaveUi !== false;
    const toggle = el('input', { type: 'checkbox', ...(enabled ? { checked: 'checked' } : {}) });
    toggle.addEventListener('change', event => {
      setHideEntrySaveUi(Boolean(event.target.checked));
      toast(Boolean(event.target.checked) ? '엔트리 저장 UI 숨김' : '엔트리 저장 UI 표시');
    });

    return el('div', { class: 'eht-auto-save-box eht-hide-save-ui-box' }, [
      el('div', { class: 'eht-save-row' }, [
        el('div', { class: 'eht-setting-main' }, [
          el('div', { class: 'eht-setting-title' }, [
            el('strong', { text: '엔트리 저장 UI 숨기기' }),
            el('span', { class: 'eht-pill', text: '권장' })
          ]),
          el('p', { text: '저장 중/저장 완료 팝업은 숨기고, Radiance 패널에서만 상태를 보여줍니다.' })
        ]),
        el('span', { class: 'eht-switch' }, [toggle, el('i')])
      ])
    ]);
  }

  function setHideEntrySaveUi(enabled) {
    state.saveWatcher = Object.assign(defaultSaveWatcherState(), state.saveWatcher || {});
    state.saveWatcher.hideEntrySaveUi = Boolean(enabled);
    if (!state.saveWatcher.hideEntrySaveUi) clearHiddenEntrySaveUi();
    else hideEntrySaveUiCandidates();
    saveLocalNow();
    render();
  }

  function clearHiddenEntrySaveUi() {
    document.querySelectorAll?.('.radiance-entry-save-ui-hidden').forEach(node => {
      node.classList.remove('radiance-entry-save-ui-hidden');
    });
  }

  function hideEntrySaveUiCandidates() {
    if (!state.saveWatcher?.hideEntrySaveUi) return;
    const nodes = Array.from(document.querySelectorAll('div, span, p, strong, em, small, button, [role="alert"], [aria-live]'));
    for (const node of nodes) {
      if (!(node instanceof HTMLElement)) continue;
      if (isRadianceNode(node)) continue;
      const text = (node.innerText || node.textContent || '').replace(/\s+/g, ' ').trim();
      if (!isEntrySaveStatusText(text)) continue;
      const target = findEntrySaveUiContainer(node);
      if (!target || isRadianceNode(target)) continue;
      target.classList.add('radiance-entry-save-ui-hidden');
    }
  }

  function isEntrySaveStatusText(text) {
    if (!text || text.length > 90) return false;
    if (/^(저장|저장하기|Radiance 백업|프로젝트 저장|save)$/i.test(text)) return false;
    return /(저장\s*중|저장되었습니다|저장 완료|저장완료|저장됨|저장했어요|저장 성공|saving|saved|save complete|saved successfully)/i.test(text);
  }

  function findEntrySaveUiContainer(node) {
    let current = node;
    let best = node;
    let depth = 0;
    const vw = Math.max(window.innerWidth || 1, 1);
    const vh = Math.max(window.innerHeight || 1, 1);

    while (current && current instanceof HTMLElement && depth < 5) {
      if (isRadianceNode(current)) break;
      const rect = current.getBoundingClientRect();
      const style = window.getComputedStyle(current);
      const classKey = `${current.className || ''} ${current.id || ''}`;
      const toastLike = /(toast|snack|alert|popup|modal|layer|notice|tooltip|save)/i.test(classKey);
      const floating = ['fixed', 'absolute', 'sticky'].includes(style.position);
      const smallEnough = rect.width > 0 && rect.height > 0 && rect.width < Math.min(520, vw * 0.8) && rect.height < Math.min(220, vh * 0.35);
      if (smallEnough && (toastLike || floating)) best = current;
      current = current.parentElement;
      depth += 1;
    }
    return best;
  }


  function renderAutoSaveControls() {
    return el('div', { class: 'eht-auto-save-box eht-auto-save-disabled' }, [
      el('div', { class: 'eht-save-row' }, [
        el('div', { class: 'eht-setting-main' }, [
          el('div', { class: 'eht-setting-title' }, [
            el('strong', { text: '자동 저장 임시 중단' }),
            el('span', { class: 'eht-pill', text: 'HOTFIX' })
          ]),
          el('p', { text: '페이지 멈춤 방지를 위해 자동 저장은 잠시 꺼두었습니다. 백업 탭의 “저장 버튼 지정”과 “지금 저장하기”를 사용해 주세요.' })
        ])
      ])
    ]);
  }

  let saveAutoTimer = null;
  let saveWatchTimer = null;
  let saveMutationObserver = null;

  function setupAutoSaveClicker() {
    return;
  }

  function findEntrySaveButton() {
    if (manualSaveButtonTarget && document.contains(manualSaveButtonTarget)) return manualSaveButtonTarget;
    const candidates = Array.from(document.querySelectorAll('button, a, [role="button"], [aria-label], [title]'));
    for (const node of candidates) {
      if (!(node instanceof HTMLElement)) continue;
      if (isRadianceNode(node)) continue;
      const rect = node.getBoundingClientRect();
      if (rect.width < 18 || rect.height < 14) continue;
      const style = window.getComputedStyle(node);
      if (style.display === 'none' || style.visibility === 'hidden' || Number(style.opacity || 1) < 0.2) continue;
      const label = getSaveCandidateLabel(node);
      if (!label || isBadSaveLabel(label)) continue;
      if (/^(저장|저장하기|Radiance 백업|프로젝트 저장|save)$/i.test(label)) return node;
      if (/저장|save/i.test(label) && label.length <= 28) return node;
    }
    return null;
  }

  function getSaveCandidateLabel(node) {
    const aria = node.getAttribute?.('aria-label') || '';
    const title = node.getAttribute?.('title') || '';
    const text = (node.innerText || node.textContent || '').replace(/\s+/g, ' ').trim();
    return `${aria} ${title} ${text}`.replace(/\s+/g, ' ').trim();
  }

  function isBadSaveLabel(label) {
    return /(임시저장|자동저장|저장됨|저장중|저장 중|저장완료|저장 완료|저장되었습니다|저장 성공|불러오기|공유|save complete|saved|saving)/i.test(label);
  }

  function attemptEntrySave(reason = 'manual') {
    if (!detectWorkspace().ok) {
      markSaveStatus('failed', '작품만들기 미감지', '엔트리 작품만들기 화면에서 저장을 시도해 주세요.');
      toast('작품만들기 화면에서 저장을 시도해 주세요.');
      return false;
    }

    const button = findEntrySaveButton();
    if (!button) {
      markSaveStatus('failed', '저장 버튼 미감지', '저장 버튼이 화면에 보이는지 확인해 주세요.');
      toast('저장 버튼을 찾지 못했습니다.');
      return false;
    }

    try {
      button.scrollIntoView?.({ block: 'center', inline: 'center', behavior: 'smooth' });
      button.classList.add('radiance-save-flash');
      setTimeout(() => button.classList.remove('radiance-save-flash'), 1300);

      state.saveWatcher = Object.assign(defaultSaveWatcherState(), state.saveWatcher || {});
      state.saveWatcher.lastClickAt = new Date().toISOString();
      state.saveWatcher.lastButtonLabel = getSaveCandidateLabel(button);
      state.stats.saveClickAttempts = Number(state.stats.saveClickAttempts || 0) + 1;
      saveLocal();

      markSaveStatus('watching', reason === 'auto' ? '자동 저장 클릭됨' : '저장 버튼 클릭됨', 'Radiance가 저장 버튼을 눌렀고, 저장 완료 문구를 감시합니다.');

      setTimeout(() => {
        try {
          button.click();
          startSaveWatch(reason === 'auto' ? 'auto-click' : 'radiance-click');
        } catch (error) {
          console.warn('Radiance save click failed', error);
          markSaveStatus('failed', '저장 버튼 클릭 실패', '버튼은 찾았지만 클릭 중 오류가 발생했습니다.');
        }
      }, 120);

      return true;
    } catch (error) {
      console.warn('Radiance save attempt failed', error);
      markSaveStatus('failed', '저장 시도 실패', '저장 버튼 처리 중 오류가 발생했습니다.');
      return false;
    }
  }

  function startSaveWatch(source = 'manual-watch') {
    state.saveWatcher = Object.assign(defaultSaveWatcherState(), state.saveWatcher || {});
    if (!state.saveWatcher.lastClickAt) state.saveWatcher.lastClickAt = new Date().toISOString();
    const label = source === 'click' ? '저장 버튼 직접 클릭 감지됨' : source === 'shortcut' ? 'Ctrl+S 저장 감지 시작' : source === 'auto-click' ? '자동 저장 감시 중' : '저장 감시 중';
    markSaveStatus('watching', label, '저장 완료 문구를 20초 동안 감시합니다.');
    stopSaveWatchTimersOnly();

    const startedAt = Date.now();
    saveMutationObserver = new MutationObserver(() => { hideEntrySaveUiCandidates(); inspectSaveSuccess(startedAt); });
    try {
      saveMutationObserver.observe(document.body, { childList: true, subtree: true, characterData: true, attributes: true });
    } catch {}

    saveWatchTimer = setInterval(() => {
      hideEntrySaveUiCandidates();
      const done = inspectSaveSuccess(startedAt);
      if (done) return;
      if (Date.now() - startedAt > 20000) {
        stopSaveWatchTimersOnly();
        markSaveStatus('failed', '저장 성공 문구 미감지', '저장은 되었을 수 있지만, Radiance가 완료 문구를 찾지 못했습니다.');
      }
    }, 700);

    hideEntrySaveUiCandidates();
    inspectSaveSuccess(startedAt);
  }

  function stopSaveWatchTimersOnly() {
    if (saveWatchTimer) {
      clearInterval(saveWatchTimer);
      saveWatchTimer = null;
    }
    if (saveMutationObserver) {
      saveMutationObserver.disconnect();
      saveMutationObserver = null;
    }
  }

  function inspectSaveSuccess() {
    const found = scanForSaveSuccessText();
    if (!found) return false;
    stopSaveWatchTimersOnly();
    state.saveWatcher = Object.assign(defaultSaveWatcherState(), state.saveWatcher || {});
    state.saveWatcher.lastDetectedText = found;
    markSaveStatus('success', '저장 성공 감지됨', `감지 문구: ${found}`);
    toast('저장 성공 감지됨');
    return true;
  }

  function scanForSaveSuccessText() {
    const successPattern = /(저장되었습니다|저장 완료|저장완료|저장됨|저장했어요|저장 성공|saved|save complete|saved successfully)/i;
    const failPattern = /(저장 실패|저장할 수 없음|오류|실패|failed|error)/i;
    const nodes = Array.from(document.querySelectorAll('div, span, p, button, strong, em, small, [role="alert"], [aria-live]'));
    for (const node of nodes) {
      if (!(node instanceof HTMLElement)) continue;
      if (isRadianceNode(node)) continue;
      const rect = node.getBoundingClientRect();
      if (rect.width <= 0 || rect.height <= 0) continue;
      const style = window.getComputedStyle(node);
      const alreadyHiddenByRadiance = node.classList.contains('radiance-entry-save-ui-hidden') || Boolean(node.closest('.radiance-entry-save-ui-hidden'));
      if (!alreadyHiddenByRadiance && (style.display === 'none' || style.visibility === 'hidden' || Number(style.opacity || 1) < 0.15)) continue;
      const text = (node.innerText || node.textContent || '').replace(/\s+/g, ' ').trim();
      if (isEntrySaveStatusText(text) && state.saveWatcher?.hideEntrySaveUi) {
        const target = findEntrySaveUiContainer(node);
        if (target) target.classList.add('radiance-entry-save-ui-hidden');
      }
      if (!text || text.length > 80) continue;
      if (failPattern.test(text)) {
        markSaveStatus('failed', '저장 실패 문구 감지', text);
        return '';
      }
      if (successPattern.test(text)) return text;
    }
    return '';
  }

  function markSaveStatus(status, message, detail = '', options = {}) {
    state.saveWatcher = Object.assign(defaultSaveWatcherState(), state.saveWatcher || {});
    if (options.clear) {
      state.saveWatcher = defaultSaveWatcherState();
    } else {
      state.saveWatcher.status = status;
      state.saveWatcher.message = message;
      state.saveWatcher.detail = detail;
      if (status === 'watching') state.saveWatcher.watchUntil = Date.now() + 20000;
      if (status === 'success') {
        state.saveWatcher.lastSuccessAt = new Date().toISOString();
        state.saveWatcher.watchUntil = 0;
        state.stats.saveSuccessDetections = Number(state.stats.saveSuccessDetections || 0) + 1;
      }
      if (status === 'failed') state.saveWatcher.watchUntil = 0;
    }
    hideEntrySaveUiCandidates();
    refreshBadges(true);
    saveLocalNow();
    if (state.tab === 'save') setTimeout(render, 0);
  }

  function flashEntrySaveButton() {
    const button = getPreferredSaveButton();
    if (!button) {
      markSaveStatus('failed', '저장 버튼 미감지', '저장 버튼을 찾지 못했습니다.');
      toast('저장 버튼을 찾지 못했습니다.');
      return false;
    }
    button.scrollIntoView?.({ block: 'center', inline: 'center', behavior: 'smooth' });
    button.classList.add('radiance-save-flash');
    setTimeout(() => button.classList.remove('radiance-save-flash'), 1600);
    markSaveStatus('idle', '저장 버튼 표시됨', getSaveCandidateLabel(button) || '버튼을 강조 표시했습니다.');
    toast('저장 버튼을 표시했습니다.');
    return true;
  }

  function isSaveClickTarget(target) {
    const node = target?.closest?.('button, a, [role="button"], div, span');
    if (!(node instanceof HTMLElement)) return false;
    if (isRadianceNode(node)) return false;
    const label = getSaveCandidateLabel(node);
    if (!label || isBadSaveLabel(label)) return false;
    return /(^|\s)(저장|저장하기|Radiance 백업|프로젝트 저장)(\s|$)/i.test(label) || (label.includes('저장') && label.length <= 16);
  }

  function copySaveStatus() {
    const data = {
      type: 'radiance-save-clicker-status',
      projectKey,
      saveWatcher: state.saveWatcher || defaultSaveWatcherState(),
      saveButtonDetected: Boolean(getPreferredSaveButton()),
      workspace: detectWorkspace(),
      copiedAt: new Date().toISOString()
    };
    copyText(JSON.stringify(data, null, 2), TEXT.copiedToast);
  }

  
  function badgeDefinitions() {
    const checkedCount = CHECKLIST.filter((_, i) => state.checklist[i]).length;
    const cueCount = timelineLines(state.timeline).length;
    const notesLen = (state.notes || '').trim().length;
    const snippetLen = (state.customSnippets || '').trim().length;
    const codeVaultCount = Array.isArray(state.codeVault) ? state.codeVault.length : 0;
    const paletteCount = Array.isArray(state.palette) ? state.palette.length : 0;
    const paletteUses = Number(state.stats.paletteAdds || 0) + Number(state.stats.paletteCopies || 0) + Number(state.stats.palettePresetUses || 0);
    const themeChanges = Number(state.stats.themeChanges || 0);
    const randomThemeUses = Number(state.stats.randomThemeUses || 0);
    const quickThemeUses = Number(state.stats.quickThemeUses || 0);
    const commandRuns = Number(state.stats.commandRuns || 0);
    const bgmLoads = Number(state.stats.bgmLoads || 0);
    const bgmWindowOpens = Number(state.stats.bgmWindowOpens || 0);
    const qualityBoostUses = Number(state.stats.qualityBoostUses || 0);
    const qualityBoostApplies = Number(state.stats.qualityBoostApplies || 0);
    const commandOpens = Number(state.stats.commandOpens || 0);
    const bubbleMoves = Number(state.stats.bubbleMoves || 0);
    const bridgeParsedItems = parseBridgeItems(state.bridgeJson).items;
    const bridgeItems = bridgeParsedItems.length;
    const bridgeDoneCount = bridgeParsedItems.filter(item => state.bridgeDone[item.id]).length;
    const coordUses = Number(state.stats.coordCopies || 0) + Number(state.stats.coordInserts || 0);
    const insertions = Number(state.stats.insertions || 0);
    const snippetPower = Number(state.stats.snippetCopies || 0) + Number(state.stats.snippetInserts || 0) + Number(state.stats.snippetToBridge || 0);
    const tabSupportUses = Number(state.stats['tab:support'] || 0) + Number(state.stats['tab:guide'] || 0) + Number(state.stats['tab:updateHub'] || 0);
    const unlockedCount = Object.values(state.badges || {}).filter(Boolean).length;
    return [
      {
        id: 'first-light',
        icon: '✨',
        title: '첫 발광',
        desc: 'Radiance 패널을 열었습니다.',
        achieved: true,
        progress: '완료'
      },
      {
        id: 'check-master',
        icon: '✅',
        title: '점검 완료',
        desc: '체크리스트를 모두 완료했습니다.',
        achieved: checkedCount >= CHECKLIST.length,
        progress: `${checkedCount}/${CHECKLIST.length}`
      },
      {
        id: 'coordinate-mage',
        icon: '📍',
        title: '좌표술사',
        desc: '좌표 복사/입력을 3번 이상 사용했습니다.',
        achieved: coordUses >= 3,
        progress: `${Math.min(coordUses, 3)}/3`
      },
      {
        id: 'cue-master',
        icon: '🎬',
        title: '큐 마스터',
        desc: '타임라인 큐를 5개 이상 작성했습니다.',
        achieved: cueCount >= 5,
        progress: `${Math.min(cueCount, 5)}/5`
      },
      {
        id: 'memo-keeper',
        icon: '📝',
        title: '기록 보관자',
        desc: '프로젝트 메모를 100자 이상 작성했습니다.',
        achieved: notesLen >= 100,
        progress: `${Math.min(notesLen, 100)}/100자`
      },
      {
        id: 'snippet-smith',
        icon: '🧩',
        title: '스니펫 장인',
        desc: '내 스니펫을 20자 이상 저장했습니다.',
        achieved: snippetLen >= 20,
        progress: `${Math.min(snippetLen, 20)}/20자`
      },
      {
        id: 'entry-touch',
        icon: '🖱️',
        title: '작업창 터치',
        desc: '엔트리 입력칸에 Radiance 값을 넣었습니다.',
        achieved: insertions >= 1,
        progress: `${Math.min(insertions, 1)}/1`
      },
      {
        id: 'viventry-link',
        icon: '🌉',
        title: 'Viventry 연결자',
        desc: 'Bridge에서 JSON 큐를 감지했습니다.',
        achieved: bridgeItems >= 1,
        progress: `${bridgeItems}큐`
      },
      {
        id: 'command-runner',
        icon: '⌘',
        title: '커맨드 러너',
        desc: '빠른 실행에서 명령을 실행했습니다.',
        achieved: commandRuns >= 1,
        progress: `${Math.min(commandRuns, 1)}/1`
      },
      {
        id: 'command-opener',
        icon: '🔎',
        title: '빠른 실행 발견자',
        desc: '커맨드 팔레트를 열었습니다.',
        achieved: commandOpens >= 1,
        progress: `${Math.min(commandOpens, 1)}/1`
      },
      {
        id: 'quality-v2',
        icon: '✨',
        title: 'Quality Boost V2',
        desc: 'Radiance Quality Boost를 적용했습니다.',
        achieved: qualityBoostUses >= 1 || qualityBoostApplies >= 1,
        progress: `${Math.min(qualityBoostApplies, 1)}/1`
      },
      {
        id: 'bgm-window',
        icon: '🪟',
        title: 'BGM 분리 창',
        desc: 'YouTube BGM을 별도 창으로 열었습니다.',
        achieved: bgmWindowOpens >= 1,
        progress: `${Math.min(bgmWindowOpens, 1)}/1`
      },
      {
        id: 'bgm-room',
        icon: '🎵',
        title: 'BGM Room 입장',
        desc: 'YouTube BGM을 Radiance에서 열었습니다.',
        achieved: bgmLoads >= 1,
        progress: `${Math.min(bgmLoads, 1)}/1`
      },
      {
        id: 'dock-walker',
        icon: '🧭',
        title: '도크 길들이기',
        desc: 'Mini Dock 위치를 옮겼습니다.',
        achieved: bubbleMoves >= 1,
        progress: `${Math.min(bubbleMoves, 1)}/1`
      },
      {
        id: 'theme-randomizer',
        icon: '🎲',
        title: '테마 랜덤술사',
        desc: '랜덤 테마를 사용했습니다.',
        achieved: randomThemeUses >= 1,
        progress: `${Math.min(randomThemeUses, 1)}/1`
      },
      {
        id: 'quick-switcher',
        icon: '⚡',
        title: '퀵 스위처',
        desc: '홈에서 테마를 빠르게 바꿨습니다.',
        achieved: quickThemeUses >= 1,
        progress: `${Math.min(quickThemeUses, 1)}/1`
      },
      {
        id: 'theme-stylist',
        icon: '🪄',
        title: '테마 스타일리스트',
        desc: 'Radiance 테마를 변경했습니다.',
        achieved: themeChanges >= 1,
        progress: `${Math.min(themeChanges, 1)}/1`
      },
      {
        id: 'theme-collector',
        icon: '🌈',
        title: '테마 수집가',
        desc: '테마 색상을 팔레트로 보냈습니다.',
        achieved: Number(state.stats.themeToPalette || 0) >= 1,
        progress: `${Math.min(Number(state.stats.themeToPalette || 0), 1)}/1`
      },
      {
        id: 'palette-keeper',
        icon: '🎨',
        title: '색상 관리자',
        desc: '팔레트에 색상을 저장했습니다.',
        achieved: paletteCount >= 1,
        progress: `${Math.min(paletteCount, 1)}/1`
      },
      {
        id: 'palette-curator',
        icon: '🖌️',
        title: '팔레트 큐레이터',
        desc: '색상을 4개 이상 저장했습니다.',
        achieved: paletteCount >= 4,
        progress: `${Math.min(paletteCount, 4)}/4`
      },
      {
        id: 'color-copyist',
        icon: '📋',
        title: '컬러 복사술사',
        desc: '팔레트 저장/복사/프리셋을 3번 이상 사용했습니다.',
        achieved: paletteUses >= 3,
        progress: `${Math.min(paletteUses, 3)}/3`
      },
      {
        id: 'code-vault-keeper',
        icon: '💾',
        title: '코드 보관자',
        desc: '코드저장에 실제 코드를 저장했습니다.',
        achieved: codeVaultCount >= 1,
        progress: `${Math.min(codeVaultCount, 1)}/1`
      },
      {
        id: 'code-collector',
        icon: '🗂️',
        title: '코드 수집가',
        desc: '코드를 3개 이상 저장했습니다.',
        achieved: codeVaultCount >= 3,
        progress: `${Math.min(codeVaultCount, 3)}/3`
      },
      {
        id: 'snippet-power',
        icon: '🧰',
        title: '스니펫 파워유저',
        desc: '스니펫 복사/삽입/Bridge 전송을 3번 이상 사용했습니다.',
        achieved: snippetPower >= 3,
        progress: `${Math.min(snippetPower, 3)}/3`
      },
      {
        id: 'snippet-pack-runner',
        icon: '📦',
        title: '팩 장착 완료',
        desc: '스니펫 팩을 사용했습니다.',
        achieved: Number(state.stats.snippetPackUses || 0) >= 1,
        progress: `${Math.min(Number(state.stats.snippetPackUses || 0), 1)}/1`
      },
      {
        id: 'bridge-runner',
        icon: '🚇',
        title: '큐 러너',
        desc: 'Bridge 필드 삽입을 3번 이상 사용했습니다.',
        achieved: Number(state.stats.bridgeFieldInserts || 0) >= 3,
        progress: `${Math.min(Number(state.stats.bridgeFieldInserts || 0), 3)}/3`
      },
      {
        id: 'queue-finisher',
        icon: '🏁',
        title: '큐 완주자',
        desc: 'Bridge 큐를 3개 이상 완료 처리했습니다.',
        achieved: bridgeDoneCount >= 3 || Number(state.stats.bridgeQueueCompletions || 0) >= 1,
        progress: `${Math.min(Math.max(bridgeDoneCount, Number(state.stats.bridgeQueueCompletions || 0)), 3)}/3`
      },
      {
        id: 'support-reader',
        icon: '🛟',
        title: '지원센터 이용자',
        desc: '사용설명서/업데이트/지원 탭을 확인했습니다.',
        achieved: tabSupportUses >= 2,
        progress: `${Math.min(tabSupportUses, 2)}/2`
      },
      {
        id: 'badge-hunter',
        icon: '🏆',
        title: '배지 헌터',
        desc: '배지를 8개 이상 달성했습니다.',
        achieved: unlockedCount >= 8,
        progress: `${Math.min(unlockedCount, 8)}/8`
      },
      {
        id: 'backup-keeper',
        icon: '🗄️',
        title: '백업 관리자',
        desc: 'Radiance 내부 백업을 만들었습니다.',
        achieved: Number(state.stats.internalBackups || 0) >= 1,
        progress: `${Math.min(Number(state.stats.internalBackups || 0), 1)}/1`
      },
      {
        id: 'page-searcher',
        icon: '🔎',
        title: '페이지 탐색자',
        desc: '페이지 내부 검색을 사용했습니다.',
        achieved: Number(state.stats.pageSearches || 0) >= 1,
        progress: `${Math.min(Number(state.stats.pageSearches || 0), 1)}/1`
      }
    ];
  }

  function refreshBadges(showToast = false) {
    let unlocked = false;
    for (const badge of badgeDefinitions()) {
      if (badge.achieved && !state.badges[badge.id]) {
        state.badges[badge.id] = true;
        unlocked = true;
        if (showToast) toast(`${TEXT.badgeUnlocked}: ${badge.icon} ${badge.title}`);
      }
    }
    if (unlocked) saveLocal();
    return unlocked;
  }

  function bumpStat(key, amount = 1) {
    state.stats[key] = Number(state.stats[key] || 0) + amount;
    refreshBadges(true);
    saveLocal();
  }

  function renderBadges() {
    refreshBadges(false);
    const badges = badgeDefinitions();
    const unlocked = badges.filter(b => state.badges[b.id]).length;
    return el('div', { class: 'eht-section eht-badge-section' }, [
      sectionIntro(TEXT.badgesTitle, TEXT.badgesDescription),
      el('div', { class: 'eht-badge-summary' }, [
        el('strong', { text: `${unlocked}/${badges.length}` }),
        el('span', { text: '배지 달성' })
      ]),
      el('div', { class: 'eht-badge-grid' }, badges.map(badge => {
        const achieved = Boolean(state.badges[badge.id]);
        return el('div', { class: `eht-badge-card ${achieved ? 'is-achieved' : 'is-locked'}` }, [
          el('div', { class: 'eht-badge-icon', text: achieved ? badge.icon : '🔒' }),
          el('div', { class: 'eht-badge-copy' }, [
            el('strong', { text: badge.title }),
            el('span', { text: badge.desc }),
            el('em', { text: achieved ? `${TEXT.badgeUnlockedLabel} · ${badge.progress}` : `${TEXT.badgeLocked} · ${badge.progress}` })
          ])
        ]);
      }))
    ]);
  }

  function renderDiagnostics() {
    const workspace = detectWorkspace();
    const backup = ensureBackupState();
    const pageSearchCount = safePageCandidateCount();
    const storageStatus = getStorageStatusLabel();
    const version = getManifestVersionLabel();

    return el('div', { class: 'eht-section eht-diagnostics-section' }, [
      sectionIntro('진단', '스토어 심사/버그 제보/테스트를 위한 상태 확인 도구입니다.'),
      el('div', { class: 'eht-status-grid' }, [
        statusChip('버전', version, true),
        statusChip('엔트리 화면', workspace.ok ? '감지됨' : '미감지', workspace.ok),
        statusChip('로컬 저장', storageStatus.ok ? '정상' : '확인 필요', storageStatus.ok),
        statusChip('백업', `${backup.items?.length || 0}개`, (backup.items?.length || 0) > 0),
        statusChip('페이지 항목', `${pageSearchCount}개`, pageSearchCount > 0),
        statusChip('탭', TEXT.tabs[state.tab] || state.tab, true)
      ]),

      el('div', { class: 'eht-save-card eht-diagnostics-card' }, [
        el('div', { class: 'eht-mini-title', text: '빠른 점검' }),
        el('div', { class: 'eht-diagnostics-list' }, [
          diagRow('playentry.org 권한', location.hostname.includes('playentry.org') ? '정상' : '엔트리 페이지가 아님', location.hostname.includes('playentry.org')),
          diagRow('패널 렌더링', document.getElementById(APP_ID) ? '정상' : '확인 필요', Boolean(document.getElementById(APP_ID))),
          diagRow('내부 백업', backup.autoEnabled ? '자동 백업 ON' : '자동 백업 OFF', Boolean(backup.autoEnabled)),
          diagRow('페이지 검색', pageSearchCount > 0 ? `${pageSearchCount}개 대상 감지` : '대상 없음', pageSearchCount > 0),
          diagRow('외부 전송', '없음', true)
        ]),
        el('div', { class: 'eht-action-row eht-wrap-row' }, [
          el('button', { class: 'eht-main-btn', onclick: copyDiagnosticsReport }, ['진단 복사']),
          el('button', { class: 'eht-link-btn', onclick: () => createInternalBackup('manual') }, ['지금 백업']),
          el('button', { class: 'eht-link-btn', onclick: () => switchTab('backupTools') }, ['데이터 관리'])
        ])
      ]),

      el('div', { class: 'eht-save-card eht-diagnostics-card' }, [
        el('div', { class: 'eht-mini-title', text: '심사원 테스트 가이드' }),
        el('div', { class: 'eht-review-guide' }, [
          el('p', { text: '1. playentry.org에서 Radiance 패널을 엽니다.' }),
          el('p', { text: '2. 홈/체크리스트/메모/페이지 검색/백업 탭을 확인합니다.' }),
          el('p', { text: '3. 백업 탭에서 “지금 백업”을 눌러 로컬 백업 생성 여부를 확인합니다.' }),
          el('p', { text: '4. Radiance는 외부 채팅/서버 전송 기능을 포함하지 않습니다.' })
        ]),
        el('button', { class: 'eht-link-btn', onclick: copyReviewGuide }, ['테스트 가이드 복사'])
      ])
    ]);
  }

  function renderBackupTools() {
    const exportText = JSON.stringify(makeFullRadianceExport(), null, 2);
    const importBox = el('textarea', {
      class: 'eht-input eht-import-box',
      placeholder: '여기에 Radiance 백업 JSON을 붙여넣고 “JSON 복원”을 누르세요.'
    });

    return el('div', { class: 'eht-section eht-backup-tools-section' }, [
      sectionIntro('데이터 관리', 'Radiance 데이터를 JSON으로 내보내거나 복원합니다. 엔트리 작품 파일 저장 기능은 아닙니다.'),
      el('div', { class: 'eht-status-grid' }, [
        statusChip('내보내기', '지원', true),
        statusChip('가져오기', '지원', true),
        statusChip('저장 위치', '브라우저 로컬', true),
        statusChip('외부 전송', '없음', true)
      ]),

      el('div', { class: 'eht-save-card eht-export-card' }, [
        el('div', { class: 'eht-mini-title', text: '전체 데이터 내보내기' }),
        el('div', { class: 'eht-hint', text: '체크리스트, 메모, 타임라인, 스니펫, 백업 목록, 배지 진행도, 설정을 JSON으로 저장합니다.' }),
        el('div', { class: 'eht-action-row eht-wrap-row' }, [
          el('button', { class: 'eht-main-btn', onclick: downloadFullRadianceExport }, ['JSON 다운로드']),
          el('button', { class: 'eht-link-btn', onclick: () => copyText(exportText, TEXT.copiedToast) }, ['JSON 복사']),
          el('button', { class: 'eht-link-btn', onclick: copyDiagnosticsReport }, ['진단 복사'])
        ])
      ]),

      el('div', { class: 'eht-save-card eht-import-card' }, [
        el('div', { class: 'eht-mini-title', text: 'JSON 복원' }),
        importBox,
        el('div', { class: 'eht-action-row eht-wrap-row' }, [
          el('button', { class: 'eht-main-btn', onclick: () => restoreFullRadianceExport(importBox.value) }, ['JSON 복원']),
          el('button', { class: 'eht-link-btn', onclick: () => { importBox.value = ''; } }, ['비우기'])
        ]),
        el('div', { class: 'eht-hint', text: '복원 전 현재 데이터는 자동으로 1회 내부 백업됩니다.' })
      ])
    ]);
  }

  function diagRow(label, value, ok) {
    return el('div', { class: `eht-diag-row ${ok ? 'is-ok' : 'is-warn'}` }, [
      el('span', { text: label }),
      el('strong', { text: value })
    ]);
  }

  function safePageCandidateCount() {
    try {
      if (typeof countPageSearchCandidates === 'function') return countPageSearchCandidates();
      if (typeof countLibraryCandidates === 'function') return countLibraryCandidates();
      return document.querySelectorAll('article, li, a[href], div[class*="card" i], div[class*="project" i]').length;
    } catch {
      return 0;
    }
  }

  function getManifestVersionLabel() {
    try {
      const manifest = chrome?.runtime?.getManifest?.();
      return manifest?.version_name || manifest?.version || 'unknown';
    } catch {
      return 'unknown';
    }
  }

  function getStorageStatusLabel() {
    try {
      const key = `radiance-storage-test:${Date.now()}`;
      localStorage.setItem(key, 'ok');
      const ok = localStorage.getItem(key) === 'ok';
      localStorage.removeItem(key);
      return { ok };
    } catch {
      return { ok: false };
    }
  }

  function makeFullRadianceExport() {
    return {
      type: 'radiance-full-export',
      version: getManifestVersionLabel(),
      exportedAt: new Date().toISOString(),
      url: location.href,
      projectKey,
      data: {
        checklist: state.checklist || {},
        timeline: state.timeline || '',
        notes: state.notes || '',
        customSnippets: state.customSnippets || '',
        palette: state.palette || [],
        codeVault: state.codeVault || [],
        bridgeJson: state.bridgeJson || '',
        bridgeDone: state.bridgeDone || {},
        bridgeInsertText: state.bridgeInsertText || '',
        bridgeActiveIndex: state.bridgeActiveIndex || 0,
        badges: state.badges || {},
        stats: state.stats || {},
        theme: state.theme,
        warningIndex: state.warningIndex || 0,
        internalBackup: state.internalBackup || defaultInternalBackupState(),
        pageSearch: state.pageSearch || defaultPageSearchState(),
        tab: state.tab || 'home'
      }
    };
  }

  function downloadFullRadianceExport() {
    const data = JSON.stringify(makeFullRadianceExport(), null, 2);
    const blob = new Blob([data], { type: 'application/json;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const stamp = new Date().toISOString().replace(/[:.]/g, '-');
    const a = document.createElement('a');
    a.href = url;
    a.download = `radiance-export-${stamp}.json`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
    toast('Radiance JSON 내보내기 완료');
  }

  function restoreFullRadianceExport(raw) {
    let parsed;
    try {
      parsed = JSON.parse(String(raw || '').trim());
    } catch {
      toast('JSON 형식이 올바르지 않습니다.');
      return false;
    }
    if (!parsed || parsed.type !== 'radiance-full-export' || !parsed.data) {
      toast('Radiance 내보내기 JSON이 아닙니다.');
      return false;
    }
    const ok = confirm('이 JSON으로 Radiance 데이터를 복원할까요? 현재 데이터는 내부 백업 후 바뀝니다.');
    if (!ok) return false;

    createInternalBackup('before-import');

    const data = parsed.data;
    state.checklist = data.checklist || {};
    state.timeline = data.timeline || '';
    state.notes = data.notes || '';
    state.customSnippets = data.customSnippets || '';
    state.theme = data.theme || state.theme || 'sky-island';
    state.palette = Array.isArray(data.palette) ? data.palette : [];
    state.codeVault = Array.isArray(data.codeVault) ? data.codeVault : [];
    state.bridgeJson = data.bridgeJson || '';
    state.bridgeDone = data.bridgeDone || {};
    state.bridgeInsertText = data.bridgeInsertText || '';
    state.bridgeActiveIndex = data.bridgeActiveIndex || 0;
    state.badges = data.badges || {};
    state.stats = data.stats || {};
    state.warningIndex = Number.isFinite(Number(data.warningIndex)) ? Number(data.warningIndex) : 0;
    state.internalBackup = data.internalBackup || defaultInternalBackupState();
    state.pageSearch = data.pageSearch || defaultPageSearchState();
    state.tab = 'home';

    saveLocalNow();
    toast('Radiance 데이터 복원 완료');
    render();
    return true;
  }

  function makeDiagnosticsReport() {
    const backup = ensureBackupState();
    return {
      type: 'radiance-diagnostics',
      version: getManifestVersionLabel(),
      copiedAt: new Date().toISOString(),
      url: location.href,
      host: location.hostname,
      workspace: detectWorkspace(),
      projectKey,
      activeTab: state.tab,
      panelEnabled: Boolean(state.enabled),
      panelCollapsed: Boolean(state.collapsed),
      backupCount: backup.items?.length || 0,
      backupAutoEnabled: Boolean(backup.autoEnabled),
      pageSearchTargetCount: safePageCandidateCount(),
      checklistDone: Object.values(state.checklist || {}).filter(Boolean).length,
      timelineLines: timelineLines(state.timeline || '').length,
      notesLength: (state.notes || '').trim().length,
      hasExternalChat: false,
      sendsDataToServer: false
    };
  }

  function copyDiagnosticsReport() {
    copyText(JSON.stringify(makeDiagnosticsReport(), null, 2), TEXT.copiedToast);
  }

  function copyReviewGuide() {
    copyText([
      '1. playentry.org에 접속합니다.',
      '2. 확장 프로그램 아이콘을 누르고 “도우미 열기”를 클릭합니다.',
      '3. Radiance 패널이 표시되는지 확인합니다.',
      '4. 홈/체크리스트/메모/페이지 검색/백업 탭을 확인합니다.',
      '5. 백업 탭에서 “지금 백업”을 눌러 내부 백업이 생성되는지 확인합니다.',
      '6. Radiance는 외부 채팅/서버 전송 기능을 포함하지 않습니다.'
    ].join('\n'), TEXT.copiedToast);
  }



  function getReleaseChannelLabel() {
    try {
      const gecko = chrome?.runtime?.getManifest?.()?.browser_specific_settings?.gecko;
      if (gecko) return 'Firefox / AMO';
    } catch {}
    const title = chrome?.runtime?.getManifest?.()?.action?.default_title || '';
    if (/firefox/i.test(title)) return 'Firefox / AMO';
    if (/chromium|chrome|edge/i.test(title)) return 'Chromium';
    return 'Browser Extension';
  }

  function getUpdateModeLabel() {
    const channel = getReleaseChannelLabel();
    if (channel.includes('Firefox')) return 'AMO 서명판은 브라우저/AMO 배포 설정에 따라 자동 업데이트됩니다.';
    if (channel === 'Chromium') return 'Chromium판 ZIP은 Chrome, Edge, Whale, Brave 등에서 사용할 수 있으며, 개발자 모드 설치본은 새 ZIP을 받아 수동으로 다시 로드해야 합니다.';
    return '설치 방식에 따라 업데이트 방식이 달라집니다.';
  }

  function makeBugReportTemplate() {
    const diag = makeDiagnosticsReport();
    return [
      '# Radiance 버그 제보',
      '',
      '## 증상',
      '- ',
      '',
      '## 재현 순서',
      '1. ',
      '2. ',
      '3. ',
      '',
      '## 기대한 동작',
      '- ',
      '',
      '## 실제 동작',
      '- ',
      '',
      '## 진단 정보',
      '```json',
      JSON.stringify(diag, null, 2),
      '```'
    ].join('\n');
  }

  function copyBugReportTemplate() {
    copyText(makeBugReportTemplate(), '버그제보 템플릿 복사 완료');
  }

  function makeReleasePostText() {
    const version = getManifestVersionLabel();
    return [
      `Radiance Lucis ${version} 업데이트`,
      '',
      '이번 업데이트에서는 지원 센터와 설치 안내 복사 기능이 추가되었습니다.',
      '패널 안에서 기능 설명, 브라우저별 업데이트 방법, 버그제보 템플릿을 바로 확인할 수 있습니다.',
      '',
      '지원 브라우저:',
      '- Chromium 기반 브라우저: Chrome, Edge, Whale, Brave 등',
      '- Firefox',
      '',
      '주의:',
      'Radiance 백업은 엔트리 작품 파일 저장이 아니라 Radiance 내부 메모/체크리스트/타임라인 데이터 백업입니다.'
    ].join('\n');
  }

  function copyReleasePostText() {
    copyText(makeReleasePostText(), '릴리즈 공지 복사 완료');
  }

  function renderGuide() {
    return el('div', { class: 'eht-section eht-guide-section' }, [
      sectionIntro('사용설명서', 'Radiance 기능을 처음 쓰는 사람도 바로 볼 수 있는 빠른 안내입니다.'),
      el('div', { class: 'eht-status-grid' }, [
        statusChip('패널 상태', state.collapsed ? '접힘' : '열림', true),
        statusChip('현재 탭', TEXT.tabs[state.tab] || state.tab, true),
        statusChip('저장 위치', '브라우저 로컬', true),
        statusChip('외부 전송', '없음', true)
      ]),
      el('div', { class: 'eht-guide-list' }, USER_GUIDE_SECTIONS.map(section =>
        el('div', { class: 'eht-save-card eht-guide-card' }, [
          el('div', { class: 'eht-mini-title', text: section.title }),
          el('p', { class: 'eht-guide-body', text: section.body })
        ])
      )),
      el('div', { class: 'eht-save-card eht-guide-card' }, [
        el('div', { class: 'eht-mini-title', text: '한 줄 요약' }),
        el('p', { class: 'eht-guide-body', text: 'Radiance는 엔트리 제작 중 필요한 메모, 체크리스트, 검색, 백업, 진단을 한 패널에 모아 주는 제작 보조 도구입니다.' }),
        el('div', { class: 'eht-action-row eht-wrap-row' }, [
          el('button', { class: 'eht-main-btn', onclick: () => switchTab('updateHub') }, ['업데이트 보기']),
          el('button', { class: 'eht-link-btn', onclick: copyReviewGuide }, ['심사 가이드 복사'])
        ])
      ])
    ]);
  }

  function renderUpdateHub() {
    const current = RELEASE_NOTES[0];
    const version = getManifestVersionLabel();
    const channel = getReleaseChannelLabel();
    const updateMode = getUpdateModeLabel();

    return el('div', { class: 'eht-section eht-update-section' }, [
      sectionIntro('업데이트', '현재 버전, 업데이트 방식, 변경 로그를 확인합니다. 자동 설치가 아니라 안전한 업데이트 안내 방식입니다.'),
      el('div', { class: 'eht-status-grid' }, [
        statusChip('현재 버전', version, true),
        statusChip('채널', channel, true),
        statusChip('최신 내장 로그', current.version, true),
        statusChip('자동 설치', '브라우저 정책상 불가', false)
      ]),
      el('div', { class: 'eht-save-card eht-update-card' }, [
        el('div', { class: 'eht-mini-title', text: '업데이트 방식' }),
        el('p', { class: 'eht-guide-body', text: updateMode }),
        el('p', { class: 'eht-guide-body', text: 'Chromium판 개발자 모드 ZIP은 Chrome, Edge, Whale, Brave 등에서 사용할 수 있으며, 새 버전을 내려받아 확장 프로그램 관리 페이지에서 다시 로드해야 합니다. Firefox signed XPI/AMO판은 AMO 배포 설정을 따릅니다.' }),
        el('div', { class: 'eht-action-row eht-wrap-row' }, [
          el('button', { class: 'eht-main-btn', onclick: copyReleasePostText }, ['릴리즈 공지 복사']),
          el('button', { class: 'eht-link-btn', onclick: copyBugReportTemplate }, ['버그제보 템플릿']),
          el('button', { class: 'eht-link-btn', onclick: () => window.open('https://playentry.org/', '_blank', 'noopener,noreferrer') }, ['엔트리 열기'])
        ])
      ]),
      el('div', { class: 'eht-release-list' }, RELEASE_NOTES.map(note =>
        el('div', { class: 'eht-save-card eht-release-card' }, [
          el('div', { class: 'eht-release-head' }, [
            el('strong', { text: `${note.version} · ${note.title}` }),
            el('span', { text: note.date })
          ]),
          el('ul', { class: 'eht-release-items' }, note.items.map(item => el('li', { text: item })))
        ])
      )),
      el('div', { class: 'eht-coming-soon' }, [
        el('strong', { text: '자동 업데이트 체크 안내' }),
        el('span', { text: '원격 서버/API를 추가하면 권한과 심사 부담이 늘어나므로, 현재 버전은 로컬 변경 로그와 수동 업데이트 안내를 제공합니다.' })
      ])
    ]);
  }

  function getChromiumInstallGuideText() {
    return [
      'Radiance Lucis Chromium판 설치 방법',
      '',
      '대상 브라우저:',
      '- Chrome',
      '- Edge',
      '- Whale',
      '- Brave',
      '- 기타 Chromium 기반 브라우저',
      '',
      '설치 순서:',
      '1. radiance-chromium ZIP 파일을 다운로드합니다.',
      '2. ZIP 압축을 풉니다.',
      '3. 브라우저 확장 프로그램 관리 페이지를 엽니다.',
      '   - Chrome: chrome://extensions',
      '   - Edge: edge://extensions',
      '   - Whale: whale://extensions',
      '   - Brave: brave://extensions',
      '4. 개발자 모드를 켭니다.',
      '5. “압축해제된 확장 프로그램을 로드”를 누릅니다.',
      '6. 압축을 푼 Radiance 폴더를 선택합니다.',
      '7. playentry.org에서 확장 아이콘을 누르고 “도우미 열기”를 클릭합니다.',
      '',
      '업데이트:',
      '새 버전 ZIP을 다시 다운로드하고 압축을 푼 뒤, 확장 프로그램 관리 페이지에서 Radiance를 다시 로드합니다.'
    ].join('\n');
  }

  function getFirefoxInstallGuideText() {
    return [
      'Radiance Lucis Firefox판 설치 방법',
      '',
      'Firefox판은 Firefox 전용 빌드를 사용합니다.',
      '일반 사용자는 Mozilla AMO 서명판 또는 signed XPI를 사용하는 것을 권장합니다.',
      '',
      '설치 순서:',
      '1. Firefox용 signed XPI 파일을 다운로드합니다.',
      '2. Firefox에서 XPI 파일을 엽니다.',
      '3. 설치 확인 창이 뜨면 추가/설치를 선택합니다.',
      '4. playentry.org에서 확장 아이콘을 누르고 “도우미 열기”를 클릭합니다.',
      '',
      '임시 테스트:',
      '1. about:debugging#/runtime/this-firefox 를 엽니다.',
      '2. “임시 부가 기능 로드...”를 클릭합니다.',
      '3. 압축을 푼 Firefox ZIP 폴더의 manifest.json을 선택합니다.',
      '',
      '업데이트:',
      'AMO 배포판은 AMO 설정을 따릅니다. 직접 배포 signed XPI는 새 XPI를 다시 설치합니다.'
    ].join('\n');
  }

  function getQuickHelpText() {
    return [
      'Radiance Lucis 빠른 도움말',
      '',
      'Q. Edge에서도 되나요?',
      'A. 네. Chromium판은 Chrome, Edge, Whale, Brave 등 Chromium 기반 브라우저에서 사용할 수 있습니다.',
      '',
      'Q. Firefox에서는 어떤 파일을 쓰나요?',
      'A. Firefox판 signed XPI 또는 AMO 서명판을 사용합니다.',
      '',
      'Q. 백업이 엔트리 작품 파일도 저장하나요?',
      'A. 아니요. Radiance 백업은 Radiance 안의 메모, 체크리스트, 타임라인, 스니펫 같은 내부 데이터만 저장합니다.',
      '',
      'Q. 패널을 닫고 페이지를 옮기면 다시 열리나요?',
      'A. v1.2.1 이후부터는 접힌 상태가 유지됩니다. 확장 아이콘에서 “도우미 열기”를 누르면 다시 열립니다.',
      '',
      'Q. 페이지 검색은 엔트리 전체 검색인가요?',
      'A. 아니요. 현재 화면에 로딩된 카드/목록 내부 검색입니다.'
    ].join('\n');
  }

  function copyChromiumInstallGuide() {
    copyText(getChromiumInstallGuideText(), 'Chromium 설치 안내 복사 완료');
  }

  function copyFirefoxInstallGuide() {
    copyText(getFirefoxInstallGuideText(), 'Firefox 설치 안내 복사 완료');
  }

  function copyQuickHelpText() {
    copyText(getQuickHelpText(), '빠른 도움말 복사 완료');
  }

  function renderSupportCenter() {
    const channel = getReleaseChannelLabel();
    const version = getManifestVersionLabel();
    return el('div', { class: 'eht-section eht-support-section' }, [
      sectionIntro('지원 센터', '설치, 업데이트, 버그제보, 빠른 도움말을 한곳에 모았습니다.'),
      el('div', { class: 'eht-status-grid' }, [
        statusChip('현재 버전', version, true),
        statusChip('채널', channel, true),
        statusChip('브라우저 구분', 'Chromium / Firefox', true),
        statusChip('외부 전송', '없음', true)
      ]),

      el('div', { class: 'eht-save-card eht-support-card' }, [
        el('div', { class: 'eht-mini-title', text: '설치 안내 복사' }),
        el('p', { class: 'eht-guide-body', text: '배포글 댓글이나 문의 답변에 바로 붙여넣을 수 있는 설치 안내문입니다.' }),
        el('div', { class: 'eht-action-row eht-wrap-row' }, [
          el('button', { class: 'eht-main-btn', onclick: copyChromiumInstallGuide }, ['Chromium 안내']),
          el('button', { class: 'eht-link-btn', onclick: copyFirefoxInstallGuide }, ['Firefox 안내']),
          el('button', { class: 'eht-link-btn', onclick: copyQuickHelpText }, ['빠른 도움말'])
        ])
      ]),

      el('div', { class: 'eht-save-card eht-support-card' }, [
        el('div', { class: 'eht-mini-title', text: '버그제보' }),
        el('p', { class: 'eht-guide-body', text: '문제 상황을 제보할 때 필요한 진단 정보와 템플릿을 복사합니다.' }),
        el('div', { class: 'eht-action-row eht-wrap-row' }, [
          el('button', { class: 'eht-main-btn', onclick: copyBugReportTemplate }, ['버그제보 템플릿']),
          el('button', { class: 'eht-link-btn', onclick: copyDiagnosticsReport }, ['진단 JSON']),
          el('button', { class: 'eht-link-btn', onclick: copyReleasePostText }, ['릴리즈 공지'])
        ])
      ]),

      el('div', { class: 'eht-support-grid' }, [
        el('div', { class: 'eht-save-card eht-support-mini' }, [
          el('div', { class: 'eht-mini-title', text: 'Chromium판' }),
          el('p', { class: 'eht-guide-body', text: 'Chrome, Edge, Whale, Brave 등 Chromium 기반 브라우저에서 사용합니다. 개발자 모드 ZIP 설치본은 새 ZIP을 받아 다시 로드합니다.' })
        ]),
        el('div', { class: 'eht-save-card eht-support-mini' }, [
          el('div', { class: 'eht-mini-title', text: 'Firefox판' }),
          el('p', { class: 'eht-guide-body', text: 'Firefox 전용 빌드입니다. AMO 서명판 또는 signed XPI를 사용하는 것을 권장합니다.' })
        ])
      ]),

      el('div', { class: 'eht-coming-soon' }, [
        el('strong', { text: '문의 대응 팁' }),
        el('span', { text: '설치 문제는 브라우저 종류와 사용한 파일명을 먼저 확인하면 빠르게 해결됩니다.' })
      ])
    ]);
  }

  function ensureCodeVault() {
    if (!Array.isArray(state.codeVault)) state.codeVault = [];
    return state.codeVault;
  }

  function createCodeEntryFromInputs(titleInput, langInput, tagsInput, descInput, codeInput) {
    const title = (titleInput.value || '').trim() || `코드 ${ensureCodeVault().length + 1}`;
    const language = (langInput.value || '').trim() || 'text';
    const tags = (tagsInput.value || '').trim();
    const description = (descInput.value || '').trim();
    const code = String(codeInput.value || '');
    if (!code.trim()) {
      toast('저장할 코드가 비어 있습니다.');
      return false;
    }
    ensureCodeVault().unshift({
      id: `code-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
      title,
      language,
      tags,
      description,
      code,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    });
    bumpStat('codeVaultSaves');
    saveLocalNow();
    toast('코드 저장 완료');
    render();
    return true;
  }

  function updateCodeEntry(id, nextCode) {
    const item = ensureCodeVault().find(entry => entry.id === id);
    if (!item) return;
    item.code = String(nextCode || '');
    item.updatedAt = new Date().toISOString();
    bumpStat('codeVaultEdits');
    saveLocalNow();
    toast('코드 수정 저장 완료');
    render();
  }

  function deleteCodeEntry(id) {
    const item = ensureCodeVault().find(entry => entry.id === id);
    if (!item) return;
    const ok = confirm(`“${item.title}” 코드를 삭제할까요?`);
    if (!ok) return;
    state.codeVault = ensureCodeVault().filter(entry => entry.id !== id);
    saveLocalNow();
    toast('코드 삭제 완료');
    render();
  }

  function copyCodeEntry(item) {
    bumpStat('codeVaultCopies');
    copyText(item.code || '', `${item.title} 코드 복사 완료`);
  }

  function insertCodeEntry(item) {
    const ok = insertIntoTarget(item.code || '');
    if (ok) bumpStat('codeVaultInserts');
  }

  function codeEntryToNotes(item) {
    appendToNotes([
      `제목: ${item.title}`,
      `언어: ${item.language || 'text'}`,
      item.tags ? `태그: ${item.tags}` : '',
      item.description ? `설명: ${item.description}` : '',
      '',
      '```' + (item.language || ''),
      item.code || '',
      '```'
    ].filter(Boolean).join('\n'), '코드저장');
    bumpStat('codeVaultToNotes');
  }

  function makeCodeVaultExport() {
    return {
      type: 'radiance-code-vault',
      version: getManifestVersionLabel(),
      exportedAt: new Date().toISOString(),
      items: ensureCodeVault()
    };
  }

  function copyCodeVaultJson() {
    copyText(JSON.stringify(makeCodeVaultExport(), null, 2), '코드 보관함 JSON 복사 완료');
  }

  function downloadCodeVaultJson() {
    const data = JSON.stringify(makeCodeVaultExport(), null, 2);
    const blob = new Blob([data], { type: 'application/json;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const stamp = new Date().toISOString().replace(/[:.]/g, '-');
    const a = document.createElement('a');
    a.href = url;
    a.download = `radiance-code-vault-${stamp}.json`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
    toast('코드 보관함 JSON 다운로드 완료');
  }

  function importCodeVaultJson(raw) {
    let parsed;
    try {
      parsed = JSON.parse(String(raw || '').trim());
    } catch {
      toast('JSON 형식이 올바르지 않습니다.');
      return false;
    }
    const items = Array.isArray(parsed) ? parsed : parsed?.items;
    if (!Array.isArray(items)) {
      toast('코드 보관함 JSON이 아닙니다.');
      return false;
    }
    const normalized = items.map((item, index) => ({
      id: String(item.id || `imported-code-${Date.now()}-${index}`),
      title: String(item.title || `가져온 코드 ${index + 1}`),
      language: String(item.language || item.lang || 'text'),
      tags: String(item.tags || ''),
      description: String(item.description || item.desc || ''),
      code: String(item.code || item.body || ''),
      createdAt: String(item.createdAt || new Date().toISOString()),
      updatedAt: new Date().toISOString()
    })).filter(item => item.code.trim());
    if (!normalized.length) {
      toast('가져올 코드가 없습니다.');
      return false;
    }
    state.codeVault = [...normalized, ...ensureCodeVault()];
    bumpStat('codeVaultImports');
    saveLocalNow();
    toast(`${normalized.length}개 코드 가져오기 완료`);
    render();
    return true;
  }

  function renderCodeVault() {
    const vault = ensureCodeVault();
    const titleInput = el('input', { class: 'eht-input', placeholder: '제목 예: 플레이어 이동 코드' });
    const langInput = el('input', { class: 'eht-input', placeholder: '언어 예: js / py / css / entry / json' });
    const tagsInput = el('input', { class: 'eht-input', placeholder: '태그 예: 물리, UI, 타이포' });
    const descInput = el('input', { class: 'eht-input', placeholder: '설명 예: 점프맵 이동 처리' });
    const codeInput = el('textarea', {
      class: 'eht-textarea eht-code-vault-editor',
      placeholder: '여기에 실제 코드를 붙여넣고 저장하세요.',
      spellcheck: 'false'
    });

    const importBox = el('textarea', {
      class: 'eht-textarea eht-code-vault-import',
      placeholder: '코드 보관함 JSON을 붙여넣고 가져오기',
      spellcheck: 'false'
    });

    return el('div', { class: 'eht-section eht-code-vault-section' }, [
      sectionIntro('코드보관함', '이 기능은 보관/백업용 레거시 기능입니다. 엔트리 블록 직접 삽입은 별도 실험툴에서 다룹니다.'),
      renderTargetMini(),
      el('div', { class: 'eht-status-grid' }, [
        statusChip('저장된 코드', `${vault.length}개`, vault.length > 0),
        statusChip('저장 위치', '브라우저 로컬', true),
        statusChip('백업 포함', '지원', true),
        statusChip('외부 전송', '없음', true)
      ]),

      el('div', { class: 'eht-save-card eht-code-vault-card' }, [
        el('div', { class: 'eht-mini-title', text: '새 코드 저장' }),
        titleInput,
        el('div', { class: 'eht-code-vault-row' }, [langInput, tagsInput]),
        descInput,
        codeInput,
        el('div', { class: 'eht-action-row eht-wrap-row' }, [
          el('button', { class: 'eht-main-btn', onclick: () => createCodeEntryFromInputs(titleInput, langInput, tagsInput, descInput, codeInput) }, ['코드 저장']),
          el('button', { class: 'eht-link-btn', onclick: () => { titleInput.value = ''; langInput.value = ''; tagsInput.value = ''; descInput.value = ''; codeInput.value = ''; } }, ['비우기'])
        ])
      ]),

      el('div', { class: 'eht-save-card eht-code-vault-card' }, [
        el('div', { class: 'eht-mini-title', text: '코드 보관함 백업' }),
        el('div', { class: 'eht-action-row eht-wrap-row' }, [
          el('button', { class: 'eht-main-btn', onclick: downloadCodeVaultJson }, ['JSON 다운로드']),
          el('button', { class: 'eht-link-btn', onclick: copyCodeVaultJson }, ['JSON 복사'])
        ]),
        importBox,
        el('div', { class: 'eht-action-row eht-wrap-row' }, [
          el('button', { class: 'eht-link-btn', onclick: () => importCodeVaultJson(importBox.value) }, ['JSON 가져오기']),
          el('button', { class: 'eht-link-btn', onclick: () => { importBox.value = ''; } }, ['비우기'])
        ])
      ]),

      el('div', { class: 'eht-mini-title', text: '저장된 코드' }),
      vault.length
        ? el('div', { class: 'eht-code-vault-list' }, vault.map(renderCodeVaultItem))
        : el('div', { class: 'eht-empty-card', text: '아직 저장된 코드가 없습니다.' })
    ]);
  }

  function renderCodeVaultItem(item) {
    const editor = el('textarea', {
      class: 'eht-textarea eht-code-vault-view',
      spellcheck: 'false'
    });
    editor.value = item.code || '';

    return el('div', { class: 'eht-save-card eht-code-vault-item' }, [
      el('div', { class: 'eht-code-vault-head' }, [
        el('div', {}, [
          el('strong', { text: item.title || '제목 없음' }),
          el('span', { text: `${item.language || 'text'}${item.tags ? ` · ${item.tags}` : ''}` })
        ]),
        el('em', { text: item.updatedAt ? new Date(item.updatedAt).toLocaleDateString() : '' })
      ]),
      item.description ? el('p', { class: 'eht-guide-body', text: item.description }) : document.createTextNode(''),
      editor,
      el('div', { class: 'eht-action-row eht-wrap-row' }, [
        el('button', { class: 'eht-main-btn', onclick: () => copyCodeEntry(item) }, ['코드 복사']),
        el('button', { class: 'eht-link-btn', onclick: () => insertCodeEntry(item) }, ['입력']),
        el('button', { class: 'eht-link-btn', onclick: () => updateCodeEntry(item.id, editor.value) }, ['수정 저장']),
        el('button', { class: 'eht-link-btn', onclick: () => codeEntryToNotes(item) }, ['메모로']),
        el('button', { class: 'eht-link-btn', onclick: () => deleteCodeEntry(item.id) }, ['삭제'])
      ])
    ]);
  }

  function ensurePalette() {
    if (!Array.isArray(state.palette)) state.palette = [];
    return state.palette;
  }

  function normalizeHex(value) {
    const raw = String(value || '').trim();
    if (!raw) return '';
    let hex = raw.startsWith('#') ? raw : `#${raw}`;
    if (/^#[0-9a-fA-F]{3}$/.test(hex)) {
      hex = '#' + hex.slice(1).split('').map(ch => ch + ch).join('');
    }
    if (!/^#[0-9a-fA-F]{6}$/.test(hex)) return '';
    return hex.toUpperCase();
  }

  function safeCssVarName(name, role = 'color') {
    const source = String(name || role || 'color').trim().toLowerCase();
    const safe = source
      .replace(/[^a-z0-9가-힣_-]+/gi, '-')
      .replace(/^-+|-+$/g, '');
    return safe || 'color';
  }

  function createPaletteColor(nameInput, hexInput, roleInput, noteInput) {
    const hex = normalizeHex(hexInput.value);
    if (!hex) {
      toast('HEX 색상 형식이 올바르지 않습니다.');
      return false;
    }
    const palette = ensurePalette();
    palette.unshift({
      id: `color-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
      name: (nameInput.value || '').trim() || `색상 ${palette.length + 1}`,
      hex,
      role: roleInput.value || '기타',
      note: (noteInput.value || '').trim(),
      createdAt: new Date().toISOString()
    });
    bumpStat('paletteAdds');
    saveLocalNow();
    toast('색상 저장 완료');
    render();
    return true;
  }

  function deletePaletteColor(id) {
    const item = ensurePalette().find(color => color.id === id);
    if (!item) return;
    const ok = confirm(`“${item.name}” 색상을 삭제할까요?`);
    if (!ok) return;
    state.palette = ensurePalette().filter(color => color.id !== id);
    saveLocalNow();
    toast('색상 삭제 완료');
    render();
  }

  function copyPaletteHex(item) {
    bumpStat('paletteCopies');
    copyText(item.hex, `${item.hex} 복사 완료`);
  }

  function copyPaletteCssVar(item) {
    bumpStat('paletteCssCopies');
    copyText(`--${safeCssVarName(item.name, item.role)}: ${item.hex};`, 'CSS 변수 복사 완료');
  }

  function paletteText() {
    const colors = ensurePalette();
    if (!colors.length) return '저장된 색상이 없습니다.';
    return colors.map(color => {
      const note = color.note ? ` // ${color.note}` : '';
      return `${color.role || '기타'} · ${color.name}: ${color.hex}${note}`;
    }).join('\n');
  }

  function paletteCssText() {
    const colors = ensurePalette();
    if (!colors.length) return ':root {\n  --color: #A1A1FF;\n}';
    const lines = colors.map(color => `  --${safeCssVarName(color.name, color.role)}: ${color.hex};`);
    return [':root {', ...lines, '}'].join('\n');
  }

  function copyPaletteAll() {
    bumpStat('paletteAllCopies');
    copyText(paletteText(), '팔레트 전체 복사 완료');
  }

  function copyPaletteCssAll() {
    bumpStat('paletteCssCopies');
    copyText(paletteCssText(), '팔레트 CSS 복사 완료');
  }

  function paletteToNotes() {
    appendToNotes(paletteText(), '색상 팔레트');
    bumpStat('paletteToNotes');
  }

  function addPalettePreset(presetId) {
    const preset = PALETTE_PRESETS.find(item => item.id === presetId);
    if (!preset) return;
    const stamp = new Date().toISOString();
    const existing = ensurePalette();
    const items = preset.colors.map((color, index) => ({
      id: `preset-${preset.id}-${Date.now()}-${index}`,
      name: color.name,
      hex: normalizeHex(color.hex),
      role: color.role || '기타',
      note: preset.title,
      createdAt: stamp
    }));
    state.palette = [...items, ...existing];
    bumpStat('palettePresetUses');
    saveLocalNow();
    toast(`${preset.title} 팔레트 추가 완료`);
    render();
  }

  function exportPaletteJson() {
    const data = {
      type: 'radiance-palette',
      version: getManifestVersionLabel(),
      exportedAt: new Date().toISOString(),
      colors: ensurePalette()
    };
    copyText(JSON.stringify(data, null, 2), '팔레트 JSON 복사 완료');
  }

  function renderPalette() {
    const palette = ensurePalette();
    const nameInput = el('input', { class: 'eht-input', placeholder: '색 이름 예: Radiance Main' });
    const hexInput = el('input', { class: 'eht-input', placeholder: '#A1A1FF 또는 A1A1FF' });
    const roleInput = el('select', { class: 'eht-input' }, PALETTE_ROLES.map(role => el('option', { value: role, text: role })));
    const noteInput = el('input', { class: 'eht-input', placeholder: '메모 예: 버튼 강조색 / 로고색' });

    hexInput.addEventListener('input', () => {
      const hex = normalizeHex(hexInput.value);
      hexInput.style.borderColor = hex ? 'rgba(34,197,94,0.55)' : '';
    });

    return el('div', { class: 'eht-section eht-palette-section' }, [
      sectionIntro('팔레트', '프로젝트 색상 HEX를 저장하고 복사해서 작품 설명, 썸네일, 타이포 작업에 활용합니다.'),
      el('div', { class: 'eht-status-grid' }, [
        statusChip('저장 색상', `${palette.length}개`, palette.length > 0),
        statusChip('프리셋', `${PALETTE_PRESETS.length}개`, true),
        statusChip('복사 방식', 'HEX / CSS', true),
        statusChip('외부 전송', '없음', true)
      ]),

      el('div', { class: 'eht-save-card eht-palette-card' }, [
        el('div', { class: 'eht-mini-title', text: '색상 저장' }),
        nameInput,
        el('div', { class: 'eht-palette-row' }, [hexInput, roleInput]),
        noteInput,
        el('div', { class: 'eht-action-row eht-wrap-row' }, [
          el('button', { class: 'eht-main-btn', onclick: () => createPaletteColor(nameInput, hexInput, roleInput, noteInput) }, ['색상 저장']),
          el('button', { class: 'eht-link-btn', onclick: () => { nameInput.value = ''; hexInput.value = ''; noteInput.value = ''; } }, ['비우기'])
        ])
      ]),

      el('div', { class: 'eht-save-card eht-palette-card' }, [
        el('div', { class: 'eht-mini-title', text: '팔레트 프리셋' }),
        el('div', { class: 'eht-palette-preset-grid' }, PALETTE_PRESETS.map(preset =>
          el('button', { class: 'eht-palette-preset', onclick: () => addPalettePreset(preset.id) }, [
            el('strong', { text: preset.title }),
            el('span', { text: preset.desc }),
            el('div', { class: 'eht-swatch-row' }, preset.colors.map(color =>
              el('i', { class: 'eht-swatch-dot', style: `background:${normalizeHex(color.hex)}` })
            ))
          ])
        ))
      ]),

      el('div', { class: 'eht-save-card eht-palette-card' }, [
        el('div', { class: 'eht-mini-title', text: '팔레트 내보내기' }),
        el('div', { class: 'eht-action-row eht-wrap-row' }, [
          el('button', { class: 'eht-main-btn', onclick: copyPaletteAll }, ['전체 복사']),
          el('button', { class: 'eht-link-btn', onclick: copyPaletteCssAll }, ['CSS 변수 복사']),
          el('button', { class: 'eht-link-btn', onclick: paletteToNotes }, ['메모로']),
          el('button', { class: 'eht-link-btn', onclick: exportPaletteJson }, ['JSON 복사'])
        ])
      ]),

      el('div', { class: 'eht-mini-title', text: '저장된 색상' }),
      palette.length
        ? el('div', { class: 'eht-palette-list' }, palette.map(renderPaletteItem))
        : el('div', { class: 'eht-empty-card', text: '아직 저장된 색상이 없습니다. 프리셋을 추가하거나 HEX를 직접 저장해 보세요.' })
    ]);
  }

  function renderPaletteItem(item) {
    const hex = normalizeHex(item.hex) || '#A1A1FF';
    return el('div', { class: 'eht-save-card eht-palette-item' }, [
      el('div', { class: 'eht-palette-swatch', style: `background:${hex}` }),
      el('div', { class: 'eht-palette-info' }, [
        el('strong', { text: item.name || '색상' }),
        el('span', { text: `${item.role || '기타'} · ${hex}${item.note ? ` · ${item.note}` : ''}` })
      ]),
      el('div', { class: 'eht-action-row eht-wrap-row' }, [
        el('button', { class: 'eht-main-btn', onclick: () => copyPaletteHex(item) }, ['HEX']),
        el('button', { class: 'eht-link-btn', onclick: () => copyPaletteCssVar(item) }, ['CSS']),
        el('button', { class: 'eht-link-btn', onclick: () => appendToNotes(`${item.role || '기타'} · ${item.name}: ${hex}`, '색상') }, ['메모']),
        el('button', { class: 'eht-link-btn', onclick: () => deletePaletteColor(item.id) }, ['삭제'])
      ])
    ]);
  }


  function defaultBgmState() {
    return {
      url: '',
      videoId: '',
      title: '',
      favorites: [],
      expanded: true
    };
  }

  function ensureBgmState() {
    if (!state.bgmRoom || typeof state.bgmRoom !== 'object') state.bgmRoom = defaultBgmState();
    state.bgmRoom = Object.assign(defaultBgmState(), state.bgmRoom);
    if (!Array.isArray(state.bgmRoom.favorites)) state.bgmRoom.favorites = [];
    state.bgmRoom.favorites = state.bgmRoom.favorites.filter(Boolean).slice(0, 8);
    return state.bgmRoom;
  }

  function extractYouTubeVideoId(input) {
    const value = String(input || '').trim();
    if (!value) return '';
    const direct = value.match(/^[a-zA-Z0-9_-]{11}$/);
    if (direct) return value;
    try {
      const url = new URL(value);
      const host = url.hostname.replace(/^www\./, '');
      if (host === 'youtu.be') return (url.pathname.split('/').filter(Boolean)[0] || '').slice(0, 11);
      if (host.endsWith('youtube.com') || host.endsWith('youtube-nocookie.com')) {
        if (url.searchParams.get('v')) return url.searchParams.get('v').slice(0, 11);
        const parts = url.pathname.split('/').filter(Boolean);
        const marker = parts.findIndex(part => ['embed', 'shorts', 'live'].includes(part));
        if (marker >= 0 && parts[marker + 1]) return parts[marker + 1].slice(0, 11);
      }
    } catch {}
    const loose = value.match(/(?:v=|youtu\.be\/|embed\/|shorts\/|live\/)([a-zA-Z0-9_-]{11})/);
    return loose?.[1] || '';
  }

  function youtubeWatchUrl(videoId) {
    return videoId ? `https://www.youtube.com/watch?v=${videoId}` : '';
  }

  function youtubeEmbedUrl(videoId) {
    return videoId ? `https://www.youtube-nocookie.com/embed/${videoId}?rel=0&modestbranding=1` : '';
  }

  function applyBgmUrl(url, source = 'manual') {
    const bgm = ensureBgmState();
    const videoId = extractYouTubeVideoId(url);
    if (!videoId) {
      toast('YouTube 링크를 확인해 주세요.');
      return false;
    }
    bgm.url = youtubeWatchUrl(videoId);
    bgm.videoId = videoId;
    bgm.title = bgm.title || `YouTube BGM ${videoId}`;
    bgm.expanded = true;
    state.stats = state.stats || {};
    state.stats.bgmLoads = Number(state.stats.bgmLoads || 0) + 1;
    if (source === 'favorite') state.stats.bgmFavoritePlays = Number(state.stats.bgmFavoritePlays || 0) + 1;
    saveLocalNow();
    refreshBadges(true);
    toast('BGM Room에 YouTube 플레이어 적용');
    render();
    return true;
  }


  function openBgmPlayerWindow(item = null) {
    const bgm = ensureBgmState();
    const videoId = item?.videoId || bgm.videoId || extractYouTubeVideoId(bgm.url);
    if (!videoId) {
      toast('먼저 YouTube 링크를 적용해 주세요.');
      return;
    }

    const fallbackOpen = () => {
      const player = window.open(
        youtubeWatchUrl(videoId),
        'radiance_youtube_bgm_player',
        'popup=yes,width=960,height=640,left=80,top=80'
      );
      return Boolean(player);
    };

    try {
      chrome.runtime.sendMessage({
        type: 'RADIANCE_OPEN_YOUTUBE_WINDOW',
        videoId
      }, response => {
        const err = chrome.runtime.lastError;
        const ok = !err && response?.ok;
        if (!ok) {
          console.warn('Radiance background BGM open failed, falling back', err || response);
          if (!fallbackOpen()) {
            toast('BGM 창을 열지 못했습니다. 팝업 허용을 확인해 주세요.');
            return;
          }
        }

        state.stats = state.stats || {};
        state.stats.bgmWindowOpens = Number(state.stats.bgmWindowOpens || 0) + 1;
        saveLocalNow();
        refreshBadges(true);
        toast(ok ? 'Background로 YouTube BGM 창 열림' : 'YouTube BGM 창 열림');
      });
    } catch (error) {
      console.warn('Radiance YouTube window error', error);
      if (!fallbackOpen()) toast('BGM 창을 열지 못했습니다.');
    }
  }


  function saveCurrentBgmFavorite() {
    const bgm = ensureBgmState();
    if (!bgm.videoId) {
      toast('먼저 YouTube 링크를 적용해 주세요.');
      return;
    }
    const item = {
      videoId: bgm.videoId,
      url: youtubeWatchUrl(bgm.videoId),
      title: bgm.title || `YouTube BGM ${bgm.videoId}`,
      savedAt: new Date().toISOString()
    };
    bgm.favorites = [item, ...bgm.favorites.filter(fav => fav.videoId !== item.videoId)].slice(0, 8);
    saveLocalNow();
    toast('BGM 즐겨찾기 저장');
    render();
  }

  function removeBgmFavorite(videoId) {
    const bgm = ensureBgmState();
    bgm.favorites = bgm.favorites.filter(item => item.videoId !== videoId);
    saveLocalNow();
    render();
  }

  function clearBgmRoom() {
    state.bgmRoom = Object.assign(defaultBgmState(), { favorites: ensureBgmState().favorites });
    saveLocalNow();
    toast('BGM 플레이어 비움');
    render();
  }

  function recordBgmToNotes() {
    const bgm = ensureBgmState();
    if (!bgm.videoId) {
      toast('기록할 BGM이 없습니다.');
      return;
    }
    const line = `[BGM] ${bgm.title || 'YouTube BGM'} · ${youtubeWatchUrl(bgm.videoId)}`;
    state.notes = `${state.notes || ''}${state.notes ? '\n' : ''}${line}`;
    saveLocalNow();
    toast('메모에 BGM 기록');
    render();
  }

  function recordBgmToTimeline() {
    const bgm = ensureBgmState();
    if (!bgm.videoId) {
      toast('기록할 BGM이 없습니다.');
      return;
    }
    const line = `00.0s  BGM 시작 · ${bgm.title || 'YouTube BGM'} · ${youtubeWatchUrl(bgm.videoId)}`;
    state.timeline = `${state.timeline || ''}${state.timeline ? '\n' : ''}${line}`;
    saveLocalNow();
    toast('타임라인에 BGM 기록');
    render();
  }

  function toggleBgmExpanded() {
    const bgm = ensureBgmState();
    bgm.expanded = !bgm.expanded;
    saveLocalNow();
    render();
  }

  function renderBgmRoom() {
    const bgm = ensureBgmState();
    const hasVideo = Boolean(bgm.videoId);
    return el('div', { class: 'eht-section eht-bgm-section' }, [
      sectionIntro('YouTube BGM Room', '유튜브 링크를 붙여넣고 엔트리 작업 중 패널 안에서 BGM처럼 재생합니다. 자동재생/다운로드/음원추출은 하지 않습니다.'),
      el('div', { class: 'eht-bgm-window-note' }, [
        el('strong', { text: '분리 창 모드' }),
        el('span', { text: 'V2에서는 background service worker가 YouTube 원본 창을 열어줍니다. 오류 153을 피하려고 확장 내부 iframe 분리창은 쓰지 않습니다.' })
      ]),
      el('div', { class: 'eht-bgm-card' }, [
        el('div', { class: 'eht-input-row' }, [
          el('input', {
            class: 'eht-input',
            placeholder: 'YouTube 링크 또는 영상 ID',
            value: bgm.url || '',
            oninput: event => {
              ensureBgmState().url = event.target.value;
              saveLocal();
            },
            onkeydown: event => {
              if (event.key === 'Enter') applyBgmUrl(event.currentTarget.value);
            }
          }),
          el('button', { class: 'eht-main-btn', onclick: () => applyBgmUrl(ensureBgmState().url) }, ['적용'])
        ]),
        hasVideo ? el('div', { class: 'eht-bgm-player-wrap' }, [
          bgm.expanded
            ? el('iframe', {
                class: 'eht-bgm-player',
                src: youtubeEmbedUrl(bgm.videoId),
                title: 'Radiance YouTube BGM Player',
                allow: 'accelerometer; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share',
                allowfullscreen: 'true',
                referrerpolicy: 'strict-origin-when-cross-origin'
              })
            : el('div', { class: 'eht-bgm-collapsed' }, [
                el('strong', { text: 'BGM 플레이어 숨김' }),
                el('span', { text: youtubeWatchUrl(bgm.videoId) })
              ])
        ]) : el('div', { class: 'eht-empty-state' }, [
          el('strong', { text: '아직 BGM이 없습니다.' }),
          el('span', { text: '유튜브 링크를 붙여넣고 적용을 누르세요.' })
        ]),
        el('div', { class: 'eht-action-row eht-wrap-row' }, [
          el('button', { class: 'eht-link-btn', onclick: toggleBgmExpanded }, [bgm.expanded ? '플레이어 숨기기' : '플레이어 보이기']),
          el('button', { class: 'eht-main-btn', onclick: () => openBgmPlayerWindow() }, ['분리 창 열기']),
          el('button', { class: 'eht-link-btn', onclick: saveCurrentBgmFavorite }, ['즐겨찾기 저장']),
          el('button', { class: 'eht-link-btn', onclick: recordBgmToNotes }, ['메모에 기록']),
          el('button', { class: 'eht-link-btn', onclick: recordBgmToTimeline }, ['타임라인 기록']),
          el('button', { class: 'eht-link-btn', onclick: clearBgmRoom }, ['비우기'])
        ])
      ]),
      el('div', { class: 'eht-mini-title', text: 'BGM 즐겨찾기' }),
      bgm.favorites.length
        ? el('div', { class: 'eht-bgm-favorites' }, bgm.favorites.map(item => renderBgmFavorite(item)))
        : el('div', { class: 'eht-hint', text: '즐겨찾기를 저장하면 다음 작업 때 바로 불러올 수 있습니다.' }),
      renderQualityBoostTeaser()
    ]);
  }

  function renderBgmFavorite(item) {
    return el('div', { class: 'eht-bgm-fav' }, [
      el('button', {
        class: 'eht-bgm-fav-main',
        onclick: () => {
          ensureBgmState().title = item.title || `YouTube BGM ${item.videoId}`;
          applyBgmUrl(item.url || item.videoId, 'favorite');
        }
      }, [
        el('strong', { text: item.title || `YouTube BGM ${item.videoId}` }),
        el('span', { text: youtubeWatchUrl(item.videoId) })
      ]),
      el('button', { class: 'eht-icon-btn', title: '분리 창', onclick: () => openBgmPlayerWindow(item) }, ['↗']),
      el('button', { class: 'eht-icon-btn', title: '삭제', onclick: () => removeBgmFavorite(item.videoId) }, ['×'])
    ]);
  }

  function renderQualityBoostTeaser() {
    const quality = ensureQualityBoostState();
    return el('div', { class: 'eht-quality-teaser' }, [
      el('div', { class: 'eht-mini-title', text: 'Radiance Quality Boost V2' }),
      el('div', { class: 'eht-hint', text: `640×400 계열 canvas 후보에 선명도 보정/캡처 프레임/확대 실험을 적용합니다. 현재 상태: ${quality.enabled ? 'ON' : 'OFF'}` }),
      el('div', { class: 'eht-quality-grid' }, [
        el('span', { text: '선명도 보정' }),
        el('span', { text: '캡처 프레임' }),
        el('span', { text: '확대 실험' })
      ]),
      el('button', { class: 'eht-main-btn', onclick: () => switchTab('quality') }, ['Quality Boost 열기'])
    ]);
  }


  function defaultQualityBoostState() {
    return {
      enabled: false,
      mode: 'balanced',
      zoom: 1,
      captureFrame: false,
      lastCount: 0,
      lastScanAt: ''
    };
  }

  function ensureQualityBoostState() {
    if (!state.qualityBoost || typeof state.qualityBoost !== 'object') state.qualityBoost = defaultQualityBoostState();
    state.qualityBoost = Object.assign(defaultQualityBoostState(), state.qualityBoost);
    const allowedModes = ['balanced', 'smooth', 'sharp'];
    if (!allowedModes.includes(state.qualityBoost.mode)) state.qualityBoost.mode = 'balanced';
    const zoom = Number(state.qualityBoost.zoom);
    state.qualityBoost.zoom = Number.isFinite(zoom) ? Math.min(1.6, Math.max(1, zoom)) : 1;
    state.qualityBoost.lastCount = Number(state.qualityBoost.lastCount || 0);
    return state.qualityBoost;
  }

  function qualityBoostCandidates() {
    const canvases = Array.from(document.querySelectorAll('canvas'));
    return canvases.filter(canvas => {
      const width = Number(canvas.width || canvas.getAttribute('width') || 0);
      const height = Number(canvas.height || canvas.getAttribute('height') || 0);
      const rect = canvas.getBoundingClientRect();
      const ratio = rect.height ? rect.width / rect.height : (height ? width / height : 0);
      const entrySize = (width === 640 && height === 400) || (Math.abs(width / Math.max(height, 1) - 1.6) < 0.08 && width >= 300 && height >= 180);
      const visibleSize = rect.width >= 180 && rect.height >= 110 && Math.abs(ratio - 1.6) < 0.22;
      const idClassHint = `${canvas.id || ''} ${canvas.className || ''}`.toLowerCase();
      const entryHint = /entry|stage|canvas|workspace|play/.test(idClassHint);
      return entrySize || visibleSize || entryHint;
    }).slice(0, 24);
  }

  function clearQualityBoostTargets() {
    document.querySelectorAll('[data-radiance-quality-target="1"]').forEach(node => {
      node.removeAttribute('data-radiance-quality-target');
    });
  }

  function qualityModeCss(mode) {
    if (mode === 'sharp') return 'image-rendering:-webkit-optimize-contrast !important;image-rendering:crisp-edges !important;filter:contrast(1.08) saturate(1.03);';
    if (mode === 'smooth') return 'image-rendering:auto !important;filter:contrast(1.02) saturate(1.02);';
    return 'image-rendering:auto !important;filter:contrast(1.05) saturate(1.035);';
  }

  function syncQualityFrameState() {
    const quality = ensureQualityBoostState();
    const payload = {
      enabled: quality.enabled,
      mode: quality.mode,
      zoom: quality.zoom,
      captureFrame: quality.captureFrame
    };
    try {
      chrome.storage.local.set({ [QUALITY_FRAME_STORAGE_KEY]: payload });
    } catch (error) {
      console.warn('Radiance quality frame storage sync failed', error);
    }
    return payload;
  }

  function applyQualityBoost(showToast = false) {
    const quality = ensureQualityBoostState();
    const framePayload = syncQualityFrameState();

    let style = document.getElementById(`${APP_ID}-quality-style`);
    if (!style) {
      style = document.createElement('style');
      style.id = `${APP_ID}-quality-style`;
      document.documentElement.append(style);
    }

    clearQualityBoostTargets();

    if (!quality.enabled) {
      style.textContent = '';
      quality.lastCount = 0;
      quality.lastScanAt = new Date().toISOString();
      if (showToast) toast('Quality Boost 꺼짐');
      return [];
    }

    const targets = qualityBoostCandidates();
    targets.forEach(canvas => {
      canvas.setAttribute('data-radiance-quality-target', '1');
    });

    const zoom = Math.min(1.6, Math.max(1, Number(quality.zoom || 1)));
    const transform = zoom > 1 ? `transform:translateZ(0) scale(${zoom});transform-origin:center center;` : 'transform:translateZ(0);';
    const capture = quality.captureFrame ? 'outline:2px solid rgba(161,161,255,0.82) !important;box-shadow:0 0 0 4px rgba(161,161,255,0.18),0 18px 42px rgba(0,0,0,0.28) !important;' : '';
    style.textContent = `
      canvas[data-radiance-quality-target="1"] {
        ${qualityModeCss(quality.mode)}
        ${transform}
        backface-visibility:hidden !important;
        will-change:transform,filter !important;
        ${capture}
      }
    `;

    quality.lastCount = targets.length;
    quality.lastScanAt = new Date().toISOString();
    state.stats = state.stats || {};
    state.stats.qualityBoostApplies = Number(state.stats.qualityBoostApplies || 0) + 1;
    if (quality.enabled) state.stats.qualityBoostUses = Math.max(1, Number(state.stats.qualityBoostUses || 0));
    saveLocal();

    try {
      chrome.runtime.sendMessage({ type: 'RADIANCE_QUALITY_BROADCAST', state: framePayload }, () => {});
    } catch {}

    refreshBadges(true);
    if (showToast) toast(`Quality Boost 적용 · 현재 프레임 ${targets.length}개 + 내부 프레임 동기화`);
    return targets;
  }

  function setQualityBoostPatch(patch, rerender = true) {
    const quality = ensureQualityBoostState();
    Object.assign(quality, patch);
    saveLocalNow();
    applyQualityBoost(true);
    if (rerender) render();
  }

  function renderQualityBoost() {
    const quality = ensureQualityBoostState();
    const liveCount = qualityBoostCandidates().length;
    const lastScan = quality.lastScanAt ? new Date(quality.lastScanAt).toLocaleTimeString() : '아직 없음';

    return el('div', { class: 'eht-section eht-quality-section' }, [
      sectionIntro('Radiance Quality Boost V2', '엔트리 원본 해상도를 직접 바꾸는 기능은 아니고, 640×400 계열 canvas 후보에 선명도/캡처/확대 보정을 안전하게 얹는 실험실입니다.'),
      el('div', { class: 'eht-quality-frame-note' }, [
        el('strong', { text: 'V2 프레임 감지' }),
        el('span', { text: '화질 보정 전용 스크립트가 내부 프레임에도 들어가 canvas를 각 프레임 안에서 직접 감지합니다.' })
      ]),
      el('div', { class: 'eht-status-grid' }, [
        statusChip('Boost', quality.enabled ? 'ON' : 'OFF', quality.enabled),
        statusChip('후보 canvas', `${liveCount}개`, liveCount > 0),
        statusChip('모드', quality.mode, true),
        statusChip('최근 적용', `${quality.lastCount || 0}개`, (quality.lastCount || 0) > 0)
      ]),
      el('div', { class: 'eht-quality-v2-card' }, [
        el('div', { class: 'eht-mini-title', text: '화질 보정' }),
        el('div', { class: 'eht-quality-toggle-row' }, [
          el('button', { class: quality.enabled ? 'eht-main-btn' : 'eht-link-btn', onclick: () => setQualityBoostPatch({ enabled: !quality.enabled }) }, [quality.enabled ? 'Quality Boost 끄기' : 'Quality Boost 켜기']),
          el('button', { class: 'eht-link-btn', onclick: () => applyQualityBoost(true) }, ['후보 재스캔']),
          el('button', { class: 'eht-link-btn', onclick: () => setQualityBoostPatch({ captureFrame: !quality.captureFrame }) }, [quality.captureFrame ? '캡처 프레임 끄기' : '캡처 프레임'])
        ]),
        el('div', { class: 'eht-mini-title', text: '선명도 모드' }),
        el('div', { class: 'eht-quality-mode-row' }, [
          qualityModeButton('balanced', '균형', 'contrast + smooth'),
          qualityModeButton('smooth', '부드럽게', '기본 보간 유지'),
          qualityModeButton('sharp', '선명하게', 'crisp/contrast')
        ]),
        el('div', { class: 'eht-mini-title', text: '확대 실험' }),
        el('div', { class: 'eht-quality-zoom-row' }, [
          qualityZoomButton(1, '1.0×'),
          qualityZoomButton(1.15, '1.15×'),
          qualityZoomButton(1.3, '1.3×'),
          qualityZoomButton(1.5, '1.5×')
        ]),
        el('div', { class: 'eht-hint', text: `최근 스캔: ${lastScan} · 확대는 레이아웃을 건드릴 수 있어서 필요할 때만 쓰는 실험 기능입니다.` })
      ]),
      el('div', { class: 'eht-quality-v2-warning' }, [
        el('strong', { text: '안전 제한' }),
        el('span', { text: 'Entry 프로젝트 데이터를 수정하지 않습니다. 감지된 canvas에 CSS 보정만 적용합니다. 이상하면 Quality Boost를 끄면 바로 원상복구됩니다.' })
      ])
    ]);
  }

  function qualityModeButton(mode, title, desc) {
    const quality = ensureQualityBoostState();
    const active = quality.mode === mode;
    return el('button', { class: `eht-quality-option ${active ? 'is-active' : ''}`, onclick: () => setQualityBoostPatch({ mode }) }, [
      el('strong', { text: title }),
      el('span', { text: desc })
    ]);
  }

  function qualityZoomButton(zoom, label) {
    const quality = ensureQualityBoostState();
    const active = Math.abs(Number(quality.zoom || 1) - zoom) < 0.01;
    return el('button', { class: `eht-quality-zoom ${active ? 'is-active' : ''}`, onclick: () => setQualityBoostPatch({ zoom }) }, [label]);
  }



  function getThemeId() {
    const legacyThemeMap = {
      'ancient-ruins': 'forest-ruins',
      'cyberpunk': 'winter-belltower'
    };
    const rawId = state.theme || 'sky-island';
    const migrated = legacyThemeMap[rawId] || rawId;
    if (migrated !== rawId) state.theme = migrated;
    return THEME_PRESETS.some(theme => theme.id === migrated) ? migrated : 'sky-island';
  }

  function getThemeLabel(id = getThemeId()) {
    return THEME_PRESETS.find(theme => theme.id === id)?.title || '하늘섬';
  }


  function themeAssetUrl(id = getThemeId()) {
    const theme = THEME_PRESETS.find(item => item.id === id) || THEME_PRESETS[0];
    return chrome.runtime.getURL(theme.asset || 'assets/themes/sky-island.webp');
  }

  function currentTheme() {
    return THEME_PRESETS.find(item => item.id === getThemeId()) || THEME_PRESETS[0];
  }


  function randomTheme() {
    const current = getThemeId();
    const pool = THEME_PRESETS.filter(theme => theme.id !== current);
    const next = pool[Math.floor(Math.random() * pool.length)] || THEME_PRESETS[0];
    bumpStat('randomThemeUses');
    setRadianceTheme(next.id, 'random');
  }

  function reapplyTheme() {
    const currentRoot = document.getElementById(APP_ID);
    if (currentRoot) applyThemeToNode(currentRoot);
    saveGlobalNow();
    saveLocalNow();
    toast(`${getThemeLabel()} 테마 다시 적용`);
    render();
  }


  function commandItems() {
    const tabItems = [
      ['home', '홈', 'Radiance 홈으로 이동', '🏠'],
      ['check', '체크리스트', '작업 점검 목록으로 이동', '✅'],
      ['timeline', '타임라인', '작업 흐름 기록으로 이동', '🕒'],
      ['notes', '메모', '아이디어와 기록으로 이동', '📝'],
      ['snippet', '스니펫', '자주 쓰는 코드/문구로 이동', '⌘'],
      ['palette', '팔레트', '색상 저장소로 이동', '🎨'],
      ['theme', '테마', '테마 설정으로 이동', '🪄'],
      ['bgm', 'BGM', 'YouTube BGM Room으로 이동', '🎵'],
      ['quality', '화질', 'Radiance Quality Boost V2로 이동', '✨'],
      ['pageSearch', '페이지 검색', '현재 페이지 검색으로 이동', '🔎'],
      ['save', '백업', '저장/복원 도구로 이동', '☁️'],
      ['support', '지원', '도움말과 문의로 이동', '🎧'],
      ['badges', '배지', '업적 배지 보기', '🏅'],
      ['settings', '설정', 'Radiance 설정으로 이동', '⚙️']
    ].map(([tab, title, desc, icon]) => ({
      id: `tab-${tab}`,
      title,
      desc,
      icon,
      keywords: `${title} ${desc} 이동 열기 탭`,
      run: () => {
        bumpStat('commandRuns');
        closeCommandPalette(false);
        switchTab(tab);
      }
    }));

    const themeItems = THEME_PRESETS.map(theme => ({
      id: `theme-${theme.id}`,
      title: `${theme.title} 테마 적용`,
      desc: theme.desc,
      icon: '🌈',
      keywords: `${theme.title} ${theme.desc} 테마 색상 분위기 적용`,
      run: () => {
        bumpStat('commandRuns');
        closeCommandPalette(false);
        setRadianceTheme(theme.id, 'command');
      }
    }));

    const actionItems = [
      {
        id: 'action-random-theme',
        title: '랜덤 테마 적용',
        desc: '아무 테마나 랜덤으로 바꿉니다.',
        icon: '🎲',
        keywords: '랜덤 테마 아무거나 분위기 바꾸기',
        run: () => {
          bumpStat('commandRuns');
          closeCommandPalette(false);
          randomTheme();
        }
      },
      {
        id: 'action-reapply-theme',
        title: '현재 테마 다시 적용',
        desc: '테마 이미지와 색상을 다시 적용합니다.',
        icon: '🔁',
        keywords: '테마 다시 적용 새로고침 복구',
        run: () => {
          bumpStat('commandRuns');
          closeCommandPalette(false);
          reapplyTheme();
        }
      },
      {
        id: 'action-backup',
        title: '백업 파일 내보내기',
        desc: 'Radiance 데이터를 JSON으로 내보냅니다.',
        icon: '📦',
        keywords: '백업 내보내기 저장 export json 다운로드',
        run: () => {
          bumpStat('commandRuns');
          closeCommandPalette(false);
          if (typeof downloadFullRadianceExport === 'function') downloadFullRadianceExport();
          else switchTab('backupTools');
        }
      },
      {
        id: 'action-copy-palette',
        title: '팔레트 CSS 복사',
        desc: '저장된 팔레트를 CSS 변수로 복사합니다.',
        icon: '🧩',
        keywords: '팔레트 css 변수 복사 색상',
        run: () => {
          bumpStat('commandRuns');
          closeCommandPalette(false);
          if (typeof copyPaletteCss === 'function') copyPaletteCss();
          else switchTab('palette');
        }
      },
      {
        id: 'action-search-page',
        title: '페이지 검색 바로 열기',
        desc: '페이지 검색 탭으로 이동합니다.',
        icon: '🔍',
        keywords: '검색 찾기 페이지 작품 탐색',
        run: () => {
          bumpStat('commandRuns');
          closeCommandPalette(false);
          switchTab('pageSearch');
        }
      },
      {
        id: 'action-reset-project',
        title: '현재 프로젝트 데이터 초기화',
        desc: '현재 프로젝트의 Radiance 데이터만 초기화합니다.',
        icon: '🧹',
        keywords: '초기화 리셋 reset 정리 프로젝트',
        run: () => {
          bumpStat('commandRuns');
          closeCommandPalette(false);
          resetCurrentProject();
        }
      }
    ];

    return [...tabItems, ...themeItems, ...actionItems];
  }

  function normalizeCommandText(value) {
    return String(value || '').toLowerCase().replace(/\s+/g, '');
  }

  function commandMatches(item, query) {
    const q = normalizeCommandText(query);
    if (!q) return true;
    return normalizeCommandText(`${item.title} ${item.desc} ${item.keywords}`).includes(q);
  }

  function openCommandPalette() {
    state.commandOpen = true;
    state.commandQuery = '';
    bumpStat('commandOpens');
    saveLocalNow();
    render();
    requestAnimationFrame(() => {
      document.querySelector(`#${APP_ID} .eht-command-input`)?.focus();
    });
  }

  function closeCommandPalette(shouldRender = true) {
    state.commandOpen = false;
    state.commandQuery = '';
    saveLocalNow();
    if (shouldRender) render();
  }

  function runCommand(item) {
    if (!item || typeof item.run !== 'function') return;
    item.run();
  }

  function renderCommandPalette() {
    if (!state.commandOpen) return document.createTextNode('');
    const query = state.commandQuery || '';
    const results = commandItems().filter(item => commandMatches(item, query)).slice(0, 12);
    return el('div', {
      class: 'eht-command-backdrop',
      onclick: event => {
        if (event.target.classList.contains('eht-command-backdrop')) closeCommandPalette();
      }
    }, [
      el('div', { class: 'eht-command-modal' }, [
        el('div', { class: 'eht-command-head' }, [
          el('div', {}, [
            el('strong', { text: '빠른 실행' }),
            el('span', { text: '탭 이동, 테마 적용, 백업까지 한 번에' })
          ]),
          el('button', { class: 'eht-icon-btn', onclick: () => closeCommandPalette(), title: '닫기' }, ['×'])
        ]),
        el('div', { class: 'eht-command-search' }, [
          el('span', { text: '⌘K' }),
          el('input', {
            class: 'eht-command-input',
            type: 'search',
            placeholder: '예: 메모, 우주, 백업, 팔레트...',
            value: query,
            oninput: event => {
              state.commandQuery = event.target.value;
              saveLocalNow();
              render();
            },
            onkeydown: event => {
              if (event.key === 'Escape') {
                event.preventDefault();
                closeCommandPalette();
              }
              if (event.key === 'Enter') {
                event.preventDefault();
                const first = commandItems().filter(item => commandMatches(item, state.commandQuery)).at(0);
                runCommand(first);
              }
            }
          })
        ]),
        renderCommandResults(results)
      ])
    ]);
  }

  function renderCommandResults(list = commandItems().filter(item => commandMatches(item, state.commandQuery)).slice(0, 12)) {
    return el('div', { class: 'eht-command-list' }, list.length ? list.map(item =>
      el('button', { class: 'eht-command-item', onclick: () => runCommand(item) }, [
        el('span', { class: 'eht-command-icon', text: item.icon }),
        el('span', { class: 'eht-command-copy' }, [
          el('strong', { text: item.title }),
          el('em', { text: item.desc })
        ]),
        el('span', { class: 'eht-command-arrow', text: '↵' })
      ])
    ) : [
      el('div', { class: 'eht-command-empty' }, [
        el('strong', { text: '검색 결과 없음' }),
        el('span', { text: '다른 키워드로 검색해보세요.' })
      ])
    ]);
  }

  function renderQuickThemeBar() {
    const active = getThemeId();
    return el('div', { class: 'eht-quick-theme-bar' }, [
      el('div', { class: 'eht-quick-theme-head' }, [
        el('strong', { text: '빠른 테마 전환' }),
        el('button', { class: 'eht-link-btn eht-mini-btn', onclick: randomTheme }, ['랜덤'])
      ]),
      el('div', { class: 'eht-quick-theme-strip' }, THEME_PRESETS.map(theme =>
        el('button', {
          class: `eht-quick-theme-chip ${theme.id === active ? 'is-active' : ''}`,
          title: theme.title,
          style: `--chip-image:url("${themeAssetUrl(theme.id)}");--chip-accent:${theme.colors[3]};`,
          onclick: () => setRadianceTheme(theme.id, 'quick')
        }, [
          el('span', { class: 'eht-quick-thumb' }),
          el('em', { text: theme.title })
        ])
      ))
    ]);
  }

  function applyThemeToNode(node) {
    if (!node) return;
    const id = getThemeId();
    node.dataset.radianceTheme = id;
    node.style.setProperty('--eht-theme-image', `url("${themeAssetUrl(id)}")`);
  }

  function setRadianceTheme(id, source = 'manual') {
    state.theme = THEME_PRESETS.some(theme => theme.id === id) ? id : 'sky-island';
    const currentRoot = document.getElementById(APP_ID);
    if (currentRoot) applyThemeToNode(currentRoot);
    bumpStat('themeChanges');
    if (source === 'quick') bumpStat('quickThemeUses');
    saveGlobalNow();
    saveLocalNow();
    toast(`${getThemeLabel()} 테마 적용`);
    render();
  }

  function copyThemeCss(theme) {
    const lines = [
      `/* Radiance Theme: ${theme.title} */`,
      `--theme-main: ${theme.colors[0]};`,
      `--theme-sub: ${theme.colors[1]};`,
      `--theme-text: ${theme.colors[2]};`,
      `--theme-accent: ${theme.colors[3]};`
    ];
    copyText(lines.join('\n'), `${theme.title} 테마 색상 복사 완료`);
  }

  function themeToPalette(theme) {
    const stamp = new Date().toISOString();
    const roles = ['메인', '배경', '텍스트', '강조'];
    const items = theme.colors.map((hex, index) => ({
      id: `theme-${theme.id}-${Date.now()}-${index}`,
      name: `${theme.title} ${roles[index] || '색상'}`,
      hex,
      role: roles[index] || '기타',
      note: 'Radiance 테마에서 가져옴',
      createdAt: stamp
    }));
    state.palette = [...items, ...ensurePalette()];
    bumpStat('themeToPalette');
    saveLocalNow();
    toast(`${theme.title} 색상을 팔레트에 추가`);
    switchTab('palette');
  }

  function renderThemeKit() {
    const active = getThemeId();
    return el('div', { class: 'eht-section eht-theme-section' }, [
      sectionIntro('테마', 'Radiance 패널의 분위기를 바꿉니다. 작품 데이터나 엔트리 에디터는 건드리지 않습니다.'),
      el('div', { class: 'eht-theme-main-preview', style: `background-image: linear-gradient(180deg, transparent, rgba(0,0,0,0.45)), url("${themeAssetUrl(active)}");` }, [
        el('div', { class: 'eht-home-kicker', text: 'Current Theme' }),
        el('div', { class: 'eht-home-title', text: getThemeLabel(active) }),
        el('div', { class: 'eht-home-subtitle', text: '선택한 이미지 테마가 패널에 바로 적용됩니다.' }),
        el('div', { class: 'eht-action-row eht-wrap-row' }, [
          el('button', { class: 'eht-link-btn', onclick: reapplyTheme }, ['현재 테마 다시 적용']),
          el('button', { class: 'eht-link-btn', onclick: randomTheme }, ['랜덤 테마'])
        ])
      ]),
      el('div', { class: 'eht-status-grid' }, [
        statusChip('현재 테마', getThemeLabel(active), true),
        statusChip('테마 수', `${THEME_PRESETS.length}개`, true),
        statusChip('적용 범위', 'Radiance 패널', true),
        statusChip('작품 영향', '없음', true),
        statusChip('테마 저장 상태', state.theme ? '저장됨' : '기본값', true)
      ]),
      el('div', { class: 'eht-theme-grid' }, THEME_PRESETS.map(theme => renderThemeCard(theme, theme.id === active)))
    ]);
  }

  function renderThemeCard(theme, active) {
    return el('div', { class: `eht-save-card eht-theme-card ${active ? 'is-active' : ''}` }, [
      el('div', { class: 'eht-theme-preview', style: `background-image: linear-gradient(180deg, transparent, rgba(0,0,0,0.42)), url("${themeAssetUrl(theme.id)}"); color:${theme.colors[2]}; border-color:${theme.colors[3]};` }, [
        el('div', { class: 'eht-theme-preview-title', text: theme.title }),
        el('div', { class: 'eht-theme-preview-chip', style: `background:${theme.colors[3]};` })
      ]),
      el('div', { class: 'eht-theme-card-copy' }, [
        el('strong', { text: `${theme.title}${active ? ' · 적용 중' : ''}` }),
        el('span', { text: theme.desc })
      ]),
      el('div', { class: 'eht-swatch-row' }, theme.colors.map(color =>
        el('i', { class: 'eht-swatch-dot', style: `background:${color}` })
      )),
      el('div', { class: 'eht-action-row eht-wrap-row' }, [
        el('button', { class: active ? 'eht-main-btn' : 'eht-link-btn', onclick: () => setRadianceTheme(theme.id) }, [active ? '적용 중' : '적용']),
        el('button', { class: 'eht-link-btn', onclick: () => copyThemeCss(theme) }, ['색상 복사']),
        el('button', { class: 'eht-link-btn', onclick: () => themeToPalette(theme) }, ['팔레트로'])
      ])
    ]);
  }


  function renderSettings() {
    state.darkMode = false;
    const backup = ensureBackupState();
    const guard = ensureLeaveGuardState();
    const page = ensurePageSearchState();
    return el('div', { class: 'eht-section eht-settings-section' }, [
      sectionIntro(TEXT.settingsTitle, '홈/백업/페이지 검색/진단/사용설명서/업데이트 상태를 한눈에 확인합니다.'),
      el('div', { class: 'eht-polish-grid' }, [
        el('div', { class: 'eht-polish-card' }, [
          el('strong', { text: '백업' }),
          el('span', { text: backup.autoEnabled ? `자동 백업 ON · ${backup.intervalMinutes}분` : '자동 백업 OFF' })
        ]),
        el('div', { class: 'eht-polish-card' }, [
          el('strong', { text: '페이지 검색' }),
          el('span', { text: page.active ? `필터 ON · ${page.query || '검색어 없음'}` : 'Enter로 검색 실행' })
        ]),
        el('div', { class: 'eht-polish-card' }, [
          el('strong', { text: '작업 보호' }),
          el('span', { text: '봉인됨' })
        ])
      ]),
      el('div', { class: 'eht-coming-soon' }, [
        el('strong', { text: 'Coming Soon..' }),
        el('span', { text: '사용설명서, 업데이트 로그, 버그제보 템플릿을 포함합니다.' })
      ])
    ]);
  }

  let darkModeObserver = null;
  let darkModeRefreshTimer = null;
  const DARK_ROOT_CLASS = 'radiance-dark-page-root';
  const DARK_MEDIA_SAFE_CLASS = 'radiance-dark-media-safe';

  function applyDarkMode() {
    state.darkMode = false;
    document.documentElement.classList.remove('radiance-entry-dark');
    stopDarkModeObserver();
    clearDarkModeRoots();
    document.getElementById(`${APP_ID}-darkmode-style`)?.remove();
  }

  function startDarkModeObserver() {
    stopDarkModeObserver();
    if (!document.body) return;
    darkModeObserver = new MutationObserver(() => scheduleDarkModeRootRefresh(80));
    darkModeObserver.observe(document.body, { childList: true, subtree: false });
    window.addEventListener('resize', handleDarkModeResize, { passive: true });
  }

  function stopDarkModeObserver() {
    if (darkModeObserver) {
      darkModeObserver.disconnect();
      darkModeObserver = null;
    }
    window.removeEventListener('resize', handleDarkModeResize);
    if (darkModeRefreshTimer) {
      clearTimeout(darkModeRefreshTimer);
      darkModeRefreshTimer = null;
    }
  }

  function handleDarkModeResize() {
    scheduleDarkModeRootRefresh(120);
  }

  function scheduleDarkModeRootRefresh(delay = 80) {
    if (!state.darkMode) return;
    if (darkModeRefreshTimer) clearTimeout(darkModeRefreshTimer);
    darkModeRefreshTimer = setTimeout(markDarkModeRoots, delay);
  }

  function clearDarkModeRoots() {
    document.querySelectorAll?.(`.${DARK_ROOT_CLASS}`).forEach(node => {
      node.classList.remove(DARK_ROOT_CLASS);
    });
    document.querySelectorAll?.(`.${DARK_MEDIA_SAFE_CLASS}`).forEach(node => {
      node.classList.remove(DARK_MEDIA_SAFE_CLASS);
    });
  }

  function markDarkModeRoots() {
    darkModeRefreshTimer = null;
    if (!state.darkMode || !document.body) return;
    clearDarkModeRoots();
    for (const child of Array.from(document.body.children)) {
      if (!(child instanceof HTMLElement)) continue;
      if (isRadianceNode(child) || shouldIgnoreDarkRoot(child)) continue;
      child.classList.add(DARK_ROOT_CLASS);
    }
    markDarkModeMediaSafe();
  }

  function markDarkModeMediaSafe() {
    const roots = document.querySelectorAll?.(`.${DARK_ROOT_CLASS}`) || [];
    const directMediaSelector = 'img, picture, video, canvas, iframe, svg, object, embed';
    const mediaClassSelector = [
      '[class*="avatar" i]',
      '[class*="profile" i]',
      '[class*="thumbnail" i]',
      '[class*="thumb" i]',
      '[class*="logo" i]',
      '[class*="illust" i]',
      '[class*="illustration" i]',
      '[class*="artwork" i]',
      '[class*="preview" i]'
    ].join(',');

    roots.forEach(root => {
      root.querySelectorAll?.(`${directMediaSelector}, ${mediaClassSelector}`).forEach(node => {
        if (!(node instanceof HTMLElement) && !(node instanceof SVGElement)) return;
        if (isRadianceNode(node)) return;
        node.classList?.add(DARK_MEDIA_SAFE_CLASS);
      });

      root.querySelectorAll?.('div, a, span, button, figure, section, article').forEach(node => {
        if (!(node instanceof HTMLElement)) return;
        if (isRadianceNode(node) || node.classList.contains(DARK_MEDIA_SAFE_CLASS)) return;
        const style = window.getComputedStyle(node);
        const hasBackgroundImage = style.backgroundImage && style.backgroundImage !== 'none';
        if (!hasBackgroundImage) return;
        if (node.querySelector('img, picture, video, canvas, iframe, svg, object, embed')) return;
        const textLength = (node.innerText || '').trim().length;
        if (textLength > 18) return;
        const rect = node.getBoundingClientRect();
        if (rect.width < 20 || rect.height < 20) return;
        node.classList.add(DARK_MEDIA_SAFE_CLASS);
      });
    });
  }

  function isRadianceNode(node) {
    return Boolean(node.matches?.(`#${APP_ID}, #${APP_ID}-bubble, .eht-toast`) || node.closest?.(`#${APP_ID}, #${APP_ID}-bubble, .eht-toast`));
  }

  function shouldIgnoreDarkRoot(node) {
    const tag = node.tagName?.toLowerCase();
    if (!tag) return true;
    if (['script', 'style', 'link', 'meta', 'noscript'].includes(tag)) return true;
    if (node.id === `${APP_ID}-darkmode-style`) return true;
    return false;
  }


  function statusChip(label, value, good) {
    return el('div', { class: `eht-status-chip ${good ? 'is-good' : ''}` }, [
      el('span', { text: label }),
      el('strong', { text: value })
    ]);
  }

  function detectWorkspace() {
    const path = location.pathname.toLowerCase();
    const urlLooksRight = /\/ws(?:\/|$)/.test(path) || /\/project\//.test(path) || /\/editor/.test(path);
    const domLooksRight = Boolean(
      document.querySelector('[class*="workspace" i], [class*="block" i], [class*="entry" i], canvas')
    );
    return { ok: urlLooksRight || domLooksRight, urlLooksRight, domLooksRight };
  }

  let lastEditableTarget = null;

  function isEditableTarget(target) {
    if (!target || target.closest?.(`#${APP_ID}, #${APP_ID}-bubble`)) return false;
    if (target instanceof HTMLInputElement) {
      const blocked = ['button', 'submit', 'reset', 'checkbox', 'radio', 'file', 'image', 'range', 'color'];
      return !target.disabled && !target.readOnly && !blocked.includes((target.type || '').toLowerCase());
    }
    if (target instanceof HTMLTextAreaElement) return !target.disabled && !target.readOnly;
    return Boolean(target.isContentEditable);
  }

  function getTargetLabel() {
    if (!lastEditableTarget || !document.contains(lastEditableTarget)) return TEXT.noTarget;
    const target = lastEditableTarget;
    const aria = target.getAttribute?.('aria-label');
    const title = target.getAttribute?.('title');
    const placeholder = target.getAttribute?.('placeholder');
    const id = target.getAttribute?.('id');
    const name = target.getAttribute?.('name');
    const raw = aria || title || placeholder || name || id || target.tagName.toLowerCase();
    return raw.length > 24 ? raw.slice(0, 24) + '…' : raw;
  }

  function renderTargetMini() {
    return el('div', { class: 'eht-target-mini' }, [
      el('span', { text: TEXT.currentTarget }),
      el('strong', { text: getTargetLabel() })
    ]);
  }

  function replaceTargetValue(text) {
    const target = lastEditableTarget;
    if (!target || !document.contains(target)) {
      toast(TEXT.noTarget);
      return false;
    }
    const value = String(text ?? '');
    try {
      target.focus();
      if (target instanceof HTMLInputElement || target instanceof HTMLTextAreaElement) {
        setTextControlValue(target, value);
      } else if (target.isContentEditable) {
        target.textContent = value;
        target.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'insertText', data: value }));
      }
      target.dispatchEvent(new Event('change', { bubbles: true }));
      bumpStat('targetReplaces');
      toast(TEXT.targetInserted);
      return true;
    } catch (error) {
      console.warn('Radiance replace failed', error);
      toast(TEXT.copyFailed);
      return false;
    }
  }

  function clearTargetValue() {
    return replaceTargetValue('');
  }

  function flashTarget() {
    const target = lastEditableTarget;
    if (!target || !document.contains(target)) {
      toast(TEXT.noTarget);
      return false;
    }
    target.classList.add('radiance-target-flash');
    target.scrollIntoView?.({ block: 'center', inline: 'center', behavior: 'smooth' });
    setTimeout(() => target.classList.remove('radiance-target-flash'), 1200);
    return true;
  }

  function setTextControlValue(target, value) {
    const proto = Object.getPrototypeOf(target);
    const descriptor = Object.getOwnPropertyDescriptor(proto, 'value');
    if (descriptor?.set) descriptor.set.call(target, value);
    else target.value = value;
    try { target.setSelectionRange(value.length, value.length); } catch {}
    target.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'insertText', data: value }));
  }

  
  function insertIntoTarget(text) {
    const target = lastEditableTarget;
    if (!target || !document.contains(target)) {
      toast(TEXT.noTarget);
      return false;
    }
    const value = String(text ?? '');
    try {
      target.focus();
      if (target instanceof HTMLInputElement || target instanceof HTMLTextAreaElement) {
        insertIntoTextControl(target, value);
      } else if (target.isContentEditable) {
        document.execCommand('insertText', false, value);
        target.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'insertText', data: value }));
      }
      target.dispatchEvent(new Event('change', { bubbles: true }));
      bumpStat('insertions');
      toast(TEXT.targetInserted);
      return true;
    } catch (error) {
      console.warn('Radiance insert failed', error);
      toast(TEXT.copyFailed);
      return false;
    }
  }

  function insertIntoTextControl(target, value) {
    const start = typeof target.selectionStart === 'number' ? target.selectionStart : target.value.length;
    const end = typeof target.selectionEnd === 'number' ? target.selectionEnd : target.value.length;
    const next = target.value.slice(0, start) + value + target.value.slice(end);
    const proto = Object.getPrototypeOf(target);
    const descriptor = Object.getOwnPropertyDescriptor(proto, 'value');
    if (descriptor?.set) descriptor.set.call(target, next);
    else target.value = next;
    const cursor = start + value.length;
    try { target.setSelectionRange(cursor, cursor); } catch {}
    target.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'insertText', data: value }));
  }

  function bringSelectionToArea(area) {
    const selected = String(window.getSelection?.() || '').trim();
    if (!selected) {
      toast('선택된 텍스트가 없습니다.');
      return;
    }
    area.value = selected;
    if (area.classList.contains('eht-bridge-insert')) state.bridgeInsertText = selected;
    area.dispatchEvent(new Event('input', { bubbles: true }));
    toast(TEXT.savedToast);
  }

  function parseBridgeItems(raw) {
    const value = (raw || '').trim();
    if (!value) return { items: [], error: '' };
    try {
      const data = JSON.parse(value);
      const source = extractBridgeArray(data);
      const items = source.map((item, index) => normalizeBridgeItem(item, index));
      return { items, error: '' };
    } catch {
      return { items: [], error: TEXT.jsonInvalid };
    }
  }

  function extractBridgeArray(data) {
    if (Array.isArray(data)) return data;
    if (!data || typeof data !== 'object') return [];
    const candidates = [
      data.items,
      data.timeline,
      data.cues,
      data.queue,
      data.objects,
      data.scenes,
      data.actions,
      data.steps,
      data.plan?.items,
      data.plan?.timeline,
      data.viventry?.items,
      data.viventry?.timeline
    ];
    for (const candidate of candidates) {
      if (Array.isArray(candidate)) return candidate;
    }
    return [];
  }

  function normalizeBridgeItem(item, index) {
    if (typeof item === 'string') return { id: `item-${index}`, time: '', text: item, fields: { text: item } };
    const fields = flattenBridgeFields(item || {});
    const time = String(fields.time ?? fields.t ?? fields.at ?? '');
    const text = String(fields.text ?? fields.label ?? fields.body ?? fields.lyric ?? fields.name ?? fields.value ?? '');
    const id = String(fields.id ?? `${time}-${text}-${index}`);
    return { id, time, text, fields };
  }

  function flattenBridgeFields(item) {
    const fields = { ...item };
    const pos = item.position || item.pos || item.coord || item.coords || item.coordinate || {};
    if (fields.x === undefined && pos.x !== undefined) fields.x = pos.x;
    if (fields.y === undefined && pos.y !== undefined) fields.y = pos.y;
    if (fields.size === undefined && fields.scale !== undefined) fields.size = fields.scale;
    if (fields.direction === undefined && fields.rotation !== undefined) fields.direction = fields.rotation;
    if (fields.text === undefined && item.content !== undefined) fields.text = item.content;
    if (fields.effect === undefined && item.motion !== undefined) fields.effect = item.motion;
    return fields;
  }

  function bridgeLine(item) {
    const bits = [];
    if (item.time) bits.push(`${item.time}s`);
    if (item.text) bits.push(item.text);
    for (const key of ['x', 'y', 'size', 'direction', 'effect', 'scene', 'object']) {
      const value = bridgeFieldValue(item, key);
      if (value !== '') bits.push(`${key}:${value}`);
    }
    return bits.join('  ') || JSON.stringify(item.fields);
  }

  function bridgeFieldValue(item, key) {
    if (!item || !item.fields) return '';
    const aliases = {
      text: ['text', 'label', 'body', 'lyric', 'name', 'value', 'content'],
      x: ['x'],
      y: ['y'],
      size: ['size', 'scale'],
      direction: ['direction', 'rotation', 'angle'],
      effect: ['effect', 'motion', 'animation'],
      scene: ['scene'],
      object: ['object', 'sprite', 'target']
    };
    for (const alias of aliases[key] || [key]) {
      const value = item.fields[alias];
      if (value !== undefined && value !== null && value !== '') return String(value);
    }
    return '';
  }

  function renderBridgeActive(container, items) {
    container.replaceChildren();
    if (!items.length) {
      container.append(el('div', { class: 'eht-hint', text: '큐를 불러오면 현재 큐 적용기가 표시됩니다.' }));
      return;
    }
    const index = clamp(state.bridgeActiveIndex || 0, 0, items.length - 1);
    const item = items[index];
    const line = bridgeLine(item);
    const done = Boolean(state.bridgeDone[item.id]);
    container.append(el('div', { class: 'eht-mini-title', text: `현재 큐 ${index + 1}/${items.length}${done ? ' · 완료' : ''}` }));
    container.append(el('div', { class: 'eht-bridge-current-line', text: line }));
    container.append(el('div', { class: 'eht-action-row eht-wrap-row' }, [
      el('button', { class: 'eht-link-btn', onclick: () => moveBridgeIndex(-1) }, ['이전']),
      el('button', { class: 'eht-link-btn', onclick: () => moveBridgeIndex(1) }, ['다음']),
      el('button', { class: 'eht-main-btn', onclick: () => insertBridgeField(item, 'text', { done: true, advance: true }) }, ['텍스트 넣고 다음']),
      el('button', { class: 'eht-link-btn', onclick: () => insertIntoTarget(line) }, ['전체 입력']),
      el('button', { class: 'eht-link-btn', onclick: () => copyText(line, TEXT.copiedToast) }, [TEXT.copyButton])
    ]));
    const fieldButtons = ['text', 'x', 'y', 'size', 'direction', 'effect', 'scene', 'object'].filter(key => bridgeFieldValue(item, key) !== '').map(key =>
      el('button', { class: 'eht-link-btn', onclick: () => insertBridgeField(item, key) }, [key])
    );
    if (fieldButtons.length) container.append(el('div', { class: 'eht-action-row eht-wrap-row' }, fieldButtons));
  }

  function renderBridgeQueue(container, status, raw) {
    container.replaceChildren();
    const { items, error } = parseBridgeItems(raw);
    status.textContent = error || (items.length ? `${items.length}개 큐 감지됨` : 'JSON을 붙여넣으면 큐가 표시됩니다.');
    status.classList.toggle('is-danger', Boolean(error));
    if (error || !items.length) return;
    container.append(el('div', { class: 'eht-mini-title', text: TEXT.queuePreview }));
    items.slice(0, 60).forEach((item, index) => {
      const line = bridgeLine(item);
      const done = Boolean(state.bridgeDone[item.id]);
      const active = index === state.bridgeActiveIndex;
      const fieldButtons = ['text', 'x', 'y', 'size', 'direction'].filter(key => bridgeFieldValue(item, key) !== '').map(key =>
        el('button', { class: 'eht-link-btn', onclick: () => insertBridgeField(item, key) }, [key])
      );
      container.append(el('div', { class: `eht-bridge-item ${done ? 'is-done' : ''} ${active ? 'is-active' : ''}` }, [
        el('div', { class: 'eht-bridge-item-main', onclick: () => setBridgeIndex(index) }, [
          el('span', { class: 'eht-bridge-index', text: String(index + 1) }),
          el('div', { class: 'eht-bridge-text', text: line })
        ]),
        el('div', { class: 'eht-action-row eht-wrap-row' }, [
          el('button', { class: 'eht-link-btn', onclick: () => copyText(line, TEXT.copiedToast) }, [TEXT.copyButton]),
          el('button', { class: 'eht-link-btn', onclick: () => insertBridgeField(item, 'text') }, [TEXT.insertButton]),
          el('button', { class: 'eht-link-btn', onclick: () => { setBridgeIndex(index); insertBridgeField(item, 'text', { done: true, advance: true }); } }, ['넣고 다음']),
          ...fieldButtons,
          el('button', { class: 'eht-link-btn', onclick: () => {
            state.bridgeDone[item.id] = !state.bridgeDone[item.id];
            saveLocal();
            render();
          } }, [done ? TEXT.clearDone : TEXT.markDone])
        ])
      ]));
    });
    if (items.length > 60) container.append(el('div', { class: 'eht-timeline-more', text: `+${items.length - 60}개 더 있음` }));
  }

  function setBridgeIndex(index) {
    const { items } = parseBridgeItems(state.bridgeJson);
    state.bridgeActiveIndex = items.length ? clamp(index, 0, items.length - 1) : 0;
    saveLocalNow();
    render();
  }

  function moveBridgeIndex(delta) {
    const { items } = parseBridgeItems(state.bridgeJson);
    if (!items.length) return;
    state.bridgeActiveIndex = clamp((state.bridgeActiveIndex || 0) + delta, 0, items.length - 1);
    saveLocalNow();
    render();
  }

  function insertBridgeField(item, key, options = {}) {
    const value = key === 'line' ? bridgeLine(item) : bridgeFieldValue(item, key);
    if (value === '') {
      toast(`${key} 값이 없습니다.`);
      return false;
    }
    const ok = insertIntoTarget(value);
    if (!ok) return false;
    bumpStat('bridgeFieldInserts');
    if (options.done) state.bridgeDone[item.id] = true;
    if (options.advance) moveBridgeIndex(1);
    else saveLocal();
    return true;
  }

  function fillBridgeExample(area, onUpdate) {
    const sample = {
      type: 'viventry-timeline',
      items: [
        { time: '00.0', text: '심어둔', x: 0, y: 20, size: 35, effect: 'fade-in' },
        { time: '01.2', text: '우리를', x: -40, y: -10, size: 32, effect: 'slide-up' },
        { time: '02.5', text: '기억하겠다', x: 30, y: 0, size: 30, effect: 'typewriter' }
      ]
    };
    area.value = JSON.stringify(sample, null, 2);
    state.bridgeJson = area.value;
    onUpdate?.();
    toast(TEXT.savedToast);
  }

  function timelineToBridge(area, onUpdate) {
    const items = timelineLines(state.timeline).map((line, index) => {
      const seconds = parseSeconds(line);
      const body = line.replace(/^(?:(\d+):)?\d+(?:\.\d+)?\s*s?\s*/i, '').trim() || line;
      return {
        id: `timeline-${index}`,
        time: Number.isFinite(seconds) ? Number(seconds.toFixed(1)) : '',
        text: body
      };
    });
    if (!items.length) {
      toast('타임라인 메모가 비어 있습니다.');
      return;
    }
    area.value = JSON.stringify({ type: 'radiance-timeline-import', items }, null, 2);
    state.bridgeJson = area.value;
    onUpdate?.();
    toast('타임라인을 Bridge로 변환했습니다.');
  }

  
  function rerollWarning() {
    let next = state.warningIndex;
    while (WARNINGS.length > 1 && next === state.warningIndex) {
      next = Math.floor(Math.random() * WARNINGS.length);
    }
    state.warningIndex = next;
    saveLocalNow();
    const warning = document.querySelector(`#${APP_ID} .eht-warning`);
    if (warning) warning.textContent = WARNINGS[state.warningIndex];
  }

  function collapsePanel() {
    state.collapsed = true;
    saveGlobalNow();
    saveLocalNow();
    render();
  }

  function clearChecklist() {
    state.checklist = {};
    saveLocalNow();
    render();
    toast(`${TEXT.tabs.check} ${TEXT.resetButton}됨`);
  }

  async function resetCurrentProject() {
    const ok = confirm(TEXT.resetConfirm);
    if (!ok) return;
    await safeChromeStorageSet({
      [storageKey]: {
        collapsed: false,
        tab: 'home',
        checklist: {},
        timeline: '',
        notes: '',
        customSnippets: '',
        palette: [],
        codeVault: [],
        bridgeJson: '',
        bridgeDone: {},
        bridgeInsertText: '',
        bridgeActiveIndex: 0,
        saveWatcher: defaultSaveWatcherState(),
        internalBackup: defaultInternalBackupState(),
        pageSearch: defaultPageSearchState(),
    leaveGuard: defaultLeaveGuardState(),
        badges: {},
        stats: {},
        theme: 'sky-island',
        warningIndex: Math.floor(Math.random() * WARNINGS.length)
      }
    });
    state.collapsed = false;
    state.tab = 'home';
    state.checklist = {};
    state.timeline = '';
    state.notes = '';
    state.customSnippets = '';
    state.bridgeJson = '';
    state.bridgeDone = {};
    state.bridgeInsertText = '';
    state.bridgeActiveIndex = 0;
    state.saveWatcher = defaultSaveWatcherState();
    state.internalBackup = defaultInternalBackupState();
    state.pageSearch = defaultPageSearchState();
    state.leaveGuard = defaultLeaveGuardState();
    state.badges = {};
    state.stats = {};
    render();
  }

  function exportProjectData() {
    const data = {
      name: `${TEXT.name} 백업`,
      projectKey,
      exportedAt: new Date().toISOString(),
      checklist: state.checklist,
      timeline: state.timeline,
      notes: state.notes,
      customSnippets: state.customSnippets,
      bridgeJson: state.bridgeJson,
      bridgeDone: state.bridgeDone,
      badges: state.badges,
      stats: state.stats,
      darkMode: state.darkMode,
      theme: state.theme
    };
    const text = JSON.stringify(data, null, 2);
    copyText(text, TEXT.copiedToast);
  }

  async function copyText(text, successMessage = TEXT.copiedToast) {
    try {
      await navigator.clipboard.writeText(text || '');
      toast(successMessage);
    } catch {
      try {
        const textarea = document.createElement('textarea');
        textarea.value = text || '';
        textarea.style.position = 'fixed';
        textarea.style.left = '-9999px';
        document.body.append(textarea);
        textarea.select();
        document.execCommand('copy');
        textarea.remove();
        toast(successMessage);
      } catch {
        toast(TEXT.copyFailed);
      }
    }
  }

  function toast(message) {
    document.querySelector('.eht-toast')?.remove();
    const node = el('div', { class: 'eht-toast', text: message });
    document.documentElement.append(node);
    setTimeout(() => node.remove(), 1600);
  }

  function makeDraggable(root, handle) {
    let startX = 0;
    let startY = 0;
    let startRight = 0;
    let startTop = 0;
    let dragging = false;

    handle.addEventListener('pointerdown', event => {
      if (event.target.closest('button')) return;
      dragging = true;
      startX = event.clientX;
      startY = event.clientY;
      const rect = root.getBoundingClientRect();
      startRight = window.innerWidth - rect.right;
      startTop = rect.top;
      handle.setPointerCapture(event.pointerId);
      root.classList.add('is-dragging');
    });

    handle.addEventListener('pointermove', event => {
      if (!dragging) return;
      const dx = event.clientX - startX;
      const dy = event.clientY - startY;
      const width = root.offsetWidth || 330;
      const nextRight = clamp(startRight - dx, 8, Math.max(8, window.innerWidth - width - 8));
      const nextTop = clamp(startTop + dy, 8, Math.max(8, window.innerHeight - 80));
      state.position = { right: nextRight, top: nextTop };
      root.style.right = `${nextRight}px`;
      root.style.top = `${nextTop}px`;
      saveGlobal();
    });

    handle.addEventListener('pointerup', event => {
      dragging = false;
      root.classList.remove('is-dragging');
      try { handle.releasePointerCapture(event.pointerId); } catch {}
    });
  }

  function clamp(value, min, max) {
    return Math.min(max, Math.max(min, value));
  }



  function keepPanelInsideViewport() {
    const root = document.getElementById(APP_ID);
    if (!root || state.collapsed) return;
    const rect = root.getBoundingClientRect();
    const margin = 14;
    let changed = false;
    if (rect.top < margin) {
      state.position.top = margin;
      changed = true;
    }
    if (rect.bottom > window.innerHeight - margin) {
      state.position.top = Math.max(margin, window.innerHeight - rect.height - margin);
      changed = true;
    }
    if (rect.right > window.innerWidth - margin) {
      state.position.right = margin;
      changed = true;
    }
    if (changed) {
      root.style.top = `${state.position.top}px`;
      root.style.right = `${state.position.right}px`;
      saveGlobal();
    }
  }


  window.addEventListener('resize', () => { setTimeout(keepPanelInsideViewport, 80); setTimeout(keepBubbleInsideViewport, 80); }, { passive: true });


  // Global save click/key listeners removed in v0.6.7 hotfix.

  setupLeaveGuardListeners();

  window.addEventListener('pagehide', () => {
    saveLocalNow();
  }, { capture: true });

  document.addEventListener('focusin', event => {
    if (isEditableTarget(event.target)) {
      lastEditableTarget = event.target;
      const targetMini = document.querySelector(`#${APP_ID} .eht-target-mini strong`);
      if (targetMini) targetMini.textContent = getTargetLabel();
    }
  }, true);


  function flushRadiancePanelState() {
    try {
      saveGlobalNow();
      saveLocalNow();
    } catch {}
  }

  window.addEventListener('pagehide', flushRadiancePanelState);
  window.addEventListener('beforeunload', flushRadiancePanelState);

  chrome.runtime?.onMessage?.addListener((message, _sender, sendResponse) => {
    if (!message || message.source !== 'ENTRY_HELPER_POPUP') return;
    if (message.type === 'SET_ENABLED') {
      state.enabled = Boolean(message.enabled);
      if (!state.enabled) state.collapsed = false;
      saveGlobalNow();
      render();
      setTimeout(keepPanelInsideViewport, 0);
      sendResponse?.({ ok: true, enabled: state.enabled });
    }
    if (message.type === 'SET_DARK_MODE') {
      state.darkMode = Boolean(message.darkMode);
      applyDarkMode();
      saveGlobalNow();
      refreshBadges(true);
      sendResponse?.({ ok: true, darkMode: state.darkMode });
    }
    if (message.type === 'OPEN_PANEL') {
      state.enabled = true;
      state.collapsed = false;
      saveGlobalNow();
      saveLocalNow();
      render();
      sendResponse?.({ ok: true });
    }
  });


  document.addEventListener('keydown', event => {
    const isCommandKey = event.ctrlKey || event.metaKey;
    if (isCommandKey && event.shiftKey && event.key.toLowerCase() === 'k') {
      event.preventDefault();
      state.enabled = true;
      state.collapsed = false;
      openCommandPalette();
    }
    if (event.key === 'Escape' && state.commandOpen) {
      event.preventDefault();
      closeCommandPalette();
    }
  }, { capture: true });
  document.documentElement.dataset.ehtCommandGlobalShortcut = 'ready';

  loadState().then(() => {
    refreshBadges(false);
    render();
  }).catch(() => {
    console.warn(TEXT.loadFailed);
  });
})();
