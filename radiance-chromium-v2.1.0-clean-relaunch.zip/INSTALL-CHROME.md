# Chrome 설치 방법

1. 이 ZIP 파일의 압축을 풉니다.
2. Chrome 주소창에 `chrome://extensions`를 입력합니다.
3. 오른쪽 위 개발자 모드를 켭니다.
4. `압축해제된 확장 프로그램을 로드`를 누릅니다.
5. 압축을 푼 폴더 중 `manifest.json`이 바로 보이는 폴더를 선택합니다.
6. `playentry.org`에 접속해 Radiance 패널이 보이는지 확인합니다.
