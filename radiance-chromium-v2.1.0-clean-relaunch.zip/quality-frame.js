(() => {
  const STYLE_ID = 'radiance-quality-frame-style';
  const TARGET_ATTR = 'data-radiance-quality-frame-target';
  const STORAGE_KEY = 'radianceQualityBoostFrameState';

  const DEFAULTS = {
    enabled: false,
    mode: 'balanced',
    zoom: 1,
    captureFrame: false
  };

  function normalizeState(raw) {
    const state = Object.assign({}, DEFAULTS, raw || {});
    if (!['balanced', 'smooth', 'sharp'].includes(state.mode)) state.mode = 'balanced';
    const zoom = Number(state.zoom);
    state.zoom = Number.isFinite(zoom) ? Math.min(1.6, Math.max(1, zoom)) : 1;
    state.enabled = Boolean(state.enabled);
    state.captureFrame = Boolean(state.captureFrame);
    return state;
  }

  function modeCss(mode) {
    if (mode === 'sharp') return 'image-rendering:-webkit-optimize-contrast !important;image-rendering:crisp-edges !important;filter:contrast(1.08) saturate(1.03);';
    if (mode === 'smooth') return 'image-rendering:auto !important;filter:contrast(1.02) saturate(1.02);';
    return 'image-rendering:auto !important;filter:contrast(1.05) saturate(1.035);';
  }

  function candidates() {
    const canvases = Array.from(document.querySelectorAll('canvas'));
    return canvases.filter(canvas => {
      const width = Number(canvas.width || canvas.getAttribute('width') || 0);
      const height = Number(canvas.height || canvas.getAttribute('height') || 0);
      const rect = canvas.getBoundingClientRect();
      const ratio = rect.height ? rect.width / rect.height : (height ? width / Math.max(height, 1) : 0);
      const exactEntry = width === 640 && height === 400;
      const entryLike = Math.abs((width / Math.max(height, 1)) - 1.6) < 0.12 && width >= 240 && height >= 140;
      const visibleEntryLike = rect.width >= 180 && rect.height >= 110 && Math.abs(ratio - 1.6) < 0.22;
      const idClassHint = `${canvas.id || ''} ${canvas.className || ''}`.toLowerCase();
      const entryHint = /entry|stage|canvas|workspace|play/.test(idClassHint);
      return exactEntry || entryLike || visibleEntryLike || entryHint;
    }).slice(0, 48);
  }

  function clearTargets() {
    document.querySelectorAll(`[${TARGET_ATTR}="1"]`).forEach(node => {
      node.removeAttribute(TARGET_ATTR);
    });
  }

  function apply(state, respond = false) {
    const normalized = normalizeState(state);
    let style = document.getElementById(STYLE_ID);
    if (!style) {
      style = document.createElement('style');
      style.id = STYLE_ID;
      document.documentElement.append(style);
    }

    clearTargets();

    if (!normalized.enabled) {
      style.textContent = '';
      if (respond) return { ok: true, count: 0, frame: location.href };
      return;
    }

    const targets = candidates();
    targets.forEach(canvas => canvas.setAttribute(TARGET_ATTR, '1'));

    const transform = normalized.zoom > 1 ? `transform:translateZ(0) scale(${normalized.zoom});transform-origin:center center;` : 'transform:translateZ(0);';
    const capture = normalized.captureFrame ? 'outline:2px solid rgba(161,161,255,0.82) !important;box-shadow:0 0 0 4px rgba(161,161,255,0.18),0 18px 42px rgba(0,0,0,0.28) !important;' : '';

    style.textContent = `
      canvas[${TARGET_ATTR}="1"] {
        ${modeCss(normalized.mode)}
        ${transform}
        backface-visibility:hidden !important;
        will-change:transform,filter !important;
        ${capture}
      }
    `;

    if (respond) return { ok: true, count: targets.length, frame: location.href };
  }

  function loadAndApply() {
    try {
      chrome.storage.local.get(STORAGE_KEY, result => {
        apply(result?.[STORAGE_KEY] || DEFAULTS);
      });
    } catch {
      apply(DEFAULTS);
    }
  }

  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (!message || message.type !== 'RADIANCE_QUALITY_FRAME_APPLY') return false;
    const result = apply(message.state, true);
    sendResponse?.(result);
    return true;
  });

  chrome.storage?.onChanged?.addListener((changes, area) => {
    if (area !== 'local' || !changes[STORAGE_KEY]) return;
    apply(changes[STORAGE_KEY].newValue || DEFAULTS);
  });

  loadAndApply();

  let retry = 0;
  const timer = setInterval(() => {
    retry += 1;
    loadAndApply();
    if (retry >= 12) clearInterval(timer);
  }, 1000);
})();
