# Chromium 설치 방법

1. ZIP 파일을 압축 해제합니다.
2. Chrome 또는 Edge에서 확장 프로그램 관리 페이지를 엽니다.
   - Chrome: `chrome://extensions`
   - Edge: `edge://extensions`
3. 개발자 모드를 켭니다.
4. `압축해제된 확장 프로그램을 로드`를 누릅니다.
5. 압축 해제한 Radiance 폴더를 선택합니다.

## 권장

기존 테스트 버전이 꼬였으면 먼저 제거한 뒤 이 Clean Relaunch 빌드를 설치하세요.
