# Radiance Lucis V2 Final

## Version

v2.0.2

## Final feature set

- Background service worker
- YouTube BGM original watch window
- Radiance Quality Boost V2 with all_frames detection
- Themes
- Palette
- Notes
- Timeline
- Checklist
- Snippets
- Page search
- Backup
- Support center
- Badges

## Removed from final line

- Extension internal YouTube iframe player window
- Floating/docking BGM experiments
- Risky direct Entry editor manipulation
- Old rollback docs

## Build note

This is the clean V2 final package.
