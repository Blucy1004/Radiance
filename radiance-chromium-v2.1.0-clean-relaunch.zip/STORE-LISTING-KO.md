# Radiance Lucis V2 Store Listing

## 이름

Radiance Lucis

## 짧은 설명

Entry 작업을 위한 BGM, 화질 보정, 테마, 메모, 백업 보조 패널

## 설명

Radiance Lucis는 Entry 작업을 더 편하게 만들어주는 제작 보조 패널입니다.

주요 기능:

- 작업 체크리스트
- 타임라인 메모
- 메모장
- 스니펫 보관함
- 색상 팔레트
- 테마 키트
- YouTube BGM 창 열기
- 페이지 검색
- 백업 도구
- 지원 센터
- 배지
- Radiance Quality Boost V2

Radiance는 Entry 프로젝트 데이터를 직접 수정하지 않습니다.  
사용자 설정과 보조 데이터는 브라우저 저장소에 저장됩니다.

## BGM

YouTube BGM 기능은 사용자가 입력한 YouTube 링크를 원본 YouTube 창으로 여는 방식입니다.  
Radiance는 영상 다운로드, 음원 추출, 광고 우회 기능을 제공하지 않습니다.

## Quality Boost V2

Quality Boost V2는 Entry 화면의 640×400 계열 canvas 후보에 CSS 기반 선명도, 캡처 프레임, 확대 보정을 적용하는 실험 기능입니다.  
Entry 프로젝트 데이터는 수정하지 않습니다.

## 개인정보

Radiance Lucis는 개인정보를 외부 서버로 전송하지 않습니다.
