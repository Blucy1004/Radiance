# Radiance Lucis v1.5.5 Palette Kit

## 팔레트 탭

프로젝트별 색상을 저장하고 복사하는 안전 제작 보조 기능입니다.

## 저장 항목

- 색상 이름
- HEX 코드
- 역할: 메인, 배경, 텍스트, 강조, 그림자, 버튼, 라인, 기타
- 메모

## 지원 기능

- HEX 복사
- CSS 변수 복사
- 팔레트 전체 복사
- 팔레트 CSS 전체 복사
- 팔레트 메모로 보내기
- 팔레트 JSON 복사
- 기본 팔레트 프리셋 추가

## 기본 프리셋

- Radiance Sky
- Dark Panel
- Entry Clean
- Typography Pink
- Ocean Blue
- Sunset Warm

## Safe Core

팔레트 기능은 작품 에디터 내부 구조를 직접 조작하지 않습니다.
색상 정리와 복사만 수행하므로 Radiance 본체에 안전하게 포함됩니다.
