# Radiance Lucis Changelog

## v2.1.0 Clean Relaunch

- 재출시용 클린 빌드
- 브랜드 문구 정리
- Quality Boost 명칭을 Radiance Quality Boost V2로 통일
- 이전 실험/롤백 문서 제거
- background service worker 유지
- YouTube BGM 원본 창 열기 유지
- Quality Boost V2 all_frames 감지 유지
- README / PRIVACY / 설치 안내 / 스토어 설명 정리
- Firefox AMO data_collection_permissions 유지

## v2.0.2 V2 Final Clean

- V2 최종 정리 빌드
- background service worker 유지
- YouTube BGM 창 열기 방식 정리
- Quality Boost V2 all_frames 감지 유지
- README / PRIVACY / 설치 안내 정리

## v2.0.1 Quality Frame Detect Hotfix

- Quality Boost가 내부 프레임의 canvas를 못 잡는 문제 수정
- 화질 보정 전용 all_frames content script 추가
- Radiance 본체 패널은 top frame에만 유지
- Quality Boost 설정을 chrome.storage.local로 프레임에 공유

## v2.0.0 Radiance V2

- background service worker 복구
- YouTube BGM 창 열기를 background에서 처리
- Quality Boost V2 탭 추가
