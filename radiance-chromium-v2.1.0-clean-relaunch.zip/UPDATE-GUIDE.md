# Radiance Lucis 업데이트 안내

## Chromium판

Chromium판은 Chrome, Edge, Whale, Brave 등 Chromium 기반 브라우저에서 사용할 수 있습니다.

개발자 모드 ZIP 설치본은 브라우저가 자동으로 새 ZIP을 설치하지 않습니다.
새 버전이 나오면 ZIP을 다시 내려받고, 확장 프로그램 관리 페이지에서 다시 로드해야 합니다.

## Firefox판

Firefox판은 Firefox 전용 빌드입니다.
AMO 서명판은 Mozilla Add-ons 배포 설정에 따라 업데이트됩니다.
직접 배포 signed XPI는 새 signed XPI 파일을 다시 설치해야 합니다.

## 자동 업데이트에 대한 설명

브라우저 보안 정책상 확장 프로그램이 스스로 새 확장 파일을 내려받아 몰래 설치할 수 없습니다.
Radiance는 자동 설치 대신 업데이트 로그와 안전한 업데이트 안내를 제공합니다.
