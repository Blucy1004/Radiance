# Radiance Lucis v2.0.1 Quality Frame Detect Hotfix

## 수정 내용

Quality Boost V2가 top 페이지의 canvas만 찾던 문제를 고쳤습니다.
Entry 화면이 iframe/내부 프레임 안에 있을 경우 top script에서는 canvas에 접근하지 못할 수 있습니다.

## 새 구조

- `content.js`: Radiance 본체 패널. top frame에만 실행.
- `quality-frame.js`: 화질 보정 전용 경량 스크립트. all_frames로 실행.
- `background.js`: Quality Boost 설정을 현재 탭 프레임들에 브로드캐스트.
- `chrome.storage.local`: Quality Boost 상태를 프레임 스크립트와 공유.

## 효과

- 내부 프레임 안의 640×400 canvas 후보 감지 가능성 증가
- 패널 중복 생성 방지
- Entry 프로젝트 데이터 수정 없음
- CSS 보정만 적용

## 주의

브라우저/사이트 보안 정책상 접근이 제한되는 특수 프레임은 감지되지 않을 수 있습니다.
