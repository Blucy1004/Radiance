# Radiance Lucis v1.6.0 Panel Surface Fix

## 수정 내용

- 예전 런처 스킨 CSS가 패널 표면을 하얗게 덮어쓰던 문제 수정
- 탭 영역/바디/푸터/경고 박스/헤더를 테마 기준 표면으로 통일
- 깔끔한 다크 테마의 패널 배경을 확실한 다크 톤으로 조정
- 벚꽃 테마 텍스트색/표면 계열 정리

## 원인

하위 버전에서 추가된 전역 UI 폴리시 CSS가 `#entry-helper-toolkit .eht-tabs`, `.eht-footer` 같은 요소를 고정된 밝은 색으로 덮고 있었습니다.
이번 버전에서는 `[data-radiance-theme]` 기반으로 다시 강하게 오버라이드합니다.
