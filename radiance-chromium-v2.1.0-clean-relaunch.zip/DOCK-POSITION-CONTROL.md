# Radiance Lucis v1.7.2 Dock Position Control

## 변경점

- Mini Dock 위치 저장 추가
- Mini Dock 드래그 이동 지원
- 좌상/우상/좌하/우하 위치 프리셋 추가
- 홈에서 위치를 바로 바꿀 수 있는 카드 추가
- 화면 리사이즈 시 Mini Dock 위치 자동 보정

## 사용법

- 패널을 접은 뒤 Mini Dock를 드래그하면 위치가 저장됩니다.
- 홈의 `Mini Dock 위치` 카드에서 빠른 프리셋을 누를 수도 있습니다.
