const globalKey = 'radiance:global';
const legacyGlobalKey = 'entry-helper:global';
const warnings = [
  'Radiance Lucis · First Light Release',
  '페이지 검색은 현재 화면에 로딩된 카드만 대상으로 동작합니다.',
  '백업은 엔트리 작품 저장이 아니라 Radiance 내부 데이터 백업입니다.',
  '작업 보호는 저장 여부를 직접 판별하는 기능이 아니라 이탈 경고입니다.',
  '장면 시작 이벤트는 해당 장면에 진입해야 실행됩니다.',
  '초시계 기반 코드는 초시계 준비 여부를 먼저 확인해 보세요.'
];

const enabled = document.getElementById('enabled');
const openPanel = document.getElementById('openPanel');
const warning = document.getElementById('warning');
warning.textContent = warnings[Math.floor(Math.random() * warnings.length)];

chrome.storage.local.get([globalKey, legacyGlobalKey], data => {
  const global = data?.[globalKey] || data?.[legacyGlobalKey] || {};
  enabled.checked = global.enabled !== false;
});

enabled.addEventListener('change', () => {
  const next = enabled.checked;
  chrome.storage.local.get([globalKey, legacyGlobalKey], data => {
    chrome.storage.local.set({
      [globalKey]: {
        ...(data?.[globalKey] || data?.[legacyGlobalKey] || {}),
        enabled: next
      }
    });
  });
  sendToActiveTab({ type: 'SET_ENABLED', enabled: next });
});

openPanel.addEventListener('click', () => {
  enabled.checked = true;
  chrome.storage.local.get([globalKey, legacyGlobalKey], data => {
    chrome.storage.local.set({
      [globalKey]: {
        ...(data?.[globalKey] || data?.[legacyGlobalKey] || {}),
        enabled: true
      }
    });
  });
  sendToActiveTab({ type: 'OPEN_PANEL' });
});

function sendToActiveTab(message) {
  chrome.tabs.query({ active: true, currentWindow: true }, tabs => {
    const tabId = tabs?.[0]?.id;
    if (!tabId) return;
    chrome.tabs.sendMessage(tabId, { source: 'ENTRY_HELPER_POPUP', ...message }, () => {
      void chrome.runtime.lastError;
    });
  });
}
