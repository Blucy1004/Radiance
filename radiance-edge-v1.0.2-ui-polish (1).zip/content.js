(() => {
  const APP_ID = 'entry-helper-toolkit';
  if (window.__ENTRY_HELPER_TOOLKIT__) return;
  window.__ENTRY_HELPER_TOOLKIT__ = true;

  const TEXT = {
  "name": "Radiance",
  "shortName": "Radiance",
  "description": "유저 블루시가 제작한 엔트리 제작 도우미, Radiance에 오신 것을 환영합니다!",
  "panelTitle": "엔트리 제작 도우미",
  "panelSubtitle": "제작 중 자주 확인할 도구를 한곳에 모았습니다.",
  "openButton": "도우미 열기",
  "closeButton": "접기",
  "resetButton": "초기화",
  "copyButton": "복사",
  "copiedToast": "복사되었습니다.",
  "savedToast": "저장되었습니다.",
  "resetConfirm": "이 페이지에 저장된 도구 데이터를 초기화할까요?",
  "emptyState": "아직 저장된 내용이 없습니다.",
  "tabs": {
    "check": "체크리스트",
    "coord": "좌표",
    "timeline": "타임라인",
    "notes": "메모",
    "snippet": "스니펫",
    "tips": "팁",
    "badges": "배지",
    "settings": "설정",
    "bridge": "연동",
    "save": "백업",
    "pageSearch": "페이지 검색",
    "guard": "작업 보호"
  },
  "checkTitle": "프로젝트 점검",
  "checkDescription": "실행 전에 자주 놓치는 부분을 확인해 보세요.",
  "progressLabel": "점검률",
  "clearChecks": "체크 해제",
  "coordsTitle": "엔트리 좌표 계산기",
  "coordsDescription": "엔트리 화면 기준 좌표를 빠르게 확인하고 복사합니다.",
  "xLabel": "X",
  "yLabel": "Y",
  "resultLabel": "복사용 좌표",
  "stageHint": "기본 화면 범위: X -240~240 / Y -120~120",
  "customCoords": "커스텀 좌표 검사",
  "outsideWarning": "화면 밖 가능성",
  "timelineTitle": "타이포그래피 타임라인 메모",
  "timelineDescription": "가사, 효과, 장면 전환 타이밍을 적어 두세요.",
  "timelinePlaceholder": "예: 00.0s  첫 문장 등장\n01.2s  화면 전환\n02.5s  다음 가사",
  "addLineButton": "현재 줄 추가",
  "sortButton": "시간순 정렬",
  "timelineHint": "팁: “초.초s 텍스트 x/y/size/effect” 형태로 적으면 정렬이 잘 됩니다.",
  "notesTitle": "프로젝트 메모",
  "notesDescription": "아이디어, 수정할 점, 테스트 결과를 자유롭게 적어 두세요.",
  "notesPlaceholder": "예: 2절부터 글자 크기 줄이기 / 배경을 조금 더 어둡게 조정",
  "backupJson": "백업 JSON",
  "snippetsTitle": "자주 쓰는 문구/코드 메모",
  "snippetsDescription": "반복해서 쓰는 메모나 제작 패턴을 저장해 두세요.",
  "snippetsPlaceholder": "예: 페이드 인 → 대기 → 페이드 아웃 패턴",
  "mySnippets": "내 스니펫",
  "copyMySnippets": "내 스니펫 복사",
  "tipsTitle": "제작 팁",
  "tipsDescription": "작업 중 확인하면 좋은 짧은 팁입니다.",
  "randomButton": "다른 팁 보기",
  "studioTitle": "작품만들기 연동",
  "studioDescription": "엔트리 작품만들기 화면에서 입력칸을 감지하고 값을 넣습니다.",
  "bridgeTitle": "Viventry Bridge",
  "bridgeDescription": "Viventry가 만든 JSON 계획을 붙여넣고 큐 단위로 적용합니다.",
  "insertButton": "입력",
  "insertTextButton": "입력칸에 넣기",
  "currentTarget": "현재 입력 대상",
  "noTarget": "엔트리 입력칸을 먼저 클릭해 주세요.",
  "detectWorkspace": "작품만들기 감지",
  "detected": "감지됨",
  "notDetected": "미확실",
  "bringSelection": "선택 텍스트 가져오기",
  "parseJson": "JSON 분석",
  "bridgePlaceholder": "Viventry JSON을 여기에 붙여넣기",
  "queuePreview": "큐 미리보기",
  "markDone": "완료",
  "clearDone": "완료 해제",
  "jsonInvalid": "JSON 형식이 맞지 않습니다.",
  "targetInserted": "입력칸에 넣었습니다.",
  "storageUnavailable": "브라우저 저장소를 사용할 수 없습니다.",
  "copyFailed": "복사에 실패했습니다. 직접 선택해서 복사해 주세요.",
  "loadFailed": "도구를 불러오는 중 문제가 발생했습니다.",
  "badgesTitle": "Radiance 배지",
  "badgesDescription": "작업 중 특정 조건을 만족하면 자동으로 달성되는 작은 업적입니다.",
  "badgeUnlocked": "새 배지 달성",
  "badgeLocked": "잠김",
  "badgeUnlockedLabel": "달성",
  "settingsTitle": "설정",
  "settingsDescription": "Radiance 동작과 엔트리 화면 보조 기능을 조정합니다.",
  "darkModeTitle": "다크모드 임시 중단",
  "darkModeDescription": "엔트리 홈/작품/에디터 화면 구조가 달라 안정화 전까지 다크모드를 제외했습니다.",
  "darkModeOn": "다크모드 켜짐",
  "darkModeOff": "다크모드 꺼짐",
  "experimental": "실험적"
};
  const WARNINGS = [
  "흰 배경 위의 흰 글자는 보이지 않을 수 있습니다. 배경색과 글자색 대비를 확인해 보세요.",
  "초시계 기반 코드를 사용할 때는 초시계가 정상적으로 동작하는지 먼저 확인해 보세요.",
  "오브젝트나 복제본 수가 많아지면 실행 속도가 느려질 수 있습니다.",
  "장면 시작 이벤트는 해당 장면에 진입해야 실행됩니다.",
  "Im Handsome:sunglasses:"
];
  const CHECKLIST = [
  {
    "id": "scene-start",
    "text": "장면 시작하기 코드를 사용한 장면에 시작하기 버튼을 클릭했을 때가 없나요?"
  },
  {
    "id": "timer",
    "text": "초시계 기반 코드를 쓴다면 초시계가 준비되어 있나요?"
  },
  {
    "id": "text-contrast",
    "text": "글자색과 배경색이 충분히 구분되나요?"
  },
  {
    "id": "stage-bound",
    "text": "중요 오브젝트가 화면 범위 안에 있나요?"
  },
  {
    "id": "layering",
    "text": "배경/오브젝트/텍스트 레이어 순서가 의도대로인가요?"
  },
  {
    "id": "textbox-lines",
    "text": "여러 줄 텍스트 정렬이 깨지지 않나요?"
  },
  {
    "id": "clone-count",
    "text": "복제본이나 오브젝트 수가 너무 많지 않나요?"
  },
  {
    "id": "music-sync",
    "text": "음악 싱크 타이밍이 잘 맞나요?"
  }
];
  const COORD_PRESETS = [
  {
    "label": "중앙",
    "x": 0,
    "y": 0
  },
  {
    "label": "왼쪽 위",
    "x": -240,
    "y": 120
  },
  {
    "label": "오른쪽 위",
    "x": 240,
    "y": 120
  },
  {
    "label": "왼쪽 아래",
    "x": -240,
    "y": -120
  },
  {
    "label": "오른쪽 아래",
    "x": 240,
    "y": -120
  },
  {
    "label": "아래 중앙",
    "x": 0,
    "y": -120
  }
];
  const DEFAULT_SNIPPETS = [
  {
    "title": "타이포 타임라인",
    "body": "00.0s  텍스트 등장\n01.0s  크기 변화\n02.0s  페이드 아웃"
  },
  {
    "title": "디버그 체크",
    "body": "장면 진입 / 초시계 / 레이어 / 좌표 / 텍스트 색 확인"
  }
];

  const state = {
    enabled: true,
    collapsed: false,
    tab: 'check',
    checklist: {},
    timeline: '',
    notes: '',
    customSnippets: '',
    bridgeJson: '',
    bridgeDone: {},
    bridgeInsertText: '',
    bridgeActiveIndex: 0,
    saveWatcher: defaultSaveWatcherState(),
    internalBackup: defaultInternalBackupState(),
    pageSearch: defaultPageSearchState(),
    leaveGuard: defaultLeaveGuardState(),
    badges: {},
    stats: {},
    darkMode: false,
    position: { right: 18, top: 82 },
    warningIndex: Math.floor(Math.random() * WARNINGS.length)
  };

  const projectKey = makeProjectKey();
  const storageKey = `radiance:${projectKey}`;
  const legacyStorageKey = `entry-helper:${projectKey}`;
  const globalKey = 'radiance:global';
  const legacyGlobalKey = 'entry-helper:global';

  function makeProjectKey() {
    const url = new URL(location.href);
    const match = url.pathname.match(/\/project\/([^/?#]+)/i);
    const project = match?.[1];
    if (project) return `project:${project}`;
    const cleanPath = url.pathname.replace(/[^a-zA-Z0-9_-]/g, '_').replace(/^_+|_+$/g, '');
    return cleanPath ? `page:${cleanPath}` : `host:${url.hostname}`;
  }

  function safeChromeStorageGet(keys) {
    return new Promise(resolve => {
      try { chrome.storage.local.get(keys, resolve); }
      catch { resolve({}); }
    });
  }

  function safeChromeStorageSet(value) {
    return new Promise(resolve => {
      try { chrome.storage.local.set(value, resolve); }
      catch { resolve(); }
    });
  }

  async function loadState() {
    const data = await safeChromeStorageGet([globalKey, storageKey, legacyGlobalKey, legacyStorageKey]);
    const global = data[globalKey] || data[legacyGlobalKey] || {};
    const local = data[storageKey] || data[legacyStorageKey] || {};
    Object.assign(state, global, local);
    if (typeof state.warningIndex !== 'number' || state.warningIndex >= WARNINGS.length) state.warningIndex = 0;
    if (!state.badges || typeof state.badges !== 'object') state.badges = {};
    if (!state.stats || typeof state.stats !== 'object') state.stats = {};
    if (!state.leaveGuard || typeof state.leaveGuard !== 'object') state.leaveGuard = defaultLeaveGuardState();
    state.leaveGuard = Object.assign(defaultLeaveGuardState(), state.leaveGuard);
    if (!state.pageSearch || typeof state.pageSearch !== 'object') state.pageSearch = defaultPageSearchState();
    state.pageSearch = Object.assign(defaultPageSearchState(), state.pageSearch);
    if (!state.internalBackup || typeof state.internalBackup !== 'object') state.internalBackup = defaultInternalBackupState();
    state.internalBackup = Object.assign(defaultInternalBackupState(), state.internalBackup);
    if (!Array.isArray(state.internalBackup.items)) state.internalBackup.items = [];
    if (!state.saveWatcher || typeof state.saveWatcher !== 'object') state.saveWatcher = defaultSaveWatcherState();
    state.saveWatcher = Object.assign(defaultSaveWatcherState(), state.saveWatcher);
    applyDarkMode();
    setupInternalBackupTimer();
    // Auto-save timer disabled in v0.6.7 hotfix to prevent page freezes.
  }

  function localSnapshot() {
    return {
      [storageKey]: {
        collapsed: state.collapsed,
        tab: state.tab,
        checklist: state.checklist,
        timeline: state.timeline,
        notes: state.notes,
        customSnippets: state.customSnippets,
        bridgeJson: state.bridgeJson,
        bridgeDone: state.bridgeDone,
        bridgeInsertText: state.bridgeInsertText,
        bridgeActiveIndex: state.bridgeActiveIndex || 0,
        saveWatcher: state.saveWatcher,
        internalBackup: state.internalBackup,
        pageSearch: state.pageSearch,
        leaveGuard: state.leaveGuard,
        badges: state.badges,
        stats: state.stats,
        warningIndex: state.warningIndex
      }
    };
  }

  function saveLocalNow() {
    return safeChromeStorageSet(localSnapshot());
  }

  const saveLocal = debounce(() => {
    saveLocalNow();
  }, 80);

  const saveGlobal = debounce(() => {
    safeChromeStorageSet({
      [globalKey]: {
        enabled: state.enabled,
        darkMode: state.darkMode,
        position: state.position
      }
    });
  }, 250);

  function debounce(fn, delay) {
    let timer;
    return (...args) => {
      clearTimeout(timer);
      timer = setTimeout(() => fn(...args), delay);
    };
  }

  function el(tag, attrs = {}, children = []) {
    const node = document.createElement(tag);
    for (const [key, value] of Object.entries(attrs)) {
      if (key === 'class') node.className = value;
      else if (key === 'text') node.textContent = value;
      else if (key === 'html') node.innerHTML = value;
      else if (key.startsWith('on') && typeof value === 'function') node.addEventListener(key.slice(2), value);
      else node.setAttribute(key, value);
    }
    for (const child of children) node.append(child);
    return node;
  }

  function sectionIntro(title, description) {
    const children = [el('div', { class: 'eht-mini-title', text: title })];
    if (description) children.push(el('div', { class: 'eht-hint', text: description }));
    return el('div', { class: 'eht-section-intro' }, children);
  }

  function render() {
    document.getElementById(APP_ID)?.remove();
    document.getElementById(`${APP_ID}-bubble`)?.remove();

    if (!state.enabled) return renderBubble(false);
    if (state.collapsed) return renderBubble(true);

    const root = el('section', {
      id: APP_ID,
      class: 'eht-panel',
      style: `right:${state.position.right}px;top:${state.position.top}px;`
    });

    const header = el('div', { class: 'eht-header' }, [
      el('img', { class: 'eht-logo', src: chrome.runtime.getURL('assets/icon48.png'), alt: TEXT.shortName }),
      el('div', { class: 'eht-title-wrap' }, [
        el('div', { class: 'eht-kicker', text: TEXT.name }),
        el('div', { class: 'eht-title', text: TEXT.panelTitle }),
        TEXT.panelSubtitle ? el('div', { class: 'eht-header-subtitle', text: TEXT.panelSubtitle }) : document.createTextNode('')
      ]),
      el('img', { class: 'eht-sky-island', src: chrome.runtime.getURL('assets/sky-island.png'), alt: '' }),
      el('div', { class: 'eht-header-actions' }, [
        el('button', { class: 'eht-icon-btn', title: TEXT.randomButton, onclick: rerollWarning }, ['⚠️']),
        el('button', { class: 'eht-icon-btn', title: TEXT.closeButton, onclick: collapsePanel }, ['—'])
      ])
    ]);

    makeDraggable(root, header);

    const warning = el('button', { class: 'eht-warning', onclick: rerollWarning }, [WARNINGS[state.warningIndex]]);
    const visibleTabs = ['check', 'timeline', 'notes', 'snippet', 'badges', 'pageSearch', 'save', 'guard', 'settings'];
    if (!visibleTabs.includes(state.tab)) state.tab = 'check';

    const tabs = el('div', { class: 'eht-tabs' }, [
      tabButton('check', TEXT.tabs.check),
      tabButton('timeline', TEXT.tabs.timeline),
      tabButton('notes', TEXT.tabs.notes),
      tabButton('snippet', TEXT.tabs.snippet),
      tabButton('badges', TEXT.tabs.badges),
      tabButton('pageSearch', TEXT.tabs.pageSearch),
      tabButton('save', TEXT.tabs.save),
      tabButton('guard', TEXT.tabs.guard),
      tabButton('settings', TEXT.tabs.settings)
    ]);

    const body = el('div', { class: 'eht-body' }, [renderTabBody()]);
    const footer = el('div', { class: 'eht-footer' }, [
      el('span', { text: projectKey.replace(/^project:/, '프로젝트: ').replace(/^page:/, '페이지: ') }),
      el('button', { class: 'eht-link-btn', onclick: resetCurrentProject }, [TEXT.resetButton])
    ]);

    root.append(header, warning, tabs, body, footer);
    document.documentElement.append(root);
  }

  function renderBubble(collapsed = true) {
    const bubble = el('button', {
      id: `${APP_ID}-bubble`,
      class: `eht-bubble ${collapsed ? '' : 'eht-bubble-disabled'}`,
      title: collapsed ? TEXT.openButton : `${TEXT.panelTitle} 꺼짐`,
      onclick: () => {
        state.enabled = true;
        state.collapsed = false;
        saveGlobal();
        saveLocalNow();
        render();
      }
    }, collapsed
      ? [el('img', { class: 'eht-bubble-logo', src: chrome.runtime.getURL('assets/icon48.png'), alt: TEXT.shortName })]
      : ['OFF']);
    document.documentElement.append(bubble);
  }

  function tabButton(id, label) {
    return el('button', {
      class: `eht-tab ${state.tab === id ? 'is-active' : ''}`,
      onclick: () => {
        state.tab = id;
        saveLocalNow();
        render();
      }
    }, [label]);
  }

  function renderTabBody() {
    if (state.tab === 'coord') return renderCoords();
    if (state.tab === 'timeline') return renderTimeline();
    if (state.tab === 'notes') return renderNotes();
    if (state.tab === 'snippet') return renderSnippets();
    if (state.tab === 'tips') return renderTips();
    if (state.tab === 'badges') return renderBadges();
    if (state.tab === 'settings') return renderSettings();
    if (state.tab === 'bridge') return renderBridge();
    if (state.tab === 'pageSearch') return renderPageSearch();
    if (state.tab === 'save') return renderSaveClicker();
    if (state.tab === 'guard') return renderLeaveGuard();
    return renderChecklist();
  }

  function renderChecklist() {
    const checkedCount = CHECKLIST.filter((_, i) => state.checklist[i]).length;
    const progress = Math.round((checkedCount / CHECKLIST.length) * 100);
    return el('div', { class: 'eht-section' }, [
      sectionIntro(TEXT.checkTitle, TEXT.checkDescription),
      el('div', { class: 'eht-progress-row' }, [
        el('strong', { text: `${TEXT.progressLabel} ${progress}%` }),
        el('button', { class: 'eht-link-btn', onclick: clearChecklist }, [TEXT.clearChecks])
      ]),
      el('div', { class: 'eht-progress' }, [
        el('div', { class: 'eht-progress-fill', style: `width:${progress}%` })
      ]),
      ...CHECKLIST.map((item, index) => {
        const id = `eht-check-${index}`;
        const input = el('input', {
          type: 'checkbox',
          id,
          ...(state.checklist[index] ? { checked: 'checked' } : {}),
          onchange: event => {
            state.checklist[index] = event.target.checked;
            saveLocal();
            updateChecklistProgress();
            refreshBadges(true);
          }
        });
        return el('label', { class: 'eht-check-item', for: id }, [input, el('span', { text: item.text })]);
      })
    ]);
  }

  function updateChecklistProgress() {
    const checkedCount = CHECKLIST.filter((_, i) => state.checklist[i]).length;
    const progress = Math.round((checkedCount / CHECKLIST.length) * 100);
    const row = document.querySelector(`#${APP_ID} .eht-progress-row strong`);
    const fill = document.querySelector(`#${APP_ID} .eht-progress-fill`);
    if (row) row.textContent = `${TEXT.progressLabel} ${progress}%`;
    if (fill) fill.style.width = `${progress}%`;
  }

  function renderCoords() {
    const customX = el('input', { class: 'eht-input', type: 'number', value: '0', min: '-999', max: '999', step: '1' });
    const customY = el('input', { class: 'eht-input', type: 'number', value: '0', min: '-999', max: '999', step: '1' });
    const result = el('div', { class: 'eht-coordinate-result', text: `${TEXT.xLabel} 0 / ${TEXT.yLabel} 0` });
    const hint = el('div', { class: 'eht-hint', text: TEXT.stageHint });

    const update = () => {
      const x = Number(customX.value || 0);
      const y = Number(customY.value || 0);
      const outside = x < -240 || x > 240 || y < -120 || y > 120;
      result.textContent = `${TEXT.xLabel} ${x} / ${TEXT.yLabel} ${y}${outside ? '  ⚠️ ' + TEXT.outsideWarning : ''}`;
      result.classList.toggle('is-danger', outside);
    };
    customX.addEventListener('input', update);
    customY.addEventListener('input', update);

    return el('div', { class: 'eht-section' }, [
      sectionIntro(TEXT.coordsTitle, TEXT.coordsDescription),
      el('div', { class: 'eht-grid' }, COORD_PRESETS.map(preset =>
        el('div', { class: 'eht-preset-card' }, [
          el('strong', { text: preset.label }),
          el('span', { text: `x:${preset.x} / y:${preset.y}` }),
          el('div', { class: 'eht-preset-actions' }, [
            el('button', { class: 'eht-link-btn', onclick: () => { bumpStat('coordCopies'); copyText(`x:${preset.x}, y:${preset.y}`, `${preset.label} ${TEXT.copiedToast}`); } }, [TEXT.copyButton]),
            el('button', { class: 'eht-link-btn', onclick: () => { bumpStat('coordInserts'); insertIntoTarget(`x:${preset.x}, y:${preset.y}`); } }, [TEXT.insertButton])
          ])
        ])
      )),
      renderTargetMini(),
      el('div', { class: 'eht-mini-title', text: TEXT.customCoords }),
      el('div', { class: 'eht-inline-fields eht-wrap-row' }, [
        el('label', { text: TEXT.xLabel }), customX,
        el('label', { text: TEXT.yLabel }), customY,
        el('button', { class: 'eht-main-btn', onclick: () => { bumpStat('coordCopies'); copyText(`x:${customX.value || 0}, y:${customY.value || 0}`, TEXT.copiedToast); } }, [TEXT.copyButton]),
        el('button', { class: 'eht-main-btn', onclick: () => { bumpStat('coordInserts'); insertIntoTarget(`x:${customX.value || 0}, y:${customY.value || 0}`); } }, [TEXT.insertButton])
      ]),
      el('div', { class: 'eht-action-row eht-wrap-row' }, [
        el('button', { class: 'eht-link-btn', onclick: () => insertIntoTarget(String(customX.value || 0)) }, [`${TEXT.xLabel}만 ${TEXT.insertButton}`]),
        el('button', { class: 'eht-link-btn', onclick: () => insertIntoTarget(String(customY.value || 0)) }, [`${TEXT.yLabel}만 ${TEXT.insertButton}`])
      ]),
      result,
      hint
    ]);
  }

  function renderTimeline() {
    const area = el('textarea', {
      class: 'eht-textarea eht-timeline',
      placeholder: TEXT.timelinePlaceholder,
      spellcheck: 'false'
    });
    area.value = state.timeline || '';

    const meta = el('div', { class: 'eht-timeline-meta' });
    const preview = el('div', { class: 'eht-timeline-preview' });

    const updateTimelineUi = () => {
      state.timeline = area.value;
      renderTimelineMeta(meta, area.value);
      renderTimelinePreview(preview, area.value);
      refreshBadges(false);
    };

    area.addEventListener('input', () => {
      updateTimelineUi();
      saveLocal();
    });

    updateTimelineUi();

    return el('div', { class: 'eht-section eht-timeline-section' }, [
      sectionIntro(TEXT.timelineTitle, TEXT.timelineDescription),
      el('div', { class: 'eht-timeline-board' }, [
        meta,
        el('div', { class: 'eht-action-row eht-timeline-actions' }, [
          el('button', { class: 'eht-main-btn', onclick: () => { addTimelineStamp(area); updateTimelineUi(); } }, [TEXT.addLineButton]),
          el('button', { class: 'eht-main-btn', onclick: () => { sortTimeline(area); updateTimelineUi(); } }, [TEXT.sortButton]),
          el('button', { class: 'eht-main-btn', onclick: () => copyText(area.value, TEXT.copiedToast) }, [TEXT.copyButton])
        ]),
        area,
        el('div', { class: 'eht-hint eht-timeline-hint', text: TEXT.timelineHint }),
        preview
      ])
    ]);
  }

  function timelineLines(value) {
    return (value || '').split('\n').map(line => line.trim()).filter(Boolean);
  }

  function formatCueTime(seconds) {
    if (!Number.isFinite(seconds)) return '--';
    const min = Math.floor(seconds / 60);
    const sec = seconds - min * 60;
    return min > 0 ? `${min}:${sec.toFixed(1).padStart(4, '0')}s` : `${sec.toFixed(1)}s`;
  }

  function renderTimelineMeta(container, value) {
    container.replaceChildren();
    const lines = timelineLines(value);
    const parsed = lines.map(parseSeconds).filter(Number.isFinite).sort((a, b) => a - b);
    const first = parsed.length ? formatCueTime(parsed[0]) : '--';
    const last = parsed.length ? formatCueTime(parsed[parsed.length - 1]) : '--';
    container.append(
      el('div', { class: 'eht-timeline-chip' }, [el('strong', { text: String(lines.length) }), el('span', { text: '큐' })]),
      el('div', { class: 'eht-timeline-chip' }, [el('strong', { text: first }), el('span', { text: '시작' })]),
      el('div', { class: 'eht-timeline-chip' }, [el('strong', { text: last }), el('span', { text: '마지막' })])
    );
  }

  function renderTimelinePreview(container, value) {
    container.replaceChildren();
    const lines = timelineLines(value);
    if (!lines.length) {
      container.append(el('div', { class: 'eht-timeline-empty', text: '타임라인을 적으면 아래에 큐 미리보기가 생깁니다.' }));
      return;
    }
    container.append(el('div', { class: 'eht-mini-title', text: '큐 미리보기' }));
    const visible = lines.slice(0, 7);
    for (const line of visible) {
      const seconds = parseSeconds(line);
      const body = line.replace(/^(?:(\d+):)?\d+(?:\.\d+)?\s*s?\s*/i, '').trim() || line;
      container.append(el('div', { class: 'eht-cue-row eht-cue-row-plus' }, [
        el('span', { class: 'eht-cue-time', text: formatCueTime(seconds) }),
        el('span', { class: 'eht-cue-body', text: body }),
        el('div', { class: 'eht-cue-actions' }, [
          el('button', { class: 'eht-link-btn', onclick: () => copyText(line, TEXT.copiedToast) }, [TEXT.copyButton]),
          el('button', { class: 'eht-link-btn', onclick: () => insertIntoTarget(body) }, [TEXT.insertButton])
        ])
      ]));
    }
    if (lines.length > visible.length) {
      container.append(el('div', { class: 'eht-timeline-more', text: `+${lines.length - visible.length}개 더 있음` }));
    }
  }

  function addTimelineStamp(area) {
    const now = new Date();
    const stamp = `${String(now.getMinutes()).padStart(2, '0')}.${String(now.getSeconds()).padStart(2, '0')}s  [텍스트]  x:0 y:0 size:35 fade`;
    area.value = area.value ? `${area.value}
${stamp}` : stamp;
    state.timeline = area.value;
    saveLocal();
  }

  function parseSeconds(line) {
    const match = line.trim().match(/^(?:(\d+):)?(\d+(?:\.\d+)?)\s*s?/i);
    if (!match) return Number.POSITIVE_INFINITY;
    const min = Number(match[1] || 0);
    const sec = Number(match[2] || 0);
    return min * 60 + sec;
  }

  function sortTimeline(area) {
    const lines = area.value.split('\n').filter(line => line.trim().length > 0);
    lines.sort((a, b) => parseSeconds(a) - parseSeconds(b));
    area.value = lines.join('\n');
    state.timeline = area.value;
    saveLocal();
    toast(`${TEXT.sortButton}됨`);
  }

  function renderNotes() {
    const area = el('textarea', {
      class: 'eht-textarea eht-notes',
      placeholder: TEXT.notesPlaceholder
    });
    area.value = state.notes || '';

    const counter = el('div', { class: 'eht-note-counter' });
    const updateNoteCounter = () => {
      const text = area.value || '';
      const chars = text.length;
      const lines = text ? text.split('\n').length : 0;
      counter.textContent = `${lines}줄 · ${chars}자`;
    };

    area.addEventListener('input', () => {
      state.notes = area.value;
      updateNoteCounter();
      refreshBadges(false);
      saveLocal();
    });
    updateNoteCounter();

    return el('div', { class: 'eht-section eht-notes-section' }, [
      sectionIntro(TEXT.notesTitle, TEXT.notesDescription),
      el('div', { class: 'eht-note-pad' }, [
        el('div', { class: 'eht-note-toolbar' }, [
          el('div', { class: 'eht-note-label', text: '자유 메모장' }),
          counter
        ]),
        area,
        el('div', { class: 'eht-action-row eht-note-actions' }, [
          el('button', { class: 'eht-main-btn', onclick: () => copyText(area.value, TEXT.copiedToast) }, [TEXT.copyButton]),
          el('button', { class: 'eht-main-btn', onclick: () => exportProjectData() }, [TEXT.backupJson])
        ])
      ])
    ]);
  }

  function renderSnippets() {
    const custom = el('textarea', {
      class: 'eht-textarea eht-custom-snippet',
      placeholder: TEXT.snippetsPlaceholder
    });
    custom.value = state.customSnippets || '';
    custom.addEventListener('input', () => {
      state.customSnippets = custom.value;
      refreshBadges(false);
      saveLocal();
    });

    return el('div', { class: 'eht-section' }, [
      sectionIntro(TEXT.snippetsTitle, TEXT.snippetsDescription),
      renderTargetMini(),
      ...DEFAULT_SNIPPETS.map(snippet =>
        el('div', { class: 'eht-snippet-card' }, [
          el('div', { class: 'eht-snippet-head' }, [
            el('strong', { text: snippet.title }),
            el('div', { class: 'eht-action-row' }, [
              el('button', { class: 'eht-link-btn', onclick: () => copyText(snippet.body, `${snippet.title} ${TEXT.copiedToast}`) }, [TEXT.copyButton]),
              el('button', { class: 'eht-link-btn', onclick: () => insertIntoTarget(snippet.body) }, [TEXT.insertButton])
            ])
          ]),
          el('pre', { text: snippet.body })
        ])
      ),
      el('div', { class: 'eht-mini-title', text: TEXT.mySnippets }),
      custom,
      el('div', { class: 'eht-action-row eht-wrap-row' }, [
        el('button', { class: 'eht-main-btn', onclick: () => copyText(custom.value, TEXT.copiedToast) }, [TEXT.copyMySnippets]),
        el('button', { class: 'eht-main-btn', onclick: () => insertIntoTarget(custom.value) }, [TEXT.insertTextButton])
      ])
    ]);
  }

  function renderTips() {
    return el('div', { class: 'eht-section' }, [
      sectionIntro(TEXT.tipsTitle, TEXT.tipsDescription),
      el('button', { class: 'eht-main-btn eht-full-btn', onclick: rerollWarning }, [TEXT.randomButton]),
      ...WARNINGS.map((tip, index) => el('button', {
        class: `eht-warning eht-tip-list-item ${index === state.warningIndex ? 'is-active' : ''}`,
        onclick: () => {
          state.warningIndex = index;
          saveLocal();
          render();
        }
      }, [tip]))
    ]);
  }

  function renderBridge() {
    const workspace = detectWorkspace();
    const targetLabel = getTargetLabel();
    const bridgeData = parseBridgeItems(state.bridgeJson);
    const items = bridgeData.items;
    if (!Number.isInteger(state.bridgeActiveIndex)) state.bridgeActiveIndex = 0;
    if (items.length) state.bridgeActiveIndex = clamp(state.bridgeActiveIndex, 0, items.length - 1);
    else state.bridgeActiveIndex = 0;

    const insertArea = el('textarea', {
      class: 'eht-textarea eht-bridge-insert',
      placeholder: '현재 입력칸에 넣을 텍스트'
    });
    insertArea.value = state.bridgeInsertText || '';
    insertArea.addEventListener('input', () => {
      state.bridgeInsertText = insertArea.value;
      saveLocal();
    });

    const bridgeArea = el('textarea', {
      class: 'eht-textarea eht-bridge-json',
      placeholder: TEXT.bridgePlaceholder,
      spellcheck: 'false'
    });
    bridgeArea.value = state.bridgeJson || '';

    const jsonStatus = el('div', { class: 'eht-hint' });
    const queue = el('div', { class: 'eht-bridge-queue' });
    const activeBox = el('div', { class: 'eht-bridge-active' });

    const updateBridge = () => {
      state.bridgeJson = bridgeArea.value;
      const parsed = parseBridgeItems(bridgeArea.value);
      if (parsed.items.length) state.bridgeActiveIndex = clamp(state.bridgeActiveIndex || 0, 0, parsed.items.length - 1);
      else state.bridgeActiveIndex = 0;
      renderBridgeActive(activeBox, parsed.items);
      renderBridgeQueue(queue, jsonStatus, bridgeArea.value);
      refreshBadges(false);
      saveLocal();
    };

    bridgeArea.addEventListener('input', updateBridge);
    renderBridgeActive(activeBox, items);
    renderBridgeQueue(queue, jsonStatus, bridgeArea.value);

    return el('div', { class: 'eht-section eht-bridge-section' }, [
      sectionIntro(TEXT.studioTitle, TEXT.studioDescription),
      el('div', { class: 'eht-status-grid' }, [
        statusChip(TEXT.detectWorkspace, workspace.ok ? TEXT.detected : TEXT.notDetected, workspace.ok),
        statusChip(TEXT.currentTarget, targetLabel, Boolean(lastEditableTarget && document.contains(lastEditableTarget)))
      ]),
      el('div', { class: 'eht-bridge-card' }, [
        el('div', { class: 'eht-mini-title', text: '현재 입력칸 도구' }),
        insertArea,
        el('div', { class: 'eht-action-row eht-wrap-row' }, [
          el('button', { class: 'eht-main-btn', onclick: () => insertIntoTarget(insertArea.value) }, [TEXT.insertTextButton]),
          el('button', { class: 'eht-link-btn', onclick: () => replaceTargetValue(insertArea.value) }, ['덮어쓰기']),
          el('button', { class: 'eht-link-btn', onclick: () => clearTargetValue() }, ['비우기']),
          el('button', { class: 'eht-link-btn', onclick: () => flashTarget() }, ['대상 표시']),
          el('button', { class: 'eht-link-btn', onclick: () => copyText(insertArea.value, TEXT.copiedToast) }, [TEXT.copyButton]),
          el('button', { class: 'eht-link-btn', onclick: () => bringSelectionToArea(insertArea) }, [TEXT.bringSelection])
        ])
      ]),
      sectionIntro(TEXT.bridgeTitle, TEXT.bridgeDescription),
      el('div', { class: 'eht-bridge-card eht-viventry-card' }, [
        bridgeArea,
        el('div', { class: 'eht-action-row eht-wrap-row' }, [
          el('button', { class: 'eht-main-btn', onclick: () => { updateBridge(); toast(TEXT.parseJson); } }, [TEXT.parseJson]),
          el('button', { class: 'eht-link-btn', onclick: () => fillBridgeExample(bridgeArea, updateBridge) }, ['예시']),
          el('button', { class: 'eht-link-btn', onclick: () => timelineToBridge(bridgeArea, updateBridge) }, ['타임라인→Bridge']),
          el('button', { class: 'eht-link-btn', onclick: () => copyText(bridgeArea.value, TEXT.copiedToast) }, [TEXT.copyButton]),
          el('button', { class: 'eht-link-btn', onclick: () => { state.bridgeDone = {}; saveLocal(); render(); } }, [TEXT.clearDone])
        ]),
        jsonStatus,
        activeBox,
        queue
      ])
    ]);
  }

  

  
  let manualSaveButtonTarget = null;
  let pickingSaveButton = false;

  function pickSaveButtonTarget() {
    pickingSaveButton = true;
    markSaveStatus('watching', '저장 버튼 지정 대기 중', '엔트리의 실제 저장 버튼을 한 번 클릭하세요. Radiance가 그 버튼을 기억합니다.');
    toast('엔트리 저장 버튼을 한 번 클릭해 주세요.');
  }

  function rememberSaveButtonTarget(target) {
    if (!target || isRadianceNode(target)) return false;
    const button = target.closest?.('button, a, [role="button"], div, span') || target;
    if (!(button instanceof HTMLElement) || isRadianceNode(button)) return false;
    manualSaveButtonTarget = button;
    state.saveWatcher = Object.assign(defaultSaveWatcherState(), state.saveWatcher || {});
    state.saveWatcher.manualButtonLabel = getSaveCandidateLabel(button) || button.tagName.toLowerCase();
    state.saveWatcher.manualButtonSetAt = new Date().toISOString();
    markSaveStatus('idle', '저장 버튼 지정됨', `기억한 버튼: ${state.saveWatcher.manualButtonLabel || '저장 버튼'}`);
    saveLocalNow();
    render();
    return true;
  }

  function getPreferredSaveButton() {
    if (manualSaveButtonTarget && document.contains(manualSaveButtonTarget)) return manualSaveButtonTarget;
    return findEntrySaveButton();
  }


  function renderPageSearch() {
    const stateData = ensurePageSearchState();
    const detection = detectPageSearchArea();
    const result = stateData.active ? getPageSearchResult(stateData.query || '') : { total: countLibraryCandidates(), matched: 0, hidden: 0 };

    const input = el('input', {
      class: 'eht-page-search-input',
      type: 'search',
      placeholder: '작품 제목, 설명, 닉네임 등 검색',
      value: stateData.query || ''
    });
    let composingPageSearch = false;
    input.addEventListener('compositionstart', () => { composingPageSearch = true; });
    input.addEventListener('compositionend', () => {
      composingPageSearch = false;
      state.pageSearch.query = input.value;
      saveLocal();
    });
    input.addEventListener('input', () => {
      state.pageSearch.query = input.value;
      saveLocal();
    });
    input.addEventListener('keydown', event => {
      if (event.key === 'Enter' && !composingPageSearch) {
        event.preventDefault();
        state.pageSearch.query = input.value;
        state.pageSearch.active = true;
        saveLocal();
        applyPageSearch();
        render();
      }
      if (event.key === 'Escape') {
        event.preventDefault();
        clearPageSearch();
      }
    });

    return el('div', { class: 'eht-section eht-pageSearch-section' }, [
      sectionIntro('페이지 내부 검색', '현재 페이지에 로딩된 카드/항목/작품을 검색합니다. 입력 후 Enter 또는 검색 적용을 누르세요.'),
      el('div', { class: 'eht-status-grid' }, [
        statusChip('페이지 항목', detection.ok ? '감지됨' : '미확실', detection.ok),
        statusChip('검색 대상', `${result.total}개`, result.total > 0),
        statusChip('일치 항목', stateData.active ? `${result.matched}개` : '대기 중', stateData.active && result.matched > 0),
        statusChip('필터 상태', stateData.active ? 'ON' : 'OFF', Boolean(stateData.active))
      ]),
      el('div', { class: 'eht-save-card eht-pageSearch-card' }, [
        el('div', { class: 'eht-mini-title', text: '페이지 내부 검색' }),
        input,
        el('div', { class: 'eht-inline-hint', text: 'Enter로 검색 / Esc로 필터 해제' }),
        el('div', { class: 'eht-action-row eht-wrap-row' }, [
          el('button', { class: 'eht-main-btn', onclick: () => { state.pageSearch.query = input.value; state.pageSearch.active = true; saveLocal(); applyPageSearch(); render(); } }, ['검색 적용']),
          el('button', { class: 'eht-link-btn', onclick: () => { state.pageSearch.hideNonMatches = !state.pageSearch.hideNonMatches; saveLocal(); applyPageSearch(); render(); } }, [stateData.hideNonMatches ? '흐리게 보기' : '숨기기']),
          el('button', { class: 'eht-link-btn', onclick: clearPageSearch }, ['필터 해제']),
          el('button', { class: 'eht-link-btn', onclick: () => { applyPageSearch(); toast('페이지 내부 검색을 새로고침했습니다.'); } }, ['다시 스캔'])
        ]),
        el('div', { class: 'eht-hint', text: stateData.hideNonMatches ? '필터 모드: 불일치 항목 숨김' : '필터 모드: 불일치 항목 흐리게 표시' })
      ]),
      renderPageSearchPreview()
    ]);
  }

  function ensurePageSearchState() {
    if (!state.pageSearch || typeof state.pageSearch !== 'object') {
      state.pageSearch = defaultPageSearchState();
    }
    state.pageSearch = Object.assign(defaultPageSearchState(), state.pageSearch);
    return state.pageSearch;
  }

  function defaultPageSearchState() {
    return {
      query: '',
      active: false,
      hideNonMatches: true
    };
  }

  function detectPageSearchArea() {
    const path = (location.pathname || '').toLowerCase();
    const text = (document.body?.innerText || '').slice(0, 3000);
    const urlLooks = /storage|bookmark|my|mypage|profile|workspace|project|search|community|ranking|challenge|studio/.test(path);
    const textLooks = /(나의 페이지|페이지 항목|페이지|내 작품|나의 작품|즐겨찾기|좋아요|북마크)/.test(text);
    const cards = countLibraryCandidates();
    return { ok: urlLooks || textLooks || cards >= 3, urlLooks, textLooks, cards };
  }

  function getLibraryCandidates() {
    const selector = [
      'article',
      'li',
      'a[href*="/project"]',
      'a[href*="/entry"]',
      'div[class*="card" i]',
      'div[class*="project" i]',
      'div[class*="item" i]',
      'div[class*="work" i]',
      'div[class*="list" i] > div'
    ].join(',');

    const nodes = Array.from(document.querySelectorAll(selector));
    const result = [];
    const seen = new Set();
    const vw = Math.max(window.innerWidth || 1, 1);
    const vh = Math.max(window.innerHeight || 1, 1);

    for (const node of nodes) {
      if (!(node instanceof HTMLElement)) continue;
      if (isRadianceNode(node)) continue;
      if (node.closest?.(`#${APP_ID}, #${APP_ID}-bubble`)) continue;
      const rect = node.getBoundingClientRect();
      if (rect.width < 90 || rect.height < 45) continue;
      if (rect.width > vw * 0.98 && rect.height > vh * 0.85) continue;
      const text = getLibraryCandidateText(node);
      if (!text || text.length < 2) continue;
      if (text.length > 800) continue;

      const candidate = normalizeLibraryCard(node);
      if (!candidate || seen.has(candidate)) continue;
      seen.add(candidate);
      result.push(candidate);
      if (result.length >= 250) break;
    }

    return result;
  }

  function normalizeLibraryCard(node) {
    let current = node;
    let best = node;
    let depth = 0;
    const vw = Math.max(window.innerWidth || 1, 1);
    const vh = Math.max(window.innerHeight || 1, 1);

    while (current && current instanceof HTMLElement && depth < 4) {
      if (isRadianceNode(current)) break;
      const rect = current.getBoundingClientRect();
      const text = getLibraryCandidateText(current);
      const classKey = `${current.className || ''} ${current.id || ''}`;
      const cardLike = current.matches('article, li, a') || /(card|project|item|work|thumb|list)/i.test(classKey);
      const reasonable = rect.width >= 100 && rect.height >= 55 && rect.width < vw * 0.95 && rect.height < vh * 0.75;
      if (reasonable && cardLike && text && text.length < 800) best = current;
      current = current.parentElement;
      depth += 1;
    }

    return best;
  }

  function getLibraryCandidateText(node) {
    return (node.innerText || node.textContent || node.getAttribute?.('aria-label') || node.getAttribute?.('title') || '')
      .replace(/\s+/g, ' ')
      .trim();
  }

  function countLibraryCandidates() {
    try {
      return getLibraryCandidates().length;
    } catch {
      return 0;
    }
  }

  function getPageSearchResult(query) {
    const cards = getLibraryCandidates();
    const q = normalizeSearchText(query);
    if (!q) return { total: cards.length, matched: 0, hidden: 0 };
    let matched = 0;
    let hidden = 0;
    for (const card of cards) {
      const text = normalizeSearchText(getLibraryCandidateText(card));
      if (text.includes(q)) matched += 1;
      else hidden += 1;
    }
    return { total: cards.length, matched, hidden };
  }

  function normalizeSearchText(value) {
    return String(value || '').toLowerCase().replace(/\s+/g, ' ').trim();
  }

  function applyPageSearch() {
    const search = ensurePageSearchState();
    clearPageSearchClasses(false);
    const query = normalizeSearchText(search.query);
    if (!query) {
      search.active = false;
      saveLocal();
      return;
    }

    search.active = true;
    const cards = getLibraryCandidates();
    let matched = 0;

    for (const card of cards) {
      const text = normalizeSearchText(getLibraryCandidateText(card));
      const ok = text.includes(query);
      card.classList.add('radiance-page-search-card');
      if (ok) {
        matched += 1;
        card.classList.add('radiance-pageSearch-match');
      } else {
        card.classList.add(search.hideNonMatches ? 'radiance-pageSearch-hidden' : 'radiance-pageSearch-dim');
      }
    }

    state.stats.pageSearches = Number(state.stats.pageSearches || 0) + 1;
    saveLocal();
    if (matched === 0) toast('일치하는 페이지 항목이 없습니다.');
    else toast(`${matched}개 항목을 찾았습니다.`);
  }

  function clearPageSearch() {
    ensurePageSearchState().query = '';
    ensurePageSearchState().active = false;
    clearPageSearchClasses(true);
    saveLocalNow();
    render();
  }

  function clearPageSearchClasses(removeMatches = true) {
    document.querySelectorAll?.('.radiance-page-search-card, .radiance-pageSearch-match, .radiance-pageSearch-hidden, .radiance-pageSearch-dim').forEach(node => {
      node.classList.remove('radiance-page-search-card', 'radiance-pageSearch-match', 'radiance-pageSearch-hidden', 'radiance-pageSearch-dim');
    });
  }

  function renderPageSearchPreview() {
    const search = ensurePageSearchState();
    const query = normalizeSearchText(search.query);
    if (!query || !search.active) {
      return el('div', { class: 'eht-save-card' }, [
        el('div', { class: 'eht-mini-title', text: '검색 미리보기' }),
        el('div', { class: 'eht-hint', text: '검색어를 입력하고 “검색 적용”을 누르면 현재 화면의 페이지 카드가 필터링됩니다.' })
      ]);
    }

    const cards = getLibraryCandidates();
    const matches = cards
      .map(card => getLibraryCandidateText(card))
      .filter(text => normalizeSearchText(text).includes(query))
      .slice(0, 8);

    return el('div', { class: 'eht-save-card' }, [
      el('div', { class: 'eht-mini-title', text: '검색 결과 미리보기' }),
      matches.length
        ? el('div', { class: 'eht-pageSearch-preview-list' }, matches.map(text =>
            el('div', { class: 'eht-pageSearch-preview-item', text: text.length > 90 ? text.slice(0, 90) + '…' : text })
          ))
        : el('div', { class: 'eht-hint', text: '미리볼 일치 항목이 없습니다.' })
    ]);
  }


  function renderLeaveGuard() {
    const guard = ensureLeaveGuardState();
    return el('div', { class: 'eht-section eht-guard-section' }, [
      sectionIntro('작업 보호', '작업 보호 감지는 안정화 전까지 봉인했습니다.'),
      el('div', { class: 'eht-status-grid' }, [
        statusChip('보호 상태', '봉인됨', false),
        statusChip('나가기 감지', 'OFF', false),
        statusChip('브라우저 경고', 'OFF', false),
        statusChip('상태 저장', guard.sealed ? '안전 모드' : '안전 모드', true)
      ]),
      el('div', { class: 'eht-save-card eht-guard-card eht-sealed-card' }, [
        el('div', { class: 'eht-sealed-icon', text: '🛡️' }),
        el('div', { class: 'eht-mini-title', text: 'Work Guard Coming Soon..' }),
        el('div', { class: 'eht-hint', text: '이전 작업 보호 감지가 페이지 이동/작업 상태를 과하게 잡는 문제가 있어서, 이번 버전에서는 기능을 봉인했습니다.' }),
        el('div', { class: 'eht-hint', text: '현재는 페이지 검색, 내부 백업, 메모/타임라인 기능 중심으로 안정화합니다.' })
      ])
    ]);
  }

  function ensureLeaveGuardState() {
    if (!state.leaveGuard || typeof state.leaveGuard !== 'object') {
      state.leaveGuard = defaultLeaveGuardState();
    }
    state.leaveGuard = Object.assign(defaultLeaveGuardState(), state.leaveGuard, { enabled: false, dirty: false, sealed: true });
    return state.leaveGuard;
  }

  function defaultLeaveGuardState() {
    return {
      enabled: false,
      dirty: false,
      sealed: true,
      lastDirtyAt: '',
      lastCleanAt: ''
    };
  }

  function renderLeaveGuardToggle() {
    return el('div', { class: 'eht-auto-save-box eht-sealed-card' }, [
      el('div', { class: 'eht-setting-main' }, [
        el('div', { class: 'eht-setting-title' }, [
          el('strong', { text: '작업 보호 봉인됨' }),
          el('span', { class: 'eht-pill', text: 'SEALED' })
        ]),
        el('p', { text: '이 기능은 안정화 후 다시 열 예정입니다.' })
      ])
    ]);
  }

  function markProjectDirty() { return; }

  function markProjectClean() {
    const guard = ensureLeaveGuardState();
    guard.dirty = false;
    guard.enabled = false;
    saveLocalNow();
  }

  let pendingLeaveHref = '';

  function shouldWarnBeforeLeave() { return false; }

  function showLeaveGuardOverlay() {
    toast('작업 보호는 현재 봉인된 기능입니다.');
    return false;
  }

  function setupLeaveGuardListeners() {
    // Work Guard detection is sealed in v1.0.1 to avoid false positives.
    return;
  }


  function renderSaveClicker() {
    const backup = ensureBackupState();
    const last = backup.lastBackupAt ? new Date(backup.lastBackupAt).toLocaleString() : '아직 없음';
    const count = Array.isArray(backup.items) ? backup.items.length : 0;

    return el('div', { class: 'eht-section eht-backup-section' }, [
      sectionIntro('Radiance 내부 백업', '엔트리 작품 자체가 아니라, Radiance 안의 메모/타임라인/체크리스트를 로컬에 백업합니다.'),
      el('div', { class: 'eht-status-grid' }, [
        statusChip('백업 개수', `${count}개`, count > 0),
        statusChip('마지막 백업', last, Boolean(backup.lastBackupAt)),
        statusChip('자동 백업', backup.autoEnabled ? 'ON' : 'OFF', Boolean(backup.autoEnabled)),
        statusChip('백업 위치', '브라우저 로컬', true)
      ]),
      el('div', { class: 'eht-save-card eht-backup-card' }, [
        el('div', { class: 'eht-mini-title', text: '백업 도구' }),
        renderInternalBackupControls(),
        el('div', { class: 'eht-action-row eht-wrap-row' }, [
          el('button', { class: 'eht-main-btn', onclick: () => createInternalBackup('manual') }, ['지금 백업']),
          el('button', { class: 'eht-link-btn', onclick: restoreLatestInternalBackup }, ['최신 복원']),
          el('button', { class: 'eht-link-btn', onclick: copyLatestInternalBackup }, ['최신 복사']),
          el('button', { class: 'eht-link-btn', onclick: clearInternalBackups }, ['백업 비우기'])
        ]),
        el('div', { class: 'eht-hint', text: '최근 12개까지 보관합니다. 브라우저 로컬 저장소라서 확장프로그램을 지우면 같이 사라질 수 있습니다.' })
      ]),
      renderInternalBackupList()
    ]);
  }

  function ensureBackupState() {
    if (!state.internalBackup || typeof state.internalBackup !== 'object') {
      state.internalBackup = defaultInternalBackupState();
    }
    state.internalBackup = Object.assign(defaultInternalBackupState(), state.internalBackup);
    if (!Array.isArray(state.internalBackup.items)) state.internalBackup.items = [];
    return state.internalBackup;
  }

  function defaultInternalBackupState() {
    return {
      autoEnabled: true,
      intervalMinutes: 5,
      lastBackupAt: '',
      items: []
    };
  }

  function renderInternalBackupControls() {
    const backup = ensureBackupState();
    const toggle = el('input', { type: 'checkbox', class: 'eht-switch-input' });
    toggle.checked = Boolean(backup.autoEnabled);
    toggle.addEventListener('change', event => {
      ensureBackupState().autoEnabled = Boolean(event.currentTarget.checked);
      saveLocalNow();
      setupInternalBackupTimer();
      toast(ensureBackupState().autoEnabled ? '내부 자동 백업 켜짐' : '내부 자동 백업 꺼짐');
      render();
    });

    const minutes = el('input', {
      type: 'number',
      min: '1',
      max: '60',
      value: String(backup.intervalMinutes || 5),
      class: 'eht-small-input'
    });
    minutes.addEventListener('input', () => {
      ensureBackupState().intervalMinutes = clamp(Number(minutes.value || 5), 1, 60);
      saveLocalNow();
      setupInternalBackupTimer();
    });

    return el('div', { class: `eht-auto-save-box ${backup.autoEnabled ? 'is-enabled' : ''}` }, [
      el('div', { class: 'eht-save-row' }, [
        el('div', { class: 'eht-setting-main' }, [
          el('div', { class: 'eht-setting-title' }, [
            el('strong', { text: '내부 자동 백업' }),
            el('span', { class: 'eht-pill', text: backup.autoEnabled ? 'ON' : 'OFF' })
          ]),
          el('p', { text: 'Radiance 작업 데이터를 정해진 간격마다 로컬 백업합니다.' })
        ]),
        el('label', { class: 'eht-switch eht-switch-clickable' }, [toggle, el('i')])
      ]),
      el('label', { class: 'eht-save-interval' }, [
        el('span', { text: '간격' }),
        minutes,
        el('span', { text: '분' })
      ])
    ]);
  }

  function renderInternalBackupList() {
    const items = ensureBackupState().items || [];
    if (!items.length) {
      return el('div', { class: 'eht-save-card' }, [
        el('div', { class: 'eht-mini-title', text: '백업 목록' }),
        el('div', { class: 'eht-hint', text: '아직 백업이 없습니다. “지금 백업”을 눌러 첫 백업을 만들어 보세요.' })
      ]);
    }

    return el('div', { class: 'eht-save-card' }, [
      el('div', { class: 'eht-mini-title', text: '최근 백업' }),
      el('div', { class: 'eht-backup-list' }, items.slice(0, 6).map((item, index) =>
        el('div', { class: 'eht-backup-item' }, [
          el('div', { class: 'eht-backup-main' }, [
            el('strong', { text: new Date(item.createdAt).toLocaleString() }),
            el('span', { text: `${item.reason || 'backup'} · 타임라인 ${item.summary?.timelineLines || 0}줄 · 메모 ${item.summary?.notesLength || 0}자` })
          ]),
          el('div', { class: 'eht-action-row eht-wrap-row' }, [
            el('button', { class: 'eht-link-btn', onclick: () => restoreInternalBackup(index) }, ['복원']),
            el('button', { class: 'eht-link-btn', onclick: () => copyText(JSON.stringify(item, null, 2), TEXT.copiedToast) }, ['복사'])
          ])
        ])
      ))
    ]);
  }

  let internalBackupTimer = null;

  function setupInternalBackupTimer() {
    if (internalBackupTimer) {
      clearInterval(internalBackupTimer);
      internalBackupTimer = null;
    }
    const backup = ensureBackupState();
    if (!backup.autoEnabled) return;
    const minutes = clamp(Number(backup.intervalMinutes || 5), 1, 60);
    internalBackupTimer = setInterval(() => createInternalBackup('auto'), minutes * 60 * 1000);
  }

  function makeInternalBackupSnapshot(reason = 'manual') {
    const timeline = state.timeline || '';
    const notes = state.notes || '';
    const customSnippets = state.customSnippets || '';
    const bridgeJson = state.bridgeJson || '';
    return {
      type: 'radiance-internal-backup',
      version: '0.6.9',
      reason,
      projectKey,
      createdAt: new Date().toISOString(),
      data: {
        checklist: state.checklist || {},
        timeline,
        notes,
        customSnippets,
        bridgeJson,
        bridgeDone: state.bridgeDone || {},
        bridgeInsertText: state.bridgeInsertText || '',
        bridgeActiveIndex: state.bridgeActiveIndex || 0,
        badges: state.badges || {},
        stats: state.stats || {},
        warningIndex: state.warningIndex || 0
      },
      summary: {
        checklistDone: Object.values(state.checklist || {}).filter(Boolean).length,
        timelineLines: timelineLines(timeline).length,
        notesLength: notes.trim().length,
        snippetLength: customSnippets.trim().length,
        bridgeItems: parseBridgeItems(bridgeJson).items.length
      }
    };
  }

  function createInternalBackup(reason = 'manual') {
    const backup = ensureBackupState();
    const snapshot = makeInternalBackupSnapshot(reason);
    const latest = backup.items?.[0];
    snapshot.fingerprint = fingerprintBackup(snapshot);
    if (reason === 'auto' && latest && latest.fingerprint === snapshot.fingerprint) return false;
    backup.items = [snapshot, ...(backup.items || [])].slice(0, 12);
    backup.lastBackupAt = snapshot.createdAt;
    state.stats.internalBackups = Number(state.stats.internalBackups || 0) + 1;
    saveLocal();
    refreshBadges(true);
    if (reason !== 'auto') {
      toast('Radiance 내부 백업 완료');
      render();
    }
    return true;
  }

  function fingerprintBackup(snapshot) {
    try {
      return JSON.stringify({
        checklist: snapshot.data.checklist,
        timeline: snapshot.data.timeline,
        notes: snapshot.data.notes,
        customSnippets: snapshot.data.customSnippets,
        bridgeJson: snapshot.data.bridgeJson
      });
    } catch {
      return String(Date.now());
    }
  }

  function restoreLatestInternalBackup() {
    const items = ensureBackupState().items || [];
    if (!items.length) {
      toast('복원할 백업이 없습니다.');
      return false;
    }
    return restoreInternalBackup(0);
  }

  function restoreInternalBackup(index = 0) {
    const item = ensureBackupState().items?.[index];
    if (!item || !item.data) {
      toast('복원할 백업이 없습니다.');
      return false;
    }
    const ok = confirm('이 백업으로 Radiance 데이터를 복원할까요? 현재 메모/타임라인이 바뀝니다.');
    if (!ok) return false;
    state.checklist = item.data.checklist || {};
    state.timeline = item.data.timeline || '';
    state.notes = item.data.notes || '';
    state.customSnippets = item.data.customSnippets || '';
    state.bridgeJson = item.data.bridgeJson || '';
    state.bridgeDone = item.data.bridgeDone || {};
    state.bridgeInsertText = item.data.bridgeInsertText || '';
    state.bridgeActiveIndex = item.data.bridgeActiveIndex || 0;
    state.badges = item.data.badges || {};
    state.stats = item.data.stats || {};
    if (Number.isFinite(Number(item.data.warningIndex))) state.warningIndex = Number(item.data.warningIndex);
    saveLocal();
    toast('Radiance 백업 복원 완료');
    render();
    return true;
  }

  function copyLatestInternalBackup() {
    const item = ensureBackupState().items?.[0];
    if (!item) {
      toast('복사할 백업이 없습니다.');
      return false;
    }
    copyText(JSON.stringify(item, null, 2), TEXT.copiedToast);
    return true;
  }

  function clearInternalBackups() {
    const ok = confirm('Radiance 내부 백업 목록을 모두 지울까요?');
    if (!ok) return;
    ensureBackupState().items = [];
    ensureBackupState().lastBackupAt = '';
    saveLocal();
    toast('백업을 비웠습니다.');
    render();
  }


  function defaultSaveWatcherState() {
    return {
      status: 'idle',
      message: '대기 중',
      detail: '',
      lastClickAt: '',
      lastSuccessAt: '',
      lastDetectedText: '',
      lastButtonLabel: '',
      watchUntil: 0,
      autoEnabled: false,
      autoMinutes: 5,
      hideEntrySaveUi: true,
      manualButtonLabel: '',
      manualButtonSetAt: ''
    };
  }


  function renderHideEntrySaveUiToggle() {
    const enabled = state.saveWatcher?.hideEntrySaveUi !== false;
    const toggle = el('input', { type: 'checkbox', ...(enabled ? { checked: 'checked' } : {}) });
    toggle.addEventListener('change', event => {
      setHideEntrySaveUi(Boolean(event.target.checked));
      toast(Boolean(event.target.checked) ? '엔트리 저장 UI 숨김' : '엔트리 저장 UI 표시');
    });

    return el('div', { class: 'eht-auto-save-box eht-hide-save-ui-box' }, [
      el('div', { class: 'eht-save-row' }, [
        el('div', { class: 'eht-setting-main' }, [
          el('div', { class: 'eht-setting-title' }, [
            el('strong', { text: '엔트리 저장 UI 숨기기' }),
            el('span', { class: 'eht-pill', text: '권장' })
          ]),
          el('p', { text: '저장 중/저장 완료 팝업은 숨기고, Radiance 패널에서만 상태를 보여줍니다.' })
        ]),
        el('span', { class: 'eht-switch' }, [toggle, el('i')])
      ])
    ]);
  }

  function setHideEntrySaveUi(enabled) {
    state.saveWatcher = Object.assign(defaultSaveWatcherState(), state.saveWatcher || {});
    state.saveWatcher.hideEntrySaveUi = Boolean(enabled);
    if (!state.saveWatcher.hideEntrySaveUi) clearHiddenEntrySaveUi();
    else hideEntrySaveUiCandidates();
    saveLocalNow();
    render();
  }

  function clearHiddenEntrySaveUi() {
    document.querySelectorAll?.('.radiance-entry-save-ui-hidden').forEach(node => {
      node.classList.remove('radiance-entry-save-ui-hidden');
    });
  }

  function hideEntrySaveUiCandidates() {
    if (!state.saveWatcher?.hideEntrySaveUi) return;
    const nodes = Array.from(document.querySelectorAll('div, span, p, strong, em, small, button, [role="alert"], [aria-live]'));
    for (const node of nodes) {
      if (!(node instanceof HTMLElement)) continue;
      if (isRadianceNode(node)) continue;
      const text = (node.innerText || node.textContent || '').replace(/\s+/g, ' ').trim();
      if (!isEntrySaveStatusText(text)) continue;
      const target = findEntrySaveUiContainer(node);
      if (!target || isRadianceNode(target)) continue;
      target.classList.add('radiance-entry-save-ui-hidden');
    }
  }

  function isEntrySaveStatusText(text) {
    if (!text || text.length > 90) return false;
    if (/^(저장|저장하기|Radiance 백업|프로젝트 저장|save)$/i.test(text)) return false;
    return /(저장\s*중|저장되었습니다|저장 완료|저장완료|저장됨|저장했어요|저장 성공|saving|saved|save complete|saved successfully)/i.test(text);
  }

  function findEntrySaveUiContainer(node) {
    let current = node;
    let best = node;
    let depth = 0;
    const vw = Math.max(window.innerWidth || 1, 1);
    const vh = Math.max(window.innerHeight || 1, 1);

    while (current && current instanceof HTMLElement && depth < 5) {
      if (isRadianceNode(current)) break;
      const rect = current.getBoundingClientRect();
      const style = window.getComputedStyle(current);
      const classKey = `${current.className || ''} ${current.id || ''}`;
      const toastLike = /(toast|snack|alert|popup|modal|layer|notice|tooltip|save)/i.test(classKey);
      const floating = ['fixed', 'absolute', 'sticky'].includes(style.position);
      const smallEnough = rect.width > 0 && rect.height > 0 && rect.width < Math.min(520, vw * 0.8) && rect.height < Math.min(220, vh * 0.35);
      if (smallEnough && (toastLike || floating)) best = current;
      current = current.parentElement;
      depth += 1;
    }
    return best;
  }


  function renderAutoSaveControls() {
    return el('div', { class: 'eht-auto-save-box eht-auto-save-disabled' }, [
      el('div', { class: 'eht-save-row' }, [
        el('div', { class: 'eht-setting-main' }, [
          el('div', { class: 'eht-setting-title' }, [
            el('strong', { text: '자동 저장 임시 중단' }),
            el('span', { class: 'eht-pill', text: 'HOTFIX' })
          ]),
          el('p', { text: '페이지 멈춤 방지를 위해 자동 저장은 잠시 꺼두었습니다. 백업 탭의 “저장 버튼 지정”과 “지금 저장하기”를 사용해 주세요.' })
        ])
      ])
    ]);
  }

  let saveAutoTimer = null;
  let saveWatchTimer = null;
  let saveMutationObserver = null;

  function setupAutoSaveClicker() {
    return;
  }

  function findEntrySaveButton() {
    if (manualSaveButtonTarget && document.contains(manualSaveButtonTarget)) return manualSaveButtonTarget;
    const candidates = Array.from(document.querySelectorAll('button, a, [role="button"], [aria-label], [title]'));
    for (const node of candidates) {
      if (!(node instanceof HTMLElement)) continue;
      if (isRadianceNode(node)) continue;
      const rect = node.getBoundingClientRect();
      if (rect.width < 18 || rect.height < 14) continue;
      const style = window.getComputedStyle(node);
      if (style.display === 'none' || style.visibility === 'hidden' || Number(style.opacity || 1) < 0.2) continue;
      const label = getSaveCandidateLabel(node);
      if (!label || isBadSaveLabel(label)) continue;
      if (/^(저장|저장하기|Radiance 백업|프로젝트 저장|save)$/i.test(label)) return node;
      if (/저장|save/i.test(label) && label.length <= 28) return node;
    }
    return null;
  }

  function getSaveCandidateLabel(node) {
    const aria = node.getAttribute?.('aria-label') || '';
    const title = node.getAttribute?.('title') || '';
    const text = (node.innerText || node.textContent || '').replace(/\s+/g, ' ').trim();
    return `${aria} ${title} ${text}`.replace(/\s+/g, ' ').trim();
  }

  function isBadSaveLabel(label) {
    return /(임시저장|자동저장|저장됨|저장중|저장 중|저장완료|저장 완료|저장되었습니다|저장 성공|불러오기|공유|save complete|saved|saving)/i.test(label);
  }

  function attemptEntrySave(reason = 'manual') {
    if (!detectWorkspace().ok) {
      markSaveStatus('failed', '작품만들기 미감지', '엔트리 작품만들기 화면에서 저장을 시도해 주세요.');
      toast('작품만들기 화면에서 저장을 시도해 주세요.');
      return false;
    }

    const button = findEntrySaveButton();
    if (!button) {
      markSaveStatus('failed', '저장 버튼 미감지', '저장 버튼이 화면에 보이는지 확인해 주세요.');
      toast('저장 버튼을 찾지 못했습니다.');
      return false;
    }

    try {
      button.scrollIntoView?.({ block: 'center', inline: 'center', behavior: 'smooth' });
      button.classList.add('radiance-save-flash');
      setTimeout(() => button.classList.remove('radiance-save-flash'), 1300);

      state.saveWatcher = Object.assign(defaultSaveWatcherState(), state.saveWatcher || {});
      state.saveWatcher.lastClickAt = new Date().toISOString();
      state.saveWatcher.lastButtonLabel = getSaveCandidateLabel(button);
      state.stats.saveClickAttempts = Number(state.stats.saveClickAttempts || 0) + 1;
      saveLocal();

      markSaveStatus('watching', reason === 'auto' ? '자동 저장 클릭됨' : '저장 버튼 클릭됨', 'Radiance가 저장 버튼을 눌렀고, 저장 완료 문구를 감시합니다.');

      setTimeout(() => {
        try {
          button.click();
          startSaveWatch(reason === 'auto' ? 'auto-click' : 'radiance-click');
        } catch (error) {
          console.warn('Radiance save click failed', error);
          markSaveStatus('failed', '저장 버튼 클릭 실패', '버튼은 찾았지만 클릭 중 오류가 발생했습니다.');
        }
      }, 120);

      return true;
    } catch (error) {
      console.warn('Radiance save attempt failed', error);
      markSaveStatus('failed', '저장 시도 실패', '저장 버튼 처리 중 오류가 발생했습니다.');
      return false;
    }
  }

  function startSaveWatch(source = 'manual-watch') {
    state.saveWatcher = Object.assign(defaultSaveWatcherState(), state.saveWatcher || {});
    if (!state.saveWatcher.lastClickAt) state.saveWatcher.lastClickAt = new Date().toISOString();
    const label = source === 'click' ? '저장 버튼 직접 클릭 감지됨' : source === 'shortcut' ? 'Ctrl+S 저장 감지 시작' : source === 'auto-click' ? '자동 저장 감시 중' : '저장 감시 중';
    markSaveStatus('watching', label, '저장 완료 문구를 20초 동안 감시합니다.');
    stopSaveWatchTimersOnly();

    const startedAt = Date.now();
    saveMutationObserver = new MutationObserver(() => { hideEntrySaveUiCandidates(); inspectSaveSuccess(startedAt); });
    try {
      saveMutationObserver.observe(document.body, { childList: true, subtree: true, characterData: true, attributes: true });
    } catch {}

    saveWatchTimer = setInterval(() => {
      hideEntrySaveUiCandidates();
      const done = inspectSaveSuccess(startedAt);
      if (done) return;
      if (Date.now() - startedAt > 20000) {
        stopSaveWatchTimersOnly();
        markSaveStatus('failed', '저장 성공 문구 미감지', '저장은 되었을 수 있지만, Radiance가 완료 문구를 찾지 못했습니다.');
      }
    }, 700);

    hideEntrySaveUiCandidates();
    inspectSaveSuccess(startedAt);
  }

  function stopSaveWatchTimersOnly() {
    if (saveWatchTimer) {
      clearInterval(saveWatchTimer);
      saveWatchTimer = null;
    }
    if (saveMutationObserver) {
      saveMutationObserver.disconnect();
      saveMutationObserver = null;
    }
  }

  function inspectSaveSuccess() {
    const found = scanForSaveSuccessText();
    if (!found) return false;
    stopSaveWatchTimersOnly();
    state.saveWatcher = Object.assign(defaultSaveWatcherState(), state.saveWatcher || {});
    state.saveWatcher.lastDetectedText = found;
    markSaveStatus('success', '저장 성공 감지됨', `감지 문구: ${found}`);
    toast('저장 성공 감지됨');
    return true;
  }

  function scanForSaveSuccessText() {
    const successPattern = /(저장되었습니다|저장 완료|저장완료|저장됨|저장했어요|저장 성공|saved|save complete|saved successfully)/i;
    const failPattern = /(저장 실패|저장할 수 없음|오류|실패|failed|error)/i;
    const nodes = Array.from(document.querySelectorAll('div, span, p, button, strong, em, small, [role="alert"], [aria-live]'));
    for (const node of nodes) {
      if (!(node instanceof HTMLElement)) continue;
      if (isRadianceNode(node)) continue;
      const rect = node.getBoundingClientRect();
      if (rect.width <= 0 || rect.height <= 0) continue;
      const style = window.getComputedStyle(node);
      const alreadyHiddenByRadiance = node.classList.contains('radiance-entry-save-ui-hidden') || Boolean(node.closest('.radiance-entry-save-ui-hidden'));
      if (!alreadyHiddenByRadiance && (style.display === 'none' || style.visibility === 'hidden' || Number(style.opacity || 1) < 0.15)) continue;
      const text = (node.innerText || node.textContent || '').replace(/\s+/g, ' ').trim();
      if (isEntrySaveStatusText(text) && state.saveWatcher?.hideEntrySaveUi) {
        const target = findEntrySaveUiContainer(node);
        if (target) target.classList.add('radiance-entry-save-ui-hidden');
      }
      if (!text || text.length > 80) continue;
      if (failPattern.test(text)) {
        markSaveStatus('failed', '저장 실패 문구 감지', text);
        return '';
      }
      if (successPattern.test(text)) return text;
    }
    return '';
  }

  function markSaveStatus(status, message, detail = '', options = {}) {
    state.saveWatcher = Object.assign(defaultSaveWatcherState(), state.saveWatcher || {});
    if (options.clear) {
      state.saveWatcher = defaultSaveWatcherState();
    } else {
      state.saveWatcher.status = status;
      state.saveWatcher.message = message;
      state.saveWatcher.detail = detail;
      if (status === 'watching') state.saveWatcher.watchUntil = Date.now() + 20000;
      if (status === 'success') {
        state.saveWatcher.lastSuccessAt = new Date().toISOString();
        state.saveWatcher.watchUntil = 0;
        state.stats.saveSuccessDetections = Number(state.stats.saveSuccessDetections || 0) + 1;
      }
      if (status === 'failed') state.saveWatcher.watchUntil = 0;
    }
    hideEntrySaveUiCandidates();
    refreshBadges(true);
    saveLocalNow();
    if (state.tab === 'save') setTimeout(render, 0);
  }

  function flashEntrySaveButton() {
    const button = getPreferredSaveButton();
    if (!button) {
      markSaveStatus('failed', '저장 버튼 미감지', '저장 버튼을 찾지 못했습니다.');
      toast('저장 버튼을 찾지 못했습니다.');
      return false;
    }
    button.scrollIntoView?.({ block: 'center', inline: 'center', behavior: 'smooth' });
    button.classList.add('radiance-save-flash');
    setTimeout(() => button.classList.remove('radiance-save-flash'), 1600);
    markSaveStatus('idle', '저장 버튼 표시됨', getSaveCandidateLabel(button) || '버튼을 강조 표시했습니다.');
    toast('저장 버튼을 표시했습니다.');
    return true;
  }

  function isSaveClickTarget(target) {
    const node = target?.closest?.('button, a, [role="button"], div, span');
    if (!(node instanceof HTMLElement)) return false;
    if (isRadianceNode(node)) return false;
    const label = getSaveCandidateLabel(node);
    if (!label || isBadSaveLabel(label)) return false;
    return /(^|\s)(저장|저장하기|Radiance 백업|프로젝트 저장)(\s|$)/i.test(label) || (label.includes('저장') && label.length <= 16);
  }

  function copySaveStatus() {
    const data = {
      type: 'radiance-save-clicker-status',
      projectKey,
      saveWatcher: state.saveWatcher || defaultSaveWatcherState(),
      saveButtonDetected: Boolean(getPreferredSaveButton()),
      workspace: detectWorkspace(),
      copiedAt: new Date().toISOString()
    };
    copyText(JSON.stringify(data, null, 2), TEXT.copiedToast);
  }

  
  function badgeDefinitions() {
    const checkedCount = CHECKLIST.filter((_, i) => state.checklist[i]).length;
    const cueCount = timelineLines(state.timeline).length;
    const notesLen = (state.notes || '').trim().length;
    const snippetLen = (state.customSnippets || '').trim().length;
    const bridgeItems = parseBridgeItems(state.bridgeJson).items.length;
    const coordUses = Number(state.stats.coordCopies || 0) + Number(state.stats.coordInserts || 0);
    const insertions = Number(state.stats.insertions || 0);
    return [
      {
        id: 'first-light',
        icon: '✨',
        title: '첫 발광',
        desc: 'Radiance 패널을 열었습니다.',
        achieved: true,
        progress: '완료'
      },
      {
        id: 'check-master',
        icon: '✅',
        title: '점검 완료',
        desc: '체크리스트를 모두 완료했습니다.',
        achieved: checkedCount >= CHECKLIST.length,
        progress: `${checkedCount}/${CHECKLIST.length}`
      },
      {
        id: 'coordinate-mage',
        icon: '📍',
        title: '좌표술사',
        desc: '좌표 복사/입력을 3번 이상 사용했습니다.',
        achieved: coordUses >= 3,
        progress: `${Math.min(coordUses, 3)}/3`
      },
      {
        id: 'cue-master',
        icon: '🎬',
        title: '큐 마스터',
        desc: '타임라인 큐를 5개 이상 작성했습니다.',
        achieved: cueCount >= 5,
        progress: `${Math.min(cueCount, 5)}/5`
      },
      {
        id: 'memo-keeper',
        icon: '📝',
        title: '기록 보관자',
        desc: '프로젝트 메모를 100자 이상 작성했습니다.',
        achieved: notesLen >= 100,
        progress: `${Math.min(notesLen, 100)}/100자`
      },
      {
        id: 'snippet-smith',
        icon: '🧩',
        title: '스니펫 장인',
        desc: '내 스니펫을 20자 이상 저장했습니다.',
        achieved: snippetLen >= 20,
        progress: `${Math.min(snippetLen, 20)}/20자`
      },
      {
        id: 'entry-touch',
        icon: '🖱️',
        title: '작업창 터치',
        desc: '엔트리 입력칸에 Radiance 값을 넣었습니다.',
        achieved: insertions >= 1,
        progress: `${Math.min(insertions, 1)}/1`
      },
      {
        id: 'viventry-link',
        icon: '🌉',
        title: 'Viventry 연결자',
        desc: 'Bridge에서 JSON 큐를 감지했습니다.',
        achieved: bridgeItems >= 1,
        progress: `${bridgeItems}큐`
      },
      {
        id: 'backup-keeper',
        icon: '🗄️',
        title: '백업 관리자',
        desc: 'Radiance 내부 백업을 만들었습니다.',
        achieved: Number(state.stats.internalBackups || 0) >= 1,
        progress: `${Math.min(Number(state.stats.internalBackups || 0), 1)}/1`
      },
      {
        id: 'page-searcher',
        icon: '🔎',
        title: '페이지 탐색자',
        desc: '페이지 내부 검색을 사용했습니다.',
        achieved: Number(state.stats.pageSearches || 0) >= 1,
        progress: `${Math.min(Number(state.stats.pageSearches || 0), 1)}/1`
      }
    ];
  }

  function refreshBadges(showToast = false) {
    let unlocked = false;
    for (const badge of badgeDefinitions()) {
      if (badge.achieved && !state.badges[badge.id]) {
        state.badges[badge.id] = true;
        unlocked = true;
        if (showToast) toast(`${TEXT.badgeUnlocked}: ${badge.icon} ${badge.title}`);
      }
    }
    if (unlocked) saveLocal();
    return unlocked;
  }

  function bumpStat(key, amount = 1) {
    state.stats[key] = Number(state.stats[key] || 0) + amount;
    refreshBadges(true);
    saveLocal();
  }

  function renderBadges() {
    refreshBadges(false);
    const badges = badgeDefinitions();
    const unlocked = badges.filter(b => state.badges[b.id]).length;
    return el('div', { class: 'eht-section eht-badge-section' }, [
      sectionIntro(TEXT.badgesTitle, TEXT.badgesDescription),
      el('div', { class: 'eht-badge-summary' }, [
        el('strong', { text: `${unlocked}/${badges.length}` }),
        el('span', { text: '배지 달성' })
      ]),
      el('div', { class: 'eht-badge-grid' }, badges.map(badge => {
        const achieved = Boolean(state.badges[badge.id]);
        return el('div', { class: `eht-badge-card ${achieved ? 'is-achieved' : 'is-locked'}` }, [
          el('div', { class: 'eht-badge-icon', text: achieved ? badge.icon : '🔒' }),
          el('div', { class: 'eht-badge-copy' }, [
            el('strong', { text: badge.title }),
            el('span', { text: badge.desc }),
            el('em', { text: achieved ? `${TEXT.badgeUnlockedLabel} · ${badge.progress}` : `${TEXT.badgeLocked} · ${badge.progress}` })
          ])
        ]);
      }))
    ]);
  }

  function renderSettings() {
    state.darkMode = false;
    const backup = ensureBackupState();
    const guard = ensureLeaveGuardState();
    const page = ensurePageSearchState();
    return el('div', { class: 'eht-section eht-settings-section' }, [
      sectionIntro(TEXT.settingsTitle, 'Radiance 기능 상태를 한눈에 확인합니다.'),
      el('div', { class: 'eht-polish-grid' }, [
        el('div', { class: 'eht-polish-card' }, [
          el('strong', { text: '백업' }),
          el('span', { text: backup.autoEnabled ? `자동 백업 ON · ${backup.intervalMinutes}분` : '자동 백업 OFF' })
        ]),
        el('div', { class: 'eht-polish-card' }, [
          el('strong', { text: '페이지 검색' }),
          el('span', { text: page.active ? `필터 ON · ${page.query || '검색어 없음'}` : 'Enter로 검색 실행' })
        ]),
        el('div', { class: 'eht-polish-card' }, [
          el('strong', { text: '작업 보호' }),
          el('span', { text: '봉인됨' })
        ])
      ]),
      el('div', { class: 'eht-coming-soon' }, [
        el('strong', { text: 'Coming Soon..' }),
        el('span', { text: 'Viventry 고급 적용기, 더 정교한 페이지 검색, 안전한 저장 상태 감지는 다음 버전에서 다듬을 예정입니다.' })
      ])
    ]);
  }

  let darkModeObserver = null;
  let darkModeRefreshTimer = null;
  const DARK_ROOT_CLASS = 'radiance-dark-page-root';
  const DARK_MEDIA_SAFE_CLASS = 'radiance-dark-media-safe';

  function applyDarkMode() {
    state.darkMode = false;
    document.documentElement.classList.remove('radiance-entry-dark');
    stopDarkModeObserver();
    clearDarkModeRoots();
    document.getElementById(`${APP_ID}-darkmode-style`)?.remove();
  }

  function startDarkModeObserver() {
    stopDarkModeObserver();
    if (!document.body) return;
    darkModeObserver = new MutationObserver(() => scheduleDarkModeRootRefresh(80));
    darkModeObserver.observe(document.body, { childList: true, subtree: false });
    window.addEventListener('resize', handleDarkModeResize, { passive: true });
  }

  function stopDarkModeObserver() {
    if (darkModeObserver) {
      darkModeObserver.disconnect();
      darkModeObserver = null;
    }
    window.removeEventListener('resize', handleDarkModeResize);
    if (darkModeRefreshTimer) {
      clearTimeout(darkModeRefreshTimer);
      darkModeRefreshTimer = null;
    }
  }

  function handleDarkModeResize() {
    scheduleDarkModeRootRefresh(120);
  }

  function scheduleDarkModeRootRefresh(delay = 80) {
    if (!state.darkMode) return;
    if (darkModeRefreshTimer) clearTimeout(darkModeRefreshTimer);
    darkModeRefreshTimer = setTimeout(markDarkModeRoots, delay);
  }

  function clearDarkModeRoots() {
    document.querySelectorAll?.(`.${DARK_ROOT_CLASS}`).forEach(node => {
      node.classList.remove(DARK_ROOT_CLASS);
    });
    document.querySelectorAll?.(`.${DARK_MEDIA_SAFE_CLASS}`).forEach(node => {
      node.classList.remove(DARK_MEDIA_SAFE_CLASS);
    });
  }

  function markDarkModeRoots() {
    darkModeRefreshTimer = null;
    if (!state.darkMode || !document.body) return;
    clearDarkModeRoots();
    for (const child of Array.from(document.body.children)) {
      if (!(child instanceof HTMLElement)) continue;
      if (isRadianceNode(child) || shouldIgnoreDarkRoot(child)) continue;
      child.classList.add(DARK_ROOT_CLASS);
    }
    markDarkModeMediaSafe();
  }

  function markDarkModeMediaSafe() {
    const roots = document.querySelectorAll?.(`.${DARK_ROOT_CLASS}`) || [];
    const directMediaSelector = 'img, picture, video, canvas, iframe, svg, object, embed';
    const mediaClassSelector = [
      '[class*="avatar" i]',
      '[class*="profile" i]',
      '[class*="thumbnail" i]',
      '[class*="thumb" i]',
      '[class*="logo" i]',
      '[class*="illust" i]',
      '[class*="illustration" i]',
      '[class*="artwork" i]',
      '[class*="preview" i]'
    ].join(',');

    roots.forEach(root => {
      root.querySelectorAll?.(`${directMediaSelector}, ${mediaClassSelector}`).forEach(node => {
        if (!(node instanceof HTMLElement) && !(node instanceof SVGElement)) return;
        if (isRadianceNode(node)) return;
        node.classList?.add(DARK_MEDIA_SAFE_CLASS);
      });

      root.querySelectorAll?.('div, a, span, button, figure, section, article').forEach(node => {
        if (!(node instanceof HTMLElement)) return;
        if (isRadianceNode(node) || node.classList.contains(DARK_MEDIA_SAFE_CLASS)) return;
        const style = window.getComputedStyle(node);
        const hasBackgroundImage = style.backgroundImage && style.backgroundImage !== 'none';
        if (!hasBackgroundImage) return;
        if (node.querySelector('img, picture, video, canvas, iframe, svg, object, embed')) return;
        const textLength = (node.innerText || '').trim().length;
        if (textLength > 18) return;
        const rect = node.getBoundingClientRect();
        if (rect.width < 20 || rect.height < 20) return;
        node.classList.add(DARK_MEDIA_SAFE_CLASS);
      });
    });
  }

  function isRadianceNode(node) {
    return Boolean(node.matches?.(`#${APP_ID}, #${APP_ID}-bubble, .eht-toast`) || node.closest?.(`#${APP_ID}, #${APP_ID}-bubble, .eht-toast`));
  }

  function shouldIgnoreDarkRoot(node) {
    const tag = node.tagName?.toLowerCase();
    if (!tag) return true;
    if (['script', 'style', 'link', 'meta', 'noscript'].includes(tag)) return true;
    if (node.id === `${APP_ID}-darkmode-style`) return true;
    return false;
  }


  function statusChip(label, value, good) {
    return el('div', { class: `eht-status-chip ${good ? 'is-good' : ''}` }, [
      el('span', { text: label }),
      el('strong', { text: value })
    ]);
  }

  function detectWorkspace() {
    const path = location.pathname.toLowerCase();
    const urlLooksRight = /\/ws(?:\/|$)/.test(path) || /\/project\//.test(path) || /\/editor/.test(path);
    const domLooksRight = Boolean(
      document.querySelector('[class*="workspace" i], [class*="block" i], [class*="entry" i], canvas')
    );
    return { ok: urlLooksRight || domLooksRight, urlLooksRight, domLooksRight };
  }

  let lastEditableTarget = null;

  function isEditableTarget(target) {
    if (!target || target.closest?.(`#${APP_ID}, #${APP_ID}-bubble`)) return false;
    if (target instanceof HTMLInputElement) {
      const blocked = ['button', 'submit', 'reset', 'checkbox', 'radio', 'file', 'image', 'range', 'color'];
      return !target.disabled && !target.readOnly && !blocked.includes((target.type || '').toLowerCase());
    }
    if (target instanceof HTMLTextAreaElement) return !target.disabled && !target.readOnly;
    return Boolean(target.isContentEditable);
  }

  function getTargetLabel() {
    if (!lastEditableTarget || !document.contains(lastEditableTarget)) return TEXT.noTarget;
    const target = lastEditableTarget;
    const aria = target.getAttribute?.('aria-label');
    const title = target.getAttribute?.('title');
    const placeholder = target.getAttribute?.('placeholder');
    const id = target.getAttribute?.('id');
    const name = target.getAttribute?.('name');
    const raw = aria || title || placeholder || name || id || target.tagName.toLowerCase();
    return raw.length > 24 ? raw.slice(0, 24) + '…' : raw;
  }

  function renderTargetMini() {
    return el('div', { class: 'eht-target-mini' }, [
      el('span', { text: TEXT.currentTarget }),
      el('strong', { text: getTargetLabel() })
    ]);
  }

  function replaceTargetValue(text) {
    const target = lastEditableTarget;
    if (!target || !document.contains(target)) {
      toast(TEXT.noTarget);
      return false;
    }
    const value = String(text ?? '');
    try {
      target.focus();
      if (target instanceof HTMLInputElement || target instanceof HTMLTextAreaElement) {
        setTextControlValue(target, value);
      } else if (target.isContentEditable) {
        target.textContent = value;
        target.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'insertText', data: value }));
      }
      target.dispatchEvent(new Event('change', { bubbles: true }));
      bumpStat('targetReplaces');
      toast(TEXT.targetInserted);
      return true;
    } catch (error) {
      console.warn('Radiance replace failed', error);
      toast(TEXT.copyFailed);
      return false;
    }
  }

  function clearTargetValue() {
    return replaceTargetValue('');
  }

  function flashTarget() {
    const target = lastEditableTarget;
    if (!target || !document.contains(target)) {
      toast(TEXT.noTarget);
      return false;
    }
    target.classList.add('radiance-target-flash');
    target.scrollIntoView?.({ block: 'center', inline: 'center', behavior: 'smooth' });
    setTimeout(() => target.classList.remove('radiance-target-flash'), 1200);
    return true;
  }

  function setTextControlValue(target, value) {
    const proto = Object.getPrototypeOf(target);
    const descriptor = Object.getOwnPropertyDescriptor(proto, 'value');
    if (descriptor?.set) descriptor.set.call(target, value);
    else target.value = value;
    try { target.setSelectionRange(value.length, value.length); } catch {}
    target.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'insertText', data: value }));
  }

  
  function insertIntoTarget(text) {
    const target = lastEditableTarget;
    if (!target || !document.contains(target)) {
      toast(TEXT.noTarget);
      return false;
    }
    const value = String(text ?? '');
    try {
      target.focus();
      if (target instanceof HTMLInputElement || target instanceof HTMLTextAreaElement) {
        insertIntoTextControl(target, value);
      } else if (target.isContentEditable) {
        document.execCommand('insertText', false, value);
        target.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'insertText', data: value }));
      }
      target.dispatchEvent(new Event('change', { bubbles: true }));
      bumpStat('insertions');
      toast(TEXT.targetInserted);
      return true;
    } catch (error) {
      console.warn('Radiance insert failed', error);
      toast(TEXT.copyFailed);
      return false;
    }
  }

  function insertIntoTextControl(target, value) {
    const start = typeof target.selectionStart === 'number' ? target.selectionStart : target.value.length;
    const end = typeof target.selectionEnd === 'number' ? target.selectionEnd : target.value.length;
    const next = target.value.slice(0, start) + value + target.value.slice(end);
    const proto = Object.getPrototypeOf(target);
    const descriptor = Object.getOwnPropertyDescriptor(proto, 'value');
    if (descriptor?.set) descriptor.set.call(target, next);
    else target.value = next;
    const cursor = start + value.length;
    try { target.setSelectionRange(cursor, cursor); } catch {}
    target.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'insertText', data: value }));
  }

  function bringSelectionToArea(area) {
    const selected = String(window.getSelection?.() || '').trim();
    if (!selected) {
      toast('선택된 텍스트가 없습니다.');
      return;
    }
    area.value = selected;
    if (area.classList.contains('eht-bridge-insert')) state.bridgeInsertText = selected;
    area.dispatchEvent(new Event('input', { bubbles: true }));
    toast(TEXT.savedToast);
  }

  function parseBridgeItems(raw) {
    const value = (raw || '').trim();
    if (!value) return { items: [], error: '' };
    try {
      const data = JSON.parse(value);
      const source = extractBridgeArray(data);
      const items = source.map((item, index) => normalizeBridgeItem(item, index));
      return { items, error: '' };
    } catch {
      return { items: [], error: TEXT.jsonInvalid };
    }
  }

  function extractBridgeArray(data) {
    if (Array.isArray(data)) return data;
    if (!data || typeof data !== 'object') return [];
    const candidates = [
      data.items,
      data.timeline,
      data.cues,
      data.queue,
      data.objects,
      data.scenes,
      data.actions,
      data.steps,
      data.plan?.items,
      data.plan?.timeline,
      data.viventry?.items,
      data.viventry?.timeline
    ];
    for (const candidate of candidates) {
      if (Array.isArray(candidate)) return candidate;
    }
    return [];
  }

  function normalizeBridgeItem(item, index) {
    if (typeof item === 'string') return { id: `item-${index}`, time: '', text: item, fields: { text: item } };
    const fields = flattenBridgeFields(item || {});
    const time = String(fields.time ?? fields.t ?? fields.at ?? '');
    const text = String(fields.text ?? fields.label ?? fields.body ?? fields.lyric ?? fields.name ?? fields.value ?? '');
    const id = String(fields.id ?? `${time}-${text}-${index}`);
    return { id, time, text, fields };
  }

  function flattenBridgeFields(item) {
    const fields = { ...item };
    const pos = item.position || item.pos || item.coord || item.coords || item.coordinate || {};
    if (fields.x === undefined && pos.x !== undefined) fields.x = pos.x;
    if (fields.y === undefined && pos.y !== undefined) fields.y = pos.y;
    if (fields.size === undefined && fields.scale !== undefined) fields.size = fields.scale;
    if (fields.direction === undefined && fields.rotation !== undefined) fields.direction = fields.rotation;
    if (fields.text === undefined && item.content !== undefined) fields.text = item.content;
    if (fields.effect === undefined && item.motion !== undefined) fields.effect = item.motion;
    return fields;
  }

  function bridgeLine(item) {
    const bits = [];
    if (item.time) bits.push(`${item.time}s`);
    if (item.text) bits.push(item.text);
    for (const key of ['x', 'y', 'size', 'direction', 'effect', 'scene', 'object']) {
      const value = bridgeFieldValue(item, key);
      if (value !== '') bits.push(`${key}:${value}`);
    }
    return bits.join('  ') || JSON.stringify(item.fields);
  }

  function bridgeFieldValue(item, key) {
    if (!item || !item.fields) return '';
    const aliases = {
      text: ['text', 'label', 'body', 'lyric', 'name', 'value', 'content'],
      x: ['x'],
      y: ['y'],
      size: ['size', 'scale'],
      direction: ['direction', 'rotation', 'angle'],
      effect: ['effect', 'motion', 'animation'],
      scene: ['scene'],
      object: ['object', 'sprite', 'target']
    };
    for (const alias of aliases[key] || [key]) {
      const value = item.fields[alias];
      if (value !== undefined && value !== null && value !== '') return String(value);
    }
    return '';
  }

  function renderBridgeActive(container, items) {
    container.replaceChildren();
    if (!items.length) {
      container.append(el('div', { class: 'eht-hint', text: '큐를 불러오면 현재 큐 적용기가 표시됩니다.' }));
      return;
    }
    const index = clamp(state.bridgeActiveIndex || 0, 0, items.length - 1);
    const item = items[index];
    const line = bridgeLine(item);
    const done = Boolean(state.bridgeDone[item.id]);
    container.append(el('div', { class: 'eht-mini-title', text: `현재 큐 ${index + 1}/${items.length}${done ? ' · 완료' : ''}` }));
    container.append(el('div', { class: 'eht-bridge-current-line', text: line }));
    container.append(el('div', { class: 'eht-action-row eht-wrap-row' }, [
      el('button', { class: 'eht-link-btn', onclick: () => moveBridgeIndex(-1) }, ['이전']),
      el('button', { class: 'eht-link-btn', onclick: () => moveBridgeIndex(1) }, ['다음']),
      el('button', { class: 'eht-main-btn', onclick: () => insertBridgeField(item, 'text', { done: true, advance: true }) }, ['텍스트 넣고 다음']),
      el('button', { class: 'eht-link-btn', onclick: () => insertIntoTarget(line) }, ['전체 입력']),
      el('button', { class: 'eht-link-btn', onclick: () => copyText(line, TEXT.copiedToast) }, [TEXT.copyButton])
    ]));
    const fieldButtons = ['text', 'x', 'y', 'size', 'direction', 'effect', 'scene', 'object'].filter(key => bridgeFieldValue(item, key) !== '').map(key =>
      el('button', { class: 'eht-link-btn', onclick: () => insertBridgeField(item, key) }, [key])
    );
    if (fieldButtons.length) container.append(el('div', { class: 'eht-action-row eht-wrap-row' }, fieldButtons));
  }

  function renderBridgeQueue(container, status, raw) {
    container.replaceChildren();
    const { items, error } = parseBridgeItems(raw);
    status.textContent = error || (items.length ? `${items.length}개 큐 감지됨` : 'JSON을 붙여넣으면 큐가 표시됩니다.');
    status.classList.toggle('is-danger', Boolean(error));
    if (error || !items.length) return;
    container.append(el('div', { class: 'eht-mini-title', text: TEXT.queuePreview }));
    items.slice(0, 60).forEach((item, index) => {
      const line = bridgeLine(item);
      const done = Boolean(state.bridgeDone[item.id]);
      const active = index === state.bridgeActiveIndex;
      const fieldButtons = ['text', 'x', 'y', 'size', 'direction'].filter(key => bridgeFieldValue(item, key) !== '').map(key =>
        el('button', { class: 'eht-link-btn', onclick: () => insertBridgeField(item, key) }, [key])
      );
      container.append(el('div', { class: `eht-bridge-item ${done ? 'is-done' : ''} ${active ? 'is-active' : ''}` }, [
        el('div', { class: 'eht-bridge-item-main', onclick: () => setBridgeIndex(index) }, [
          el('span', { class: 'eht-bridge-index', text: String(index + 1) }),
          el('div', { class: 'eht-bridge-text', text: line })
        ]),
        el('div', { class: 'eht-action-row eht-wrap-row' }, [
          el('button', { class: 'eht-link-btn', onclick: () => copyText(line, TEXT.copiedToast) }, [TEXT.copyButton]),
          el('button', { class: 'eht-link-btn', onclick: () => insertBridgeField(item, 'text') }, [TEXT.insertButton]),
          el('button', { class: 'eht-link-btn', onclick: () => { setBridgeIndex(index); insertBridgeField(item, 'text', { done: true, advance: true }); } }, ['넣고 다음']),
          ...fieldButtons,
          el('button', { class: 'eht-link-btn', onclick: () => {
            state.bridgeDone[item.id] = !state.bridgeDone[item.id];
            saveLocal();
            render();
          } }, [done ? TEXT.clearDone : TEXT.markDone])
        ])
      ]));
    });
    if (items.length > 60) container.append(el('div', { class: 'eht-timeline-more', text: `+${items.length - 60}개 더 있음` }));
  }

  function setBridgeIndex(index) {
    const { items } = parseBridgeItems(state.bridgeJson);
    state.bridgeActiveIndex = items.length ? clamp(index, 0, items.length - 1) : 0;
    saveLocalNow();
    render();
  }

  function moveBridgeIndex(delta) {
    const { items } = parseBridgeItems(state.bridgeJson);
    if (!items.length) return;
    state.bridgeActiveIndex = clamp((state.bridgeActiveIndex || 0) + delta, 0, items.length - 1);
    saveLocalNow();
    render();
  }

  function insertBridgeField(item, key, options = {}) {
    const value = key === 'line' ? bridgeLine(item) : bridgeFieldValue(item, key);
    if (value === '') {
      toast(`${key} 값이 없습니다.`);
      return false;
    }
    const ok = insertIntoTarget(value);
    if (!ok) return false;
    bumpStat('bridgeFieldInserts');
    if (options.done) state.bridgeDone[item.id] = true;
    if (options.advance) moveBridgeIndex(1);
    else saveLocal();
    return true;
  }

  function fillBridgeExample(area, onUpdate) {
    const sample = {
      type: 'viventry-timeline',
      items: [
        { time: '00.0', text: '심어둔', x: 0, y: 20, size: 35, effect: 'fade-in' },
        { time: '01.2', text: '우리를', x: -40, y: -10, size: 32, effect: 'slide-up' },
        { time: '02.5', text: '기억하겠다', x: 30, y: 0, size: 30, effect: 'typewriter' }
      ]
    };
    area.value = JSON.stringify(sample, null, 2);
    state.bridgeJson = area.value;
    onUpdate?.();
    toast(TEXT.savedToast);
  }

  function timelineToBridge(area, onUpdate) {
    const items = timelineLines(state.timeline).map((line, index) => {
      const seconds = parseSeconds(line);
      const body = line.replace(/^(?:(\d+):)?\d+(?:\.\d+)?\s*s?\s*/i, '').trim() || line;
      return {
        id: `timeline-${index}`,
        time: Number.isFinite(seconds) ? Number(seconds.toFixed(1)) : '',
        text: body
      };
    });
    if (!items.length) {
      toast('타임라인 메모가 비어 있습니다.');
      return;
    }
    area.value = JSON.stringify({ type: 'radiance-timeline-import', items }, null, 2);
    state.bridgeJson = area.value;
    onUpdate?.();
    toast('타임라인을 Bridge로 변환했습니다.');
  }

  
  function rerollWarning() {
    let next = state.warningIndex;
    while (WARNINGS.length > 1 && next === state.warningIndex) {
      next = Math.floor(Math.random() * WARNINGS.length);
    }
    state.warningIndex = next;
    saveLocalNow();
    const warning = document.querySelector(`#${APP_ID} .eht-warning`);
    if (warning) warning.textContent = WARNINGS[state.warningIndex];
  }

  function collapsePanel() {
    state.collapsed = true;
    saveLocalNow();
    render();
  }

  function clearChecklist() {
    state.checklist = {};
    saveLocalNow();
    render();
    toast(`${TEXT.tabs.check} ${TEXT.resetButton}됨`);
  }

  async function resetCurrentProject() {
    const ok = confirm(TEXT.resetConfirm);
    if (!ok) return;
    await safeChromeStorageSet({
      [storageKey]: {
        collapsed: false,
        tab: 'check',
        checklist: {},
        timeline: '',
        notes: '',
        customSnippets: '',
        bridgeJson: '',
        bridgeDone: {},
        bridgeInsertText: '',
        bridgeActiveIndex: 0,
        saveWatcher: defaultSaveWatcherState(),
        internalBackup: defaultInternalBackupState(),
        pageSearch: defaultPageSearchState(),
    leaveGuard: defaultLeaveGuardState(),
        badges: {},
        stats: {},
        warningIndex: Math.floor(Math.random() * WARNINGS.length)
      }
    });
    state.collapsed = false;
    state.tab = 'check';
    state.checklist = {};
    state.timeline = '';
    state.notes = '';
    state.customSnippets = '';
    state.bridgeJson = '';
    state.bridgeDone = {};
    state.bridgeInsertText = '';
    state.bridgeActiveIndex = 0;
    state.saveWatcher = defaultSaveWatcherState();
    state.internalBackup = defaultInternalBackupState();
    state.pageSearch = defaultPageSearchState();
    state.leaveGuard = defaultLeaveGuardState();
    state.badges = {};
    state.stats = {};
    render();
  }

  function exportProjectData() {
    const data = {
      name: `${TEXT.name} 백업`,
      projectKey,
      exportedAt: new Date().toISOString(),
      checklist: state.checklist,
      timeline: state.timeline,
      notes: state.notes,
      customSnippets: state.customSnippets,
      bridgeJson: state.bridgeJson,
      bridgeDone: state.bridgeDone,
      badges: state.badges,
      stats: state.stats,
      darkMode: state.darkMode
    };
    const text = JSON.stringify(data, null, 2);
    copyText(text, TEXT.copiedToast);
  }

  async function copyText(text, successMessage = TEXT.copiedToast) {
    try {
      await navigator.clipboard.writeText(text || '');
      toast(successMessage);
    } catch {
      try {
        const textarea = document.createElement('textarea');
        textarea.value = text || '';
        textarea.style.position = 'fixed';
        textarea.style.left = '-9999px';
        document.body.append(textarea);
        textarea.select();
        document.execCommand('copy');
        textarea.remove();
        toast(successMessage);
      } catch {
        toast(TEXT.copyFailed);
      }
    }
  }

  function toast(message) {
    document.querySelector('.eht-toast')?.remove();
    const node = el('div', { class: 'eht-toast', text: message });
    document.documentElement.append(node);
    setTimeout(() => node.remove(), 1600);
  }

  function makeDraggable(root, handle) {
    let startX = 0;
    let startY = 0;
    let startRight = 0;
    let startTop = 0;
    let dragging = false;

    handle.addEventListener('pointerdown', event => {
      if (event.target.closest('button')) return;
      dragging = true;
      startX = event.clientX;
      startY = event.clientY;
      const rect = root.getBoundingClientRect();
      startRight = window.innerWidth - rect.right;
      startTop = rect.top;
      handle.setPointerCapture(event.pointerId);
      root.classList.add('is-dragging');
    });

    handle.addEventListener('pointermove', event => {
      if (!dragging) return;
      const dx = event.clientX - startX;
      const dy = event.clientY - startY;
      const width = root.offsetWidth || 330;
      const nextRight = clamp(startRight - dx, 8, Math.max(8, window.innerWidth - width - 8));
      const nextTop = clamp(startTop + dy, 8, Math.max(8, window.innerHeight - 80));
      state.position = { right: nextRight, top: nextTop };
      root.style.right = `${nextRight}px`;
      root.style.top = `${nextTop}px`;
      saveGlobal();
    });

    handle.addEventListener('pointerup', event => {
      dragging = false;
      root.classList.remove('is-dragging');
      try { handle.releasePointerCapture(event.pointerId); } catch {}
    });
  }

  function clamp(value, min, max) {
    return Math.min(max, Math.max(min, value));
  }



  function keepPanelInsideViewport() {
    const root = document.getElementById(APP_ID);
    if (!root || state.collapsed) return;
    const rect = root.getBoundingClientRect();
    const margin = 14;
    let changed = false;
    if (rect.top < margin) {
      state.position.top = margin;
      changed = true;
    }
    if (rect.bottom > window.innerHeight - margin) {
      state.position.top = Math.max(margin, window.innerHeight - rect.height - margin);
      changed = true;
    }
    if (rect.right > window.innerWidth - margin) {
      state.position.right = margin;
      changed = true;
    }
    if (changed) {
      root.style.top = `${state.position.top}px`;
      root.style.right = `${state.position.right}px`;
      saveGlobal();
    }
  }


  window.addEventListener('resize', () => setTimeout(keepPanelInsideViewport, 80), { passive: true });


  // Global save click/key listeners removed in v0.6.7 hotfix.

  setupLeaveGuardListeners();

  window.addEventListener('pagehide', () => {
    saveLocalNow();
  }, { capture: true });

  document.addEventListener('focusin', event => {
    if (isEditableTarget(event.target)) {
      lastEditableTarget = event.target;
      const targetMini = document.querySelector(`#${APP_ID} .eht-target-mini strong`);
      if (targetMini) targetMini.textContent = getTargetLabel();
    }
  }, true);

  chrome.runtime?.onMessage?.addListener((message, _sender, sendResponse) => {
    if (!message || message.source !== 'ENTRY_HELPER_POPUP') return;
    if (message.type === 'SET_ENABLED') {
      state.enabled = Boolean(message.enabled);
      saveGlobal();
      render();
      setTimeout(keepPanelInsideViewport, 0);
      sendResponse?.({ ok: true, enabled: state.enabled });
    }
    if (message.type === 'SET_DARK_MODE') {
      state.darkMode = Boolean(message.darkMode);
      applyDarkMode();
      saveGlobal();
      refreshBadges(true);
      sendResponse?.({ ok: true, darkMode: state.darkMode });
    }
    if (message.type === 'OPEN_PANEL') {
      state.enabled = true;
      state.collapsed = false;
      saveGlobal();
      saveLocalNow();
      render();
      sendResponse?.({ ok: true });
    }
  });

  loadState().then(() => {
    refreshBadges(false);
    render();
  }).catch(() => {
    console.warn(TEXT.loadFailed);
  });
})();
